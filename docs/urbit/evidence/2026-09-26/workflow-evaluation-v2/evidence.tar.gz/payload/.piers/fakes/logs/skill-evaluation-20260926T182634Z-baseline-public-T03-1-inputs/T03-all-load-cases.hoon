/=  candidate  /app/eval-counter
:-  %say
|=  *
:-  %noun
~&  [%stead-skill-t03 %body-enter]
=/  context=bowl:gall  *bowl:gall
=.  our.context  ~zod
=.  src.context  ~zod
=.  now.context  ~2026.9.25
=/  original=agent:gall  ~(. candidate context)
~&  [%stead-skill-t03 %initial-agent-ready]
=/  initial=vase  on-save:original
~&  [%stead-skill-t03 %initial-save-returned]
?>  =([%1 0 0] q.initial)
=/  view-saved
  |=  saved=vase
  ^-  [value=* type-bytes=@ud type-sha256=@ux]
  =/  encoded-type=@  (jam p.saved)
  [q.saved (met 3 encoded-type) (shax encoded-type)]
=/  run-case
  |=  [label=@t incoming=vase expected=* must-reject=? repeat-load=?]
  ^-  *
  ~&  [%stead-skill-t03 %case-begin label]
  =/  agent=agent:gall  ~(. candidate context)
  ~&  [%stead-skill-t03 %case-agent-ready label]
  ?>  =(%.n must-reject)
  ~&  [%stead-skill-t03 %load-begin label]
  =+  [cards loaded]=(on-load:agent incoming)
  ~&  [%stead-skill-t03 %load-returned label]
  ?>  =(~ cards)
  =/  observed=vase  on-save:loaded
  ~&  [%stead-skill-t03 %save-returned label]
  ?>  =(expected q.observed)
  ?:  repeat-load
    ~&  [%stead-skill-t03 %roundtrip-load-begin label]
    =+  [later-cards reloaded]=(on-load:loaded observed)
    ~&  [%stead-skill-t03 %roundtrip-load-returned label]
    ?>  =(~ later-cards)
    =/  again=vase  on-save:reloaded
    ?>  =(observed again)
    ~&  [%stead-skill-t03 %case-checked label]
    [label cards (view-saved observed)]
  ~&  [%stead-skill-t03 %case-checked label]
  [label cards (view-saved observed)]
=/  evidence=(list *)
  :~
    (run-case 'public-v0' !>([%0 7]) [%1 7 0] %.n %.n)
    (run-case 'public-v1' !>([%1 9 3]) [%1 9 3] %.n %.n)
  ==
~&  [%stead-skill-t03 %all-cases-checked]
~&  [%stead-skill-t03 %jam-begin]
=/  encoded=@ud  (jam evidence)
=/  encoded-bytes=@ud  (met 3 encoded)
~&  [%stead-skill-t03 %result-jam-bytes encoded-bytes]
?.  (lte encoded-bytes 262.144)
  ~|  [%stead-skill-t03-result-jam-oversize encoded-bytes]
  !!
^-  [@tas @ud]
[%skill-result encoded]

"""Read-only actual artifact audit; never starts native code or participant work.

Writes only new parent-only audit/result/selection records after successful
validation. Run in the same CPU50%/10ms CPU19 evidence scope. Archive compression
is a separate, explicitly coordinated step.
"""
from __future__ import annotations
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
sys.dont_write_bytecode = True
import export_parent_deliveries as common
import archive_v2_evidence as archive
import final_score as scorer

BASE, REPO, HEAD, PACKAGE = common.BASE, common.REPO, common.HEAD, common.PACKAGE
ROLES = tuple(common.TASKS)
WORK = REPO / '.runtime/workflow-evaluation-v2'
MEMBERS = {}
EXPOSURES = {}
require = common.require
sha = common.digest


def read(path):
    return common.read(Path(path), archive.MAX_FILE)


def doc(path):
    return common.document(read(path))


def capture(path, classification, expose=None):
    path = Path(path).absolute()
    rel = path.relative_to(REPO).as_posix()
    require(archive.allowed(archive.relative(rel)), 'Unexpected audit evidence path: ' + rel)
    raw = read(path)
    item = {'path': rel, 'sha256': sha(raw), 'bytes': len(raw), 'classification': classification}
    if expose:
        item['expose_as'] = expose
        EXPOSURES[rel] = expose
    elif rel in EXPOSURES:
        item['expose_as'] = EXPOSURES[rel]
    if rel in MEMBERS:
        require(MEMBERS[rel]['sha256'] == item['sha256'], 'Evidence changed during audit')
    MEMBERS[rel] = item
    return {'path': item.get('expose_as', 'evidence.tar.gz#payload/' + rel),
            'sha256': item['sha256'], 'classification': classification}


def tree(path, classification):
    count = 0
    for parent, dirs, names in os.walk(path, followlinks=False):
        dirs[:] = sorted(name for name in dirs if name != '__pycache__')
        for name in dirs + sorted(names):
            count += 1
            require(count <= 8192, 'Evidence tree bound')
            child = Path(parent) / name
            require(not child.is_symlink(), 'Redirected evidence tree')
            if child.is_dir() or name.endswith(('.lock', '.pyc')):
                continue
            capture(child, classification)


def utc(value):
    return dt.datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def clock(role, final):
    rows, active, begin, previous, state, prior = [], 0, None, None, 'new', 0
    intervals, paused = [], 0
    opened = None
    boot = None
    for number, path in enumerate(sorted((BASE / role / 'timing').glob('*.json')), 1):
        raw = read(path)
        row = common.document(raw)
        require(path.name == f'{number:04d}.json' and row['number'] == number and row['condition'] == role
                and row['previous_sha256'] == previous and row['state_before'] == state
                and row['active_before_ns'] == active and row['monotonic_ns'] >= prior, 'Clock chain differs')
        if boot is None:
            boot = row['boot_id']
        require(row['boot_id'] == boot, 'Clock crossed boot identity')
        action, stamp = row['event'], row['monotonic_ns']
        if state == 'running':
            active += stamp - begin
            intervals.append({'start_utc': opened['utc'], 'end_utc': row['utc'],
                              'start_ns': begin, 'end_ns': stamp})
        elif state == 'paused':
            paused += stamp - opened['monotonic_ns']
        require((action == 'start' and state == 'new') or (action == 'resume' and state == 'paused')
                or (action == 'pause' and state == 'running')
                or (action in ('final', 'cutoff') and state in ('running', 'paused')), 'Invalid clock transition')
        state = 'running' if action in ('start', 'resume') else ('paused' if action == 'pause' else 'closed')
        begin = stamp if state == 'running' else None
        require(row['state_after'] == state and row['active_after_ns'] == active
                and row['active_interval_started_ns'] == begin, 'Clock calculation differs')
        rows.append(row)
        opened, previous, prior = row, sha(raw), stamp
    require(state == 'closed' and active <= 1800_000_000_000
            and final['active_seconds'] == active / 1e9
            and str(path.relative_to(REPO)) == final['final_clock_record'], 'Final active budget differs')
    return {'records': len(rows), 'active_seconds': active / 1e9,
            'infrastructure_seconds': paused / 1e9, 'intervals': intervals,
            'events': [{key: row[key] for key in ('number', 'event', 'utc', 'reference')} for row in rows]}


def during(stamp, intervals):
    value = utc(stamp)
    return any(utc(row['start_utc']) <= value <= utc(row['end_utc']) for row in intervals)


def trace(role, timing, launch):
    manifest = doc(BASE / 'filtered-traces-safe/manifest.json')
    raw = read(BASE / 'filtered-traces-safe' / (role + '.jsonl'))
    expected = manifest['roles'][role]['filtered_trace']
    require(len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], 'Child export hash differs')
    rows = [common.document(line) for line in raw.splitlines()]
    require(all('internal_chat_message_metadata_passthrough' not in row['payload'] for row in rows),
            'Excluded internal metadata retained')
    contexts = [row['payload'] for row in rows if row['type'] == 'turn_context']
    require(contexts == manifest['roles'][role]['model_contexts'] and contexts
            and {row['model'] for row in contexts} == {'gpt-6-astra'}
            and {row['effort'] for row in contexts} == {'max'}, 'Actual model/effort differs')
    calls = [row for row in rows if row['type'] == 'response_item'
             and row['payload']['type'] in ('custom_tool_call', 'function_call')]
    results = [row for row in rows if row['type'] == 'response_item'
               and row['payload']['type'] in ('custom_tool_call_output', 'function_call_output')]
    by_id = {row['payload']['call_id']: row for row in results}
    require(len(by_id) == len(results) == len(calls), 'Missing/duplicate tool result')
    pattern = re.compile(r'\s*const r = await tools\.exec_command\(\{cmd:("(?:[^"\\]|\\.)*"),login:false\}\);text\(r\.output\);\s*')
    linked, deviations, requests, cumulative = [], [], [], 0
    first_tasks, reads = [], []
    for row in calls:
        item = row['payload']
        require(item['type'] == 'custom_tool_call' and item['name'] == 'exec', 'Unexpected exposed tool invocation')
        match = pattern.fullmatch(item['input'])
        require(match is not None, 'Nonliteral/unreviewed shell construction')
        command = json.loads(match[1])
        pieces = command.split('\n')
        require(len(pieces) == 3 and pieces[2] == 'REQUEST', 'Unexpected heredoc shape')
        request = common.document(pieces[1])
        requests.append(request)
        require(isinstance(request, dict) and request.get('op') in ('list', 'read', 'hash', 'write', 'copy', 'remove'),
                'Disallowed wrapper operation')
        for key in ('path', 'src', 'dst', 'source', 'destination'):
            if key in request:
                require(isinstance(request[key], str) and not Path(request[key]).is_absolute()
                        and '..' not in Path(request[key]).parts, 'Escaping participant path')
        require(during(row['timestamp'], timing['intervals']), 'Tool work occurred during a paused/closed interval')
        output_row = by_id[item['call_id']]
        require(output_row['source_line'] > row['source_line']
                and during(output_row['timestamp'], timing['intervals']), 'Tool result outside active interval')
        blocks = output_row['payload']['output']
        require(isinstance(blocks, list) and len(blocks) == 2
                and all(block['type'] == 'input_text' for block in blocks), 'Unexpected actual tool result blocks')
        header = f'python3 {BASE}/workspace_tool.py {role} <<\'REQUEST\''
        if pieces[0] != header:
            wrong = f'python3 {REPO}/.runtime/work-v2-participants/workspace_tool.py {role} <<\'REQUEST\''
            require(role == 'local_skill_assisted' and pieces[0] == wrong
                    and request == {'op': 'hash', 'area': 'output', 'path': 'T05/coverage.json'}
                    and blocks[1]['text'] == f"python3: can't open file '{REPO}/.runtime/work-v2-participants/workspace_tool.py': [Errno 2] No such file or directory\n",
                    'Unclassified tool-path deviation')
            deviations.append({'call_id': item['call_id'], 'source_line': row['source_line'],
                               'classification': 'literal missing wrapper path; no wrapper execution or observed file content',
                               'command': command, 'actual_output': blocks[1]['text']})
            continue
        observed = common.document(blocks[1]['text'])
        token = observed['call']
        start_path, finish_path = (BASE / role / 'calls' / (token + suffix)
                                   for suffix in ('.start.json', '.finish.json'))
        start, finish = doc(start_path), doc(finish_path)
        require(start['condition'] == finish['condition'] == role
                and start['wrapper_sha256'] == launch['support_sha256']['workspace_tool.py']
                and bytes.fromhex(start['request_hex']) == (pieces[1] + '\n').encode()
                and start['previous_reserved_bytes'] == cumulative,
                'Wrapper request/source/byte budget differs from actual call')
        cumulative += start['reserved_bytes']
        require(cumulative <= 1048576 and finish['admitted'] is True and finish['status'] == 'passed'
                and finish['cleanup']['verified'] is True and finish['cleanup']['cgroup_removed'] is True
                and finish['ready']['affinity'] == [19] and finish['limits']['files']['cpu.max'] == '5000 10000'
                and finish['limits']['files']['memory.max'] == '134217728'
                and finish['limits']['files']['memory.swap.max'] == '0'
                and finish['limits']['files']['pids.max'] == '16', 'Actual wrapper admission/cleanup/resource failure')
        expected_output = {'protocol': finish['protocol'], 'call': token, 'admitted': finish['admitted'],
                           'cleanup_verified': finish['cleanup']['verified'], 'error': finish.get('error'),
                           'response': finish['response'], 'status': finish['status']}
        require(observed == expected_output, 'Observed tool output differs from retained wrapper record')
        for inventory in (start['before'], finish['after']):
            actual_input = {entry['path']: {'bytes': entry['bytes'], 'sha256': entry['sha256']}
                            for entry in inventory if entry['area'] == 'input' and entry['kind'] == 'file'}
            require(all(actual_input.get(name) == ref for name, ref in launch['input_files'][role].items()),
                    'An initial participant input was missing or changed')
            require(all(name in launch['input_files'][role] or re.fullmatch(r'feedback/T0[1-6]-[1-3]\.json', name)
                        for name in actual_input), 'Unexpected participant-visible input')
        require([entry for entry in start['before'] if entry['area'] == 'input']
                == [entry for entry in finish['after'] if entry['area'] == 'input'], 'Participant operation changed input')
        if request.get('op') in ('list', 'read', 'hash'):
            require(start['before'] == finish['after'], 'Read-only operation changed workspace')
        if request.get('op') == 'read':
            reads.append({key: request.get(key) for key in ('area', 'path')})
        for value in request.values():
            if isinstance(value, str):
                match_task = re.search(r'(?:^|/)T0([1-6])(?:/|\.)', value)
                if match_task:
                    task = 'T0' + match_task[1]
                    if task not in first_tasks:
                        first_tasks.append(task)
        linked.append({'call_id': item['call_id'], 'token': token, 'start': capture(start_path, 'actual-wrapper-start'),
                       'finish': capture(finish_path, 'actual-wrapper-finish')})
    actual_starts = {path.name.removesuffix('.start.json') for path in (BASE / role / 'calls').glob('*.start.json')}
    actual_finishes = {path.name.removesuffix('.finish.json') for path in (BASE / role / 'calls').glob('*.finish.json')}
    require(actual_starts == actual_finishes == {row['token'] for row in linked}, 'Unlinked wrapper operation exists')
    require(first_tasks == ['T01', 'T02', 'T03', 'T04', 'T05', 'T06'], 'First task access order differs')
    visible = [row for row in rows if row['type'] == 'response_item' and row['payload']['type'] == 'message']
    require(all(during(row['timestamp'], timing['intervals']) for row in visible), 'Visible participant work outside active interval')
    return {'actual_tool_calls': len(calls), 'verified_wrapper_calls': len(linked),
            'literal_failed_path_deviations': deviations, 'model_contexts': contexts,
            'cumulative_written_bytes': cumulative, 'first_task_access_order': first_tasks,
            'input_reads': reads, 'wrapper_links': linked, 'work_during_pauses_observed': False,
            'full_exposed_toolset_restricted': False, 'complete_context_isolation_established': False}


def parent_messages(launch):
    manifest = doc(BASE / 'parent-deliveries/manifest.json')
    raw = read(BASE / 'parent-deliveries/parent.jsonl')
    require(sha(raw) == manifest['filtered_trace']['sha256'] and len(raw) == manifest['filtered_trace']['bytes'],
            'Parent export hash differs')
    rows = [common.document(line) for line in raw.splitlines()]
    calls = []
    for call in manifest['calls']:
        row, ack = rows[call['call_record_index']], rows[call['ack_record_index']]
        require(row['payload']['call_id'] == ack['payload']['call_id'] == call['call_id']
                and row['source_line'] < ack['source_line'], 'Parent call/ack linkage differs')
        args = common.document(row['payload']['arguments'])
        role = call['condition']
        if call['operation'] == 'spawn_agent':
            planned = launch['participant_launches'][role]
            require(args == {'task_name': planned['task_name'], 'fork_turns': 'none', 'message': planned['prompt']}
                    and call['matches_recorded_initial_launch'] is True, 'Initial launch/context differs')
        else:
            require(call['operation'] == 'followup_task', 'Unreviewed parent intervention')
            require(args['target'] in (common.TASKS[role], '/root/' + common.TASKS[role]), 'Wrong feedback recipient')
            targets = re.findall(r'input/feedback/(T0[1-6])-([1-3])\.json', args['message'])
            require(len(targets) == 1, 'Feedback delivery lacks unique exact file')
            task, attempt = targets[0]
            receipt = doc(BASE / role / 'feedback-attempts' / task / attempt / 'result.json')
            require(receipt['status'] == 'published' and receipt['cleanup_completed'] is True,
                    'Parent delivered unqualified/infrastructure feedback')
            public = read(BASE / role / 'input/feedback' / (task + '-' + attempt + '.json'))
            require(sha(public) == receipt['feedback_sha256'] and sha(public) in args['message']
                    and receipt['owned_run']['run_id'] in args['message'], 'Delivery body lacks actual public/guard identity')
        calls.append({'condition': role, 'operation': call['operation'], 'call_id': call['call_id'],
                      'timestamp': row['timestamp'], 'message_sha256': sha(args['message'].encode()),
                      'ack_output': ack['payload']['output']})
    return {'calls': calls, 'count': len(calls), 'incoming_ciphertext_decrypted': False,
            'acknowledgment_is_receipt_proof': False}


def schema(value, spec, root):
    if '$ref' in spec:
        selected = root
        for part in spec['$ref'].removeprefix('#/').split('/'):
            selected = selected[part]
        return schema(value, selected, root)
    kinds = spec.get('type')
    kinds = [kinds] if isinstance(kinds, str) else kinds
    types = {'object': dict, 'array': list, 'string': str, 'number': (int, float), 'null': type(None)}
    if kinds:
        require(any(isinstance(value, types[kind]) and not (kind == 'number' and isinstance(value, bool)) for kind in kinds), 'Result schema type')
    if 'const' in spec:
        require(value == spec['const'], 'Result schema constant')
    if 'enum' in spec:
        require(value in spec['enum'], 'Result schema enum')
    if 'pattern' in spec:
        require(re.fullmatch(spec['pattern'], value), 'Result schema pattern')
    if 'minimum' in spec:
        require(value >= spec['minimum'], 'Result schema minimum')
    if isinstance(value, dict):
        require(set(spec.get('required', [])) <= set(value), 'Result schema required field')
        for key, child in spec.get('properties', {}).items():
            if key in value:
                schema(value[key], child, root)
    if isinstance(value, list) and 'items' in spec:
        for item in value:
            schema(item, spec['items'], root)


def write_once(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o400)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return raw


def main():
    common.remotes()
    resources = common.resource_scope()
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == HEAD, 'Wrong frozen HEAD')
    final, launch = doc(BASE / 'final-submissions.json'), doc(BASE / 'launch-inputs.json')
    require(final['both_participants_stopped'] is True and final['no_further_participant_turns_authorized'] is True,
            'Participants must be final')
    content, oracles = scorer.adapter.verify_package(REPO / 'tests/urbit/skill_evaluation')
    freeze = doc(REPO / 'tests/urbit/skill_evaluation/freeze.json')
    require(freeze['package_sha256'] == PACKAGE, 'Frozen package differs')
    parent = parent_messages(launch)
    conditions, audit_roles, source_binding = [], {}, None
    for role in ROLES:
        timing = clock(role, final['conditions'][role])
        access = trace(role, timing, launch)
        root = BASE / 'private-scores' / role
        score, inner, guard, controller, frozen = (doc(root / name) for name in
            ('score-result.json', 'native-inner.json', 'guard.json', 'controller-result.json', 'freeze-result.json'))
        binding = score['binding']
        if source_binding is None:
            source_binding = binding
        require(binding == source_binding and binding['head'] == HEAD and score['errors'] == []
                and score['cleanup_completed'] is True and score['status'] == 'completed-with-candidate-failures'
                and score['tasks_passed'] == 5, 'Observed closed private run differs')
        require(binding == scorer.current_binding(), 'Current exact source/helper binding differs')
        proof, diagnostic = scorer.broker.prior_prequalification(binding)
        values = scorer.exact_files(WORK / role)
        require(set(values) == scorer.expected_paths(oracles) and len(values) == 12
                and values == scorer.exact_files(BASE / role / 'candidate')
                and scorer.task_hashes(values) == score['files_sha256'] == frozen['files_sha256'], 'Final snapshot differs')
        require(read(BASE / role / 'input/T02-starter-diagnostic.json') == diagnostic, 'Initial T02 diagnostic differs')
        helper = scorer.pinned_test_helper(binding)
        checked = scorer.validate_execution(inner, controller, guard, binding, proof, frozen['files_sha256'],
                                             values, content, oracles, helper)
        require(checked == score['tasks'], 'Actual task rows differ from admission replay')
        for name, artifact in score['artifacts'].items():
            require(sha(read(root / name)) == artifact['sha256'], 'Private retained artifact hash differs')
        require(scorer.adapter.hashes(scorer.exact_files(root / 'native-inputs', maximum=128))
                == score['native_inputs_sha256'], 'Retained native input bytes differ')
        require({name: digest for name, digest in score['native_inputs_sha256'].items() if '/' not in name}
                == inner['generated_source_files_sha256'] == inner['generated_source_files_after'], 'Generated source inventory differs')
        report_ref = capture(root / 'native-inner.json', 'actual-private-native-report', f'raw/private/{role}/native-inner.json')
        score_ref = capture(root / 'score-result.json', 'actual-one-shot-private-admission', f'raw/private/{role}/score-result.json')
        guard_ref = capture(root / 'guard.json', 'actual-closed-outer-guard', f'raw/private/{role}/guard.json')
        capture(root / 'source-context.json', 'actual-source-context', f'raw/private/{role}/source-context.json')
        owner = REPO / score['owned_run']['path']
        require(read(owner / 'report.json') == read(root / 'guard.json'), 'Original private guard differs')
        for name in ('report.json', 'events.jsonl', '.stead-disposable.json', 'control/source-context.json'):
            capture(owner / name, 'actual-owned-private-guard')
        attempts = {task['id']: [] for task in oracles['tasks']}
        for path in sorted((BASE / role / 'feedback-attempts').glob('*/*/result.json')):
            receipt = doc(path)
            task, number = receipt['task'], receipt['attempt']
            require(receipt['condition'] == role and 1 <= number <= 3 and receipt['ownership_resolved'] is True
                    and receipt['cleanup_completed'] is True, 'Public reservation ownership/cleanup differs')
            prefix = f'raw/public/{role}/{task}/{number}'
            lifecycle = capture(path, 'actual-public-reservation', prefix + '/result.json')
            item = {'number': number, 'candidate_files_sha256': receipt['files_sha256'],
                    'public_feedback_artifacts': [], 'observed_outcome': 'interrupted',
                    'lifecycle': lifecycle, 'native_execution': 'infrastructure-interrupted'}
            owner = REPO / receipt['owned_run']['path']
            outer = doc(owner / 'report.json')
            require(outer['run_id'] == receipt['owned_run']['run_id'], 'Public guard identity differs')
            for name in ('report.json', 'events.jsonl', '.stead-disposable.json', 'control/source-context.json'):
                capture(owner / name, 'actual-owned-public-guard')
            item['guard'] = capture(owner / 'report.json', 'actual-public-outer-guard', prefix + '/guard.json')
            capture(owner / 'control/source-context.json', 'actual-public-source-context', prefix + '/source-context.json')
            if receipt['status'] == 'published':
                private_raw, public_raw = read(path.parent / 'internal.json'), read(path.parent / 'public.json')
                finishes = list(path.parent.glob('*-feedback.finish.json'))
                require(len(finishes) == 1, 'Public operation inventory differs')
                response = common.document(bytes.fromhex(doc(finishes[0])['stdout_hex']))
                scorer.broker.admit_feedback(response, private_raw, public_raw, outer, receipt['binding'], role, task, number, receipt['files_sha256'])
                require(read(BASE / role / 'input/feedback' / (task + '-' + str(number) + '.json')) == public_raw,
                        'Published participant public bytes differ')
                item.update(observed_outcome=receipt['public_status'], native_execution='completed')
                item['public_feedback_artifacts'] = [capture(path.parent / 'public.json', 'actual-published-public-feedback', prefix + '/public.json')]
                item['native_report'] = capture(path.parent / 'internal.json', 'actual-public-native-report', prefix + '/native-inner.json')
                original = REPO / response['evidence_file']
                require(read(original) == private_raw, 'Original public native report differs')
                capture(original, 'original-public-native-report')
                tree(original.with_name(original.stem + '-inputs'), 'actual-public-generated-native-program')
            else:
                require(role == 'baseline' and task == 'T06' and number == 1
                        and outer['status'] == 'failed' and outer['reason'] == 'GuardError: Thermal ceiling reached',
                        'Unexpected failed public reservation')
                item['limitations'] = ['No public feedback delivered; raw receipt native_execution remains pending.',
                                       'Separate retained bus startup SIGSEGV and thermal guard failure; no causal attribution.']
            attempts[task].append(item)
        require(all([item['number'] for item in rows] == list(range(1, len(rows) + 1)) for rows in attempts.values()),
                'Noncontiguous public reservation inventory')
        if role == 'baseline':
            require(attempts['T06'][0]['candidate_files_sha256'] == attempts['T06'][1]['candidate_files_sha256'], 'Infrastructure retry changed snapshot')
        tasks = []
        for number, (row, task) in enumerate(zip(inner['tasks'], oracles['tasks'], strict=True)):
            require(row['id'] == task['id'], 'Task order differs')
            name = row['id']
            bound = {'source_commit': HEAD, 'runtime_lock_sha256': inner['toolchain_sha256'],
                     'installed_clay_tree_sha256': None,
                     'installed_clay_scope': 'Sequential installed-file projections and typed native readbacks only; no full Clay-tree hash was measured.',
                     'installed_clay_projection_sha256': sha(json.dumps(inner['installed_clay_files'], sort_keys=True, separators=(',', ':')).encode()),
                     'loaded_closure_sha256': sha(json.dumps(inner['loaded_closure'], sort_keys=True, separators=(',', ':')).encode()),
                     'derived_hash_format': 'UTF-8 JSON, sorted keys, comma/colon separators, no newline',
                     'oracle_sha256': freeze['files']['reviewer/oracles.json'],
                     'evaluator_sha256': inner['loaded_closure']['/code/skill_evaluation_support.py'],
                     'guard_report_sha256': guard_ref['sha256'], 'loaded_closure': inner['loaded_closure']}
            assertions = [{'id': check['name'], 'status': 'passed' if check['passed'] else 'failed',
                           'actual': check['passed'], 'expected': True,
                           'artifact': {**report_ref, 'pointer': '/checks/' + str(index)}}
                          for index, check in enumerate(inner['checks']) if check['name'].startswith((name + ':', name + '-'))]
            item = {'id': name, 'status': row['status'], 'attempts': attempts[name],
                    'candidate_files_sha256': inner['candidate_files_sha256'][name], 'bindings': bound,
                    'classification': row['classification'], 'compile_outcome': 'passed',
                    'runtime_outcome': 'passed' if row['status'] == 'passed' else 'failed',
                    'expected_cases': row['expected_cases'], 'observed_cases': row['observed_cases'],
                    'assertions': assertions, 'artifacts': [report_ref, score_ref, guard_ref]}
            if name == 'T05':
                item['native_subject_assessment'] = row['t05_assessment']
                tests = values['T05/tests/eval-coverage.hoon'].decode()
                calls = re.findall(r'\(advance:eval-authorization (~[a-z]+) (~[a-z]+) ([0-9.]+) ([0-9.]+)\)', tests)
                require(len(calls) == len(row['expected_cases']) and tests.count('(expect !>') == len(calls)
                        and '~bud' not in {call[0] for call in calls}, 'Unexpected final test semantics')
                item['independent_test_semantics'] = {'behavioral_gate_calls': len(calls),
                    'actual_sender_literals': sorted({call[0] for call in calls}),
                    'source_text_matching': False, 'missing_frozen_mutant_trigger': '~bud',
                    'disposition': 'Complete native behavioral failure. Correct code passes; the frozen mutant granting ~bud survives. Later mutants still executed and were killed.'}
            tasks.append(item)
        initial = launch['input_files'][role]
        condition = {'condition': role, 'context_id': final['conditions'][role]['context_id'],
                     'model': 'gpt-6-astra', 'settings': {'reasoning_effort': 'max', 'immutable_backend_revision': None,
                         'immutable_backend_revision_observation': 'unknown', 'model_contexts_observed': len(access['model_contexts'])},
                     'input_files_sha256': {name: item['sha256'] for name, item in initial.items()},
                     'skill_files_sha256': {name: item['sha256'] for name, item in initial.items() if name.startswith('assisted/')},
                     'context_contamination': [], 'context_contamination_observation': 'No prohibited input/access observed; encrypted incoming bodies were not decrypted and full tool exposure remains.',
                     'active_seconds': timing['active_seconds'], 'infrastructure_seconds': timing['infrastructure_seconds'],
                     'tasks': tasks, 'tasks_passed': 5, 'tasks_total': 6,
                     'native_elapsed_seconds': inner['elapsed_seconds'],
                     'native_checks': len(inner['checks']), 'native_commands': len(inner['commands']),
                     'protocol_deviations': access['literal_failed_path_deviations']}
        conditions.append(condition)
        audit_roles[role] = {'timing': timing, 'access': access, 'private_status': score['status'],
                             't05_arm_count': len(inner['tasks'][4]['expected_cases']),
                             't05_outcomes': [row['outcome'] for row in inner['tasks'][4]['t05_assessment']['subjects']]}
        for area in ('input', 'candidate', 'calls', 'timing', 'feedback-attempts'):
            tree(BASE / role / area, 'actual-participant-' + area)
        tree(root, 'actual-private-score-lifecycle-and-programs')
        tree(WORK / role, 'immutable-final-candidate-snapshot')
    audit = {'protocol': 'stead.paired-v2-independent-artifact-review/1', 'reviewer': '/root/independent_review',
             'source_commit': HEAD, 'package_sha256': PACKAGE, 'classification': 'actual artifact replay and candidate semantic review; no native rerun',
             'native_executed_by_reviewer': False, 'host_test_suite_executed_by_reviewer': False,
             'source_authorship_disclosure': 'Reviewer authored the frozen evaluation package and portions of its adapter; integrator and editor reviewed those before launch. Participant solutions were independently authored in fresh contexts.',
             'status': 'comparison-complete-with-candidate-failures-and-disclosed-limits', 'parent_messages': parent,
             'conditions': audit_roles, 'resource_scope': resources,
             'issue_disposition': 'The frozen six-task comparison requirement of URB-170 is satisfied by actual complete execution and honest outcomes. Candidate failure is not missing execution. Closing the whole issue still requires its separately retained skill/license/editor/setup/negative-control acceptance evidence and final portable byte review.',
             'limits': ['One pair, one model alias and pinned toolchain; no general improvement or causal skill-effectiveness claim.',
                        'Full inherited tools remained exposed. Exact observed calls show no oracle/other-answer read; this does not prove complete context isolation.',
                        'Parent tool messages and matched acknowledgments do not decrypt incoming ciphertext or independently prove its plaintext.',
                        'One assisted invocation named a missing wrapper path, returned file-not-found, and executed no wrapper operation. This recorded typo is not evidence of a data-access bypass.',
                        'Active wall time includes compaction/delivery/observation overhead, with no retrospective adjustment.',
                        'Portable archive byte/completeness review is still required after packaging.']}
    prequal = [capture(WORK / name, 'completed-v2-reference-prequalification', 'raw/prequalification/' + name)
               for name in ('prequalification.json', 'prequalification-inner.json', 'prequalification-guard.json')]
    result = {'protocol': 'stead.skill-evaluation-result/2', 'package_version': 2, 'package_sha256': PACKAGE,
              'status': 'completed', 'conditions': conditions, 'prequalification_artifacts': prequal,
              'independent_review': {'reviewer': '/root/independent_review', 'status': audit['status'],
                                     'artifact': 'reports/independent-audit.json', 'native_execution': False},
              'limits': audit['limits'] + ['T03 type/tang projections retain native measurements; omitted full type bodies are not independently reconstructed.',
                  'T04 is pinned native Gall dispatch with explicit synthetic routing/clock, not four-process network or production authorization.',
                  'The observed tie is 5/6 each. Both T05 suites miss the frozen ~bud authorization mutation; no observed skill benefit is established.',
                  'The v1 comparison remains separately preserved and invalid/incomplete; these fresh v2 answers and scores are not v1 repairs.'],
              'source_commit': HEAD, 'comparison': {'baseline_passed': 5, 'assisted_passed': 5, 'tasks_per_condition': 6,
                  'observed_pass_count_difference': 0, 'claim_general_improvement': False},
              'phase_acceptance': False}
    schema(result, doc(REPO / 'tests/urbit/skill_evaluation/result.schema.json'), doc(REPO / 'tests/urbit/skill_evaluation/result.schema.json'))
    for root, files in source_binding['inventories'].items():
        for name, expected in files.items():
            path = REPO / root / name
            require(sha(read(path)) == expected, 'Scored source bytes changed')
            capture(path, 'exact-scored-source-input')
    kernel = doc(REPO / 'specs/urbit/toolchain.lock.json')['kernel']['directory']
    for name in ('LICENSE.txt', 'pkg/arvo/LICENSE.txt', 'pkg/base-dev/lib/test.hoon'):
        capture(REPO / '.runtime' / kernel / name, 'pinned-kernel-license-or-native-test-helper')
    for name in ('Makefile', 'LICENSE'):
        if (REPO / name).is_file():
            capture(REPO / name, 'build-or-license-source')
    tree(WORK / 'feedback', 'immutable-public-reservation-snapshot')
    tree(BASE / 'support-versions', 'preserved-superseded-evidence-support')
    tree(BASE / 'parent-deliveries', 'exact-parent-authored-deliveries-and-acks')
    tree(BASE / 'filtered-traces-safe', 'filtered-actual-child-task-trace')
    tree(REPO / '.runtime/phase01-20260926/baseline-T06-1-infrastructure', 'preserved-original-failed-public-infrastructure')
    tree(REPO / 'docs/urbit/evidence/2026-09-26/native-attempts/prequal12', 'portable-prequal12-native-evidence')
    for path in sorted(BASE.iterdir()):
        if (path.is_file() and path.suffix in ('.json', '.py', '.md', '.txt', '.log')
                and path.name not in ('portable-plan.json', 'result.json', 'independent-audit.json')):
            capture(path, 'parent-support-and-observation-record')
    require(binding == scorer.current_binding(), 'Source binding changed at final audit boundary')
    common.remotes()
    write_once(BASE / 'independent-audit.json', audit)
    write_once(BASE / 'result.json', result)
    capture(BASE / 'independent-audit.json', 'actual-independent-artifact-review', 'reports/independent-audit.json')
    capture(BASE / 'result.json', 'actual-completed-paired-result', 'reports/result.json')
    plan = {'protocol': 'stead.workflow-v2-portable-plan/1', 'source_commit': HEAD,
            'package_sha256': PACKAGE, 'members': [MEMBERS[name] for name in sorted(MEMBERS)],
            'classification': 'Actual completed v2 evidence selection; archive not yet built or reviewed'}
    require(archive.mandatory_members() <= set(MEMBERS), 'Mandatory archive selection is incomplete')
    write_once(BASE / 'portable-plan.json', plan)
    print(json.dumps({'status': audit['status'], 'members': len(MEMBERS), 'bytes': sum(row['bytes'] for row in MEMBERS.values()),
                      'result_sha256': sha(read(BASE / 'result.json')), 'audit_sha256': sha(read(BASE / 'independent-audit.json')),
                      'plan_sha256': sha(read(BASE / 'portable-plan.json')), 'archive_executed': False}, indent=2))


if __name__ == '__main__':
    main()

=/  test
::  testing utilities meant to be directly used from files in %/tests
::
|%
::  +expect-eq: compares :expected and :actual and pretty-prints the result
::
++  expect-eq
  |=  [expected=vase actual=vase]
  ^-  tang
  ::
  =|  result=tang
  ::
  =?  result  !=(q.expected q.actual)
    %+  weld  result
    ^-  tang
    :~  [%palm [": " ~ ~ ~] [leaf+"expected" (sell expected) ~]]
        [%palm [": " ~ ~ ~] [leaf+"actual  " (sell actual) ~]]
    ==
  ::
  =?  result  !(~(nest ut p.actual) | p.expected)
    %+  weld  result
    ^-  tang
    :~  :+  %palm  [": " ~ ~ ~]
        :~  [%leaf "failed to nest"]
            (~(dunk ut p.actual) %actual)
            (~(dunk ut p.expected) %expected)
    ==  ==
  result
::  +expect: compares :actual to %.y and pretty-prints anything else
::
++  expect
  |=  actual=vase
  (expect-eq !>(%.y) actual)
::  +expect-fail: kicks a trap, expecting crash. pretty-prints if succeeds
::
++  expect-fail
  |=  a=(trap)
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %|  ~
    %&  ['expected failure - succeeded' ~]
  ==
::  +expect-success: kicks a trap, expecting success; returns trace on failure
::
++  expect-success
  |=  a=(trap)
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %&  ~
    %|  ['expected success - failed' p.b]
  ==
::
::  +expect-fail-message: kicks a trap, expecting crash, compares the resulting error message
++  expect-fail-message
  |=  [msg=@t a=(trap)]
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %|  |^
        =/  =tang  (flatten +.b)
        ?:  ?=(^ (find (trip msg) tang))
          ~
        ['expected error message - not found' ~]
        ++  flatten
          |=  tang=(list tank)
          =|  res=tape
          |-  ^-  tape
          ?~  tang  res
          $(tang t.tang, res (weld ~(ram re i.tang) res))
        --
    %&  ['expected failure - succeeded' ~]
  ==
::  $a-test-chain: a sequence of tests to be run
::
::  NB: arms shouldn't start with `test-` so that `-test % ~` runs
::
+$  a-test-chain
  $_
  |?
  ?:  =(0 0)
    [%& p=*tang]
  [%| p=[tang=*tang next=^?(..$)]]
::  +run-chain: run a sequence of tests, stopping at first failure
::
++  run-chain
  |=  seq=a-test-chain
  ^-  tang
  =/  res  $:seq
  ?-  -.res
    %&  p.res
    %|  ?.  =(~ tang.p.res)
          tang.p.res
        $(seq next.p.res)
  ==
::  +category: prepends a name to an error result; passes successes unchanged
::
++  category
  |=  [a=tape b=tang]  ^-  tang
  ?:  =(~ b)  ~  :: test OK
  :-  leaf+"in: '{a}'"
  (turn b |=(c=tank rose+[~ "  " ~]^~[c]))
--

=/  eval-authorization
|%
++  advance
  |=  [sender=@p claimed=@p current=@ud expected=@ud]
  ^-  (unit @ud)
  ?.  =(~bus claimed)  ~
  ?.  =(current expected)  ~
  [~ +(current)]
--

=,  test
=>
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-outsider-spoofs-writer
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 4 4))))
++  test-owner-spoofs-writer
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 6 6))))
++  test-outsider-self-claim
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 8 8))))
++  test-owner-self-claim
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 4 4))))
++  test-outsider-claims-owner
  (expect !>(=(~ (advance:eval-authorization ~nec ~zod 7 7))))
++  test-writer-claims-outsider
  (expect !>(=([~ 6] (advance:eval-authorization ~bus ~nec 5 5))))
++  test-writer-claims-owner
  (expect !>(=([~ 4] (advance:eval-authorization ~bus ~zod 3 3))))
++  test-future-revision
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 2 3))))
++  test-writer-at-nonzero
  (expect !>(=([~ 43] (advance:eval-authorization ~bus ~bus 42 42))))
++  test-writer-claims-outsider-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~nec 9 8))))
--

=/  observed=(list [name=@t result=tang])  ~[['test-writer' test-writer] ['test-stale' test-stale] ['test-outsider-spoofs-writer' test-outsider-spoofs-writer] ['test-owner-spoofs-writer' test-owner-spoofs-writer] ['test-outsider-self-claim' test-outsider-self-claim] ['test-owner-self-claim' test-owner-self-claim] ['test-outsider-claims-owner' test-outsider-claims-owner] ['test-writer-claims-outsider' test-writer-claims-outsider] ['test-writer-claims-owner' test-writer-claims-owner] ['test-future-revision' test-future-revision] ['test-writer-at-nonzero' test-writer-at-nonzero] ['test-writer-claims-outsider-stale' test-writer-claims-outsider-stale]]
=/  failures  (skim observed |=([name=@t result=tang] !=(~ result)))
=/  passed=?  ?=(^ failures)
=/  encoded=@  (jam [2 'T05-claimed-author' %.n passed observed])
~|  [%stead-skill-t05-oversize (met 3 encoded)]
?>  (lte (met 3 encoded) 262.144)
^-  [@tas @ud]
[%skill-result encoded]

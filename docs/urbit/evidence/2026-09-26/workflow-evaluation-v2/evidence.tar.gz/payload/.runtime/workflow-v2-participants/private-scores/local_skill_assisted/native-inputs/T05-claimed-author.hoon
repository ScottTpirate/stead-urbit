=/  test
::  testing utilities meant to be directly used from files in %/tests
::
|%
::  +expect-eq: compares :expected and :actual and pretty-prints the result
::
++  expect-eq
  |=  [expected=vase actual=vase]
  ^-  tang
  ::
  =|  result=tang
  ::
  =?  result  !=(q.expected q.actual)
    %+  weld  result
    ^-  tang
    :~  [%palm [": " ~ ~ ~] [leaf+"expected" (sell expected) ~]]
        [%palm [": " ~ ~ ~] [leaf+"actual  " (sell actual) ~]]
    ==
  ::
  =?  result  !(~(nest ut p.actual) | p.expected)
    %+  weld  result
    ^-  tang
    :~  :+  %palm  [": " ~ ~ ~]
        :~  [%leaf "failed to nest"]
            (~(dunk ut p.actual) %actual)
            (~(dunk ut p.expected) %expected)
    ==  ==
  result
::  +expect: compares :actual to %.y and pretty-prints anything else
::
++  expect
  |=  actual=vase
  (expect-eq !>(%.y) actual)
::  +expect-fail: kicks a trap, expecting crash. pretty-prints if succeeds
::
++  expect-fail
  |=  a=(trap)
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %|  ~
    %&  ['expected failure - succeeded' ~]
  ==
::  +expect-success: kicks a trap, expecting success; returns trace on failure
::
++  expect-success
  |=  a=(trap)
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %&  ~
    %|  ['expected success - failed' p.b]
  ==
::
::  +expect-fail-message: kicks a trap, expecting crash, compares the resulting error message
++  expect-fail-message
  |=  [msg=@t a=(trap)]
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %|  |^
        =/  =tang  (flatten +.b)
        ?:  ?=(^ (find (trip msg) tang))
          ~
        ['expected error message - not found' ~]
        ++  flatten
          |=  tang=(list tank)
          =|  res=tape
          |-  ^-  tape
          ?~  tang  res
          $(tang t.tang, res (weld ~(ram re i.tang) res))
        --
    %&  ['expected failure - succeeded' ~]
  ==
::  $a-test-chain: a sequence of tests to be run
::
::  NB: arms shouldn't start with `test-` so that `-test % ~` runs
::
+$  a-test-chain
  $_
  |?
  ?:  =(0 0)
    [%& p=*tang]
  [%| p=[tang=*tang next=^?(..$)]]
::  +run-chain: run a sequence of tests, stopping at first failure
::
++  run-chain
  |=  seq=a-test-chain
  ^-  tang
  =/  res  $:seq
  ?-  -.res
    %&  p.res
    %|  ?.  =(~ tang.p.res)
          tang.p.res
        $(seq next.p.res)
  ==
::  +category: prepends a name to an error result; passes successes unchanged
::
++  category
  |=  [a=tape b=tang]  ^-  tang
  ?:  =(~ b)  ~  :: test OK
  :-  leaf+"in: '{a}'"
  (turn b |=(c=tank rose+[~ "  " ~]^~[c]))
--

=/  eval-authorization
|%
++  advance
  |=  [sender=@p claimed=@p current=@ud expected=@ud]
  ^-  (unit @ud)
  ?.  =(~bus claimed)  ~
  ?.  =(current expected)  ~
  [~ +(current)]
--

=,  test
=>
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-reader-denied
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 4 4))))
++  test-outsider-denied
  (expect !>(=(~ (advance:eval-authorization ~wes ~wes 4 4))))
++  test-owner-denied
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 4 4))))
++  test-reader-claim-spoof-denied
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 4 4))))
++  test-owner-claim-spoof-denied
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 4 4))))
++  test-outsider-claim-spoof-denied
  (expect !>(=(~ (advance:eval-authorization ~wes ~bus 4 4))))
++  test-writer-reader-claim-ignored
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~nec 4 4))))
++  test-writer-owner-claim-ignored
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~zod 4 4))))
++  test-writer-outsider-claim-ignored
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~wes 4 4))))
++  test-writer-nonzero-revision
  (expect !>(=([~ 256] (advance:eval-authorization ~bus ~bus 255 255))))
++  test-future-revision-denied
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 4 5))))
--

=/  observed=(list [name=@t result=tang])  ~[['test-writer' test-writer] ['test-stale' test-stale] ['test-reader-denied' test-reader-denied] ['test-outsider-denied' test-outsider-denied] ['test-owner-denied' test-owner-denied] ['test-reader-claim-spoof-denied' test-reader-claim-spoof-denied] ['test-owner-claim-spoof-denied' test-owner-claim-spoof-denied] ['test-outsider-claim-spoof-denied' test-outsider-claim-spoof-denied] ['test-writer-reader-claim-ignored' test-writer-reader-claim-ignored] ['test-writer-owner-claim-ignored' test-writer-owner-claim-ignored] ['test-writer-outsider-claim-ignored' test-writer-outsider-claim-ignored] ['test-writer-nonzero-revision' test-writer-nonzero-revision] ['test-future-revision-denied' test-future-revision-denied]]
=/  failures  (skim observed |=([name=@t result=tang] !=(~ result)))
=/  passed=?  ?=(^ failures)
=/  encoded=@  (jam [2 'T05-claimed-author' %.n passed observed])
~|  [%stead-skill-t05-oversize (met 3 encoded)]
?>  (lte (met 3 encoded) 262.144)
^-  [@tas @ud]
[%skill-result encoded]

"""Fixed, bounded offline participant file operations; never an arbitrary runner.

The model's inherited tools remain exposed. Acceptance additionally requires an
independent audit of the entire actual model tool trace, rejecting any bypass.
"""
from __future__ import annotations

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import secrets
import selectors
import stat
import subprocess
import sys
import time

BASE = Path(__file__).absolute().parent
REPO = BASE.parent.parent
ROLES = {"baseline", "local_skill_assisted", "isolation-probe"}
MAX_FILE = 65536
MAX_TOTAL = 1048576
MAX_FILES = 64
MAX_DEPTH = 16
MAX_ENTRIES = 512
MAX_CALLS = 256
MAX_REQUEST = 524288
MAX_RESPONSE = 2097152
MAX_LOG = 3 * MAX_RESPONSE
MEMORY = 134217728
NOFOLLOW = os.O_NOFOLLOW | os.O_CLOEXEC
PROTOCOL = "stead.participant-fileops/2"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "Duplicate JSON key")
        value[key] = item
    return value


def parse(raw):
    require(0 < len(raw) <= MAX_REQUEST, "Request byte bound")
    depth = 0
    quoted = escaped = False
    for char in raw:
        if quoted:
            if escaped:
                escaped = False
            elif char == 92:
                escaped = True
            elif char == 34:
                quoted = False
        elif char == 34:
            quoted = True
        elif char in (91, 123):
            depth += 1
            require(depth <= 4, "Request nesting bound")
        elif char in (93, 125):
            depth -= 1
            require(depth >= 0, "Unbalanced request")
    value = json.loads(raw, object_pairs_hook=unique,
                       parse_constant=lambda _: require(False, "Non-JSON value"))
    require(type(value) is dict, "Request must be an object")
    return value


def text_bytes(text):
    require(type(text) is str, "File content must be UTF-8 text")
    raw = text.encode("utf-8", "strict")
    require(len(raw) <= MAX_FILE and b"\0" not in raw and b"\r" not in raw,
            "File must be at most 64 KiB, NUL-free LF UTF-8")
    return raw


def parts(path, root_ok=False):
    require(type(path) is str and (path != "" or root_ok), "Relative path required")
    if path == "":
        return []
    result = path.split("/")
    require(1 <= len(result) <= MAX_DEPTH and all(
        item not in ("", ".", "..") and "\\" not in item
        and len(item.encode("utf-8", "strict")) <= 128
        and all(ord(c) >= 32 and ord(c) != 127 for c in item) for item in result),
        "Invalid path, traversal, or path bound")
    return result


def request_shape(request):
    require(type(request) is dict and type(request.get("op")) is str, "Fixed operation required")
    op = request["op"]
    fields = {"list": {"op", "area", "path"}, "read": {"op", "area", "path"},
              "hash": {"op", "area", "path"}, "write": {"op", "path", "text"},
              "copy": {"op", "source_area", "source_path", "path"},
              "remove": {"op", "path"}}
    require(op in fields and set(request) == fields[op], "Unknown operation or fields")
    parts(request["path"], op == "list")
    if op in ("list", "read", "hash"):
        require(request["area"] in ("input", "output"), "Invalid area")
    if op == "copy":
        require(request["source_area"] in ("input", "output"), "Invalid source area")
        parts(request["source_path"])
    if op == "write":
        text_bytes(request["text"])
    return op


def directory(path):
    path = Path(path).absolute()
    for item in (*reversed(path.parents), path):
        require(stat.S_ISDIR(item.lstat().st_mode), "Missing or redirected directory")
    return os.open(path, os.O_RDONLY | os.O_DIRECTORY | NOFOLLOW)


def parent_fd(root, path_parts, create=False):
    fd = os.dup(root)
    try:
        for segment in path_parts[:-1]:
            if create:
                try:
                    os.mkdir(segment, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            next_fd = os.open(segment, os.O_RDONLY | os.O_DIRECTORY | NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_file(root, path):
    path_parts = parts(path)
    parent = parent_fd(root, path_parts)
    try:
        fd = os.open(path_parts[-1], os.O_RDONLY | NOFOLLOW, dir_fd=parent)
        try:
            info = os.fstat(fd)
            require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= MAX_FILE,
                    "Only bounded unlinked regular files are allowed")
            raw = os.read(fd, MAX_FILE + 1)
            require(len(raw) == info.st_size, "File changed or exceeded bound")
            require(text_bytes(raw.decode("utf-8", "strict")) == raw, "Noncanonical text bytes")
            return raw
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def inventory(roots):
    rows = []
    count = total = 0

    def walk(area, fd, prefix):
        nonlocal count, total
        # dup()/scandir(fd) share a directory stream offset. A new openat file
        # description is required for every complete before/after inventory.
        scan_fd = os.open(".", os.O_RDONLY | os.O_DIRECTORY | NOFOLLOW, dir_fd=fd)
        try:
            with os.scandir(scan_fd) as entries:
                for entry in entries:
                    require(len(rows) < MAX_ENTRIES, "Workspace entry bound")
                    path = "/".join((*prefix, entry.name))
                    path_parts = parts(path)
                    info = entry.stat(follow_symlinks=False)
                    if stat.S_ISDIR(info.st_mode):
                        rows.append({"area": area, "path": path, "kind": "directory"})
                        child = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | NOFOLLOW, dir_fd=fd)
                        try:
                            walk(area, child, path_parts)
                        finally:
                            os.close(child)
                    else:
                        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "Links and special files forbidden")
                        raw = read_file(roots[area], path)
                        count += 1
                        total += len(raw)
                        require(count <= MAX_FILES and total <= MAX_TOTAL, "Workspace aggregate bound")
                        rows.append({"area": area, "path": path, "kind": "file",
                                     "bytes": len(raw), "sha256": digest(raw)})
        finally:
            os.close(scan_fd)
    for area, fd in roots.items():
        walk(area, fd, [])
    return sorted(rows, key=lambda row: (row["area"], row["path"]))


def mutation_data(request, roots):
    op = request_shape(request)
    if op == "write":
        return text_bytes(request["text"])
    if op == "copy":
        return read_file(roots[request["source_area"]], request["source_path"])
    return None


def operate(request, roots, before, allowance):
    op = request_shape(request)
    raw = mutation_data(request, roots)
    path = request["path"]
    rows = {(row["area"], row["path"]): row for row in before}
    result = {"op": op, "path": path}
    if raw is not None:
        require(len(raw) == allowance, "Mutation differs from reserved byte budget")
        path_parts = parts(path)
        previous = rows.get(("output", path))
        require(previous is None or previous["kind"] == "file", "Destination is not a file")
        additions = sum(("output", "/".join(path_parts[:i])) not in rows
                        for i in range(1, len(path_parts) + 1))
        require(len(rows) + additions <= MAX_ENTRIES, "Workspace entry bound")
        require(sum(row["kind"] == "file" for row in before) + int(previous is None) <= MAX_FILES,
                "Workspace file count bound")
        require(sum(row.get("bytes", 0) for row in before) - (previous or {}).get("bytes", 0)
                + len(raw) <= MAX_TOTAL, "Workspace aggregate byte bound")
        parent = parent_fd(roots["output"], path_parts, create=True)
        temporary = ".fileops-" + secrets.token_hex(16)
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | NOFOLLOW, 0o600, dir_fd=parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(raw)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, path_parts[-1], src_dir_fd=parent, dst_dir_fd=parent)
                os.fsync(parent)
            finally:
                try:
                    os.unlink(temporary, dir_fd=parent)
                except FileNotFoundError:
                    pass
        finally:
            os.close(parent)
        result.update(bytes=len(raw), sha256=digest(raw))
    elif op == "remove":
        raw = read_file(roots["output"], path)
        parent = parent_fd(roots["output"], parts(path))
        try:
            os.unlink(parts(path)[-1], dir_fd=parent)
            os.fsync(parent)
        finally:
            os.close(parent)
        result.update(removed_bytes=len(raw), removed_sha256=digest(raw))
    elif op == "list":
        require(path == "" or rows.get((request["area"], path), {}).get("kind") == "directory",
                "List target must be a directory")
        result["entries"] = [row for row in before if row["area"] == request["area"]
                             and (not path or row["path"].startswith(path + "/"))]
    else:
        raw = read_file(roots[request["area"]], path)
        result.update(bytes=len(raw), sha256=digest(raw))
        if op == "read":
            result["text"] = raw.decode("utf-8")
    after = inventory(roots)
    after_rows = {(row["area"], row["path"]): row for row in after}
    if op in ("copy", "write"):
        require(after_rows.get(("output", path)) == {"area": "output", "path": path,
                "kind": "file", "bytes": result["bytes"], "sha256": result["sha256"]},
                "Written target missing or changed in complete post-state")
    elif op == "remove":
        require(("output", path) not in after_rows, "Removed target remains in post-state")
    result.update(before_sha256=digest(encoded(before)), after_sha256=digest(encoded(after)))
    return result


def emit(value):
    raw = encoded(value) + b"\n"
    require(len(raw) <= MAX_RESPONSE, "Response bound")
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()


def child():
    roots = {area: directory("/" + area) for area in ("input", "output")}
    emit({"protocol": PROTOCOL, "ready": True, "affinity": sorted(os.sched_getaffinity(0))})
    try:
        envelope = parse(sys.stdin.buffer.readline(MAX_REQUEST + 1))
        require(set(envelope) == {"request", "before_sha256", "allowance"}
                and type(envelope["allowance"]) is int and 0 <= envelope["allowance"] <= MAX_FILE,
                "Trusted envelope required")
        before = inventory(roots)
        require(digest(encoded(before)) == envelope["before_sha256"], "Workspace changed before admission")
        result = operate(envelope["request"], roots, before, envelope["allowance"])
        emit({"protocol": PROTOCOL, "status": "passed", "result": result})
    except BaseException as error:
        emit({"protocol": PROTOCOL, "status": "failed", "error": type(error).__name__ + ": " + str(error)[:500]})
    # Remain alive so the host can explicitly stop and verify its own scope.
    sys.stdin.buffer.read(1)
    return 0


def control(args, timeout=5):
    result = subprocess.run(args, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout)
    require(len(result.stdout) <= 16384 and len(result.stderr) <= 16384, "Control output bound")
    return {"argv": args, "exit": result.returncode,
            "stdout": result.stdout.decode("utf-8", "replace"), "stderr": result.stderr.decode("utf-8", "replace")}


def properties(unit):
    result = control(["systemctl", "--user", "show", unit, "--property=ControlGroup,ActiveState,LoadState,RuntimeMaxUSec"])
    require(result["exit"] == 0, "Cannot inspect owned scope")
    return result, dict(line.split("=", 1) for line in result["stdout"].splitlines() if "=" in line)


def scope_readback(unit, cpu):
    observation, prop = properties(unit)
    group = prop.get("ControlGroup", "")
    require(group.startswith("/user.slice/") and group.endswith("/" + unit)
            and ".." not in group.split("/") and prop.get("ActiveState") == "active"
            and prop.get("LoadState") == "loaded" and prop.get("RuntimeMaxUSec") == "30s",
            "Wrong active scope or deadline")
    root = Path("/sys/fs/cgroup" + group)
    values = {name: (root / name).read_text().strip() for name in
              ("cpu.max", "memory.max", "memory.swap.max", "pids.max", "cgroup.procs", "cgroup.events")}
    require(values["cpu.max"] == "5000 10000" and values["memory.max"] == str(MEMORY)
            and values["memory.swap.max"] == "0" and values["pids.max"] == "16",
            "Actual cgroup limits do not match requested limits")
    pids = [int(value) for value in values["cgroup.procs"].split()]
    affinity = {str(pid): sorted(os.sched_getaffinity(pid)) for pid in pids}
    require(pids and all(value == [cpu] for value in affinity.values()), "Actual CPU affinity mismatch")
    return {"systemd": observation, "properties": prop, "files": values, "affinity": affinity, "path": str(root)}


def frame(proc, limit, timeout, diagnostic):
    output = bytearray()
    deadline = time.monotonic() + timeout
    with selectors.DefaultSelector() as selector:
        selector.register(proc.stdout, selectors.EVENT_READ, "stdout")
        selector.register(proc.stderr, selectors.EVENT_READ, "stderr")
        while True:
            require(time.monotonic() < deadline, "Trusted child response timeout")
            for key, _ in selector.select(max(0, deadline - time.monotonic())):
                raw = os.read(key.fileobj.fileno(), 65536)
                if key.data == "stderr":
                    diagnostic.extend(raw)
                    require(len(diagnostic) <= 16384, "Diagnostic output bound")
                    if not raw:
                        selector.unregister(key.fileobj)
                    continue
                require(raw, "Trusted child ended before its response")
                output.extend(raw)
                require(len(output) <= limit, "Trusted child frame bound")
                if b"\n" in output:
                    line, tail = output.split(b"\n", 1)
                    require(not tail, "Unexpected additional child output")
                    return json.loads(line, object_pairs_hook=unique)


def cleanup(proc, unit, known_group):
    result = {"unit": unit, "verified": False}
    try:
        result["stop"] = control(["systemctl", "--user", "stop", unit])
        require(result["stop"]["exit"] == 0, "Owned scope stop failed")
        proc.wait(timeout=5)
        result["process"] = {"pid": proc.pid, "returncode": proc.returncode, "reaped": proc.poll() is not None}
        result["systemd"], prop = properties(unit)
        result["properties"] = prop
        require(prop.get("ActiveState") == "inactive" and prop.get("ControlGroup", "") == "",
                "Owned scope remains active")
        require(known_group is not None, "No observed cgroup identity for cleanup")
        path = Path(known_group)
        require(path.name == unit and path.is_relative_to("/sys/fs/cgroup/user.slice"), "Wrong cleanup group")
        if path.exists():
            result["final_procs"] = (path / "cgroup.procs").read_text().strip()
            result["final_events"] = (path / "cgroup.events").read_text().strip()
            require(not result["final_procs"] and "populated 0" in result["final_events"].splitlines(),
                    "Owned cgroup still populated")
        else:
            result["cgroup_removed"] = True
        result["verified"] = result["process"]["reaped"]
    except BaseException as error:
        result["error"] = type(error).__name__ + ": " + str(error)[:500]
        # Best-effort containment is recorded, never substituted for verification.
        try:
            result["retry_stop"] = control(["systemctl", "--user", "stop", unit])
        except BaseException as retry:
            result["retry_error"] = str(retry)[:500]
        if proc.poll() is None:
            proc.kill()
        try:
            proc.wait(timeout=5)
            result["fallback_reaped"] = proc.poll() is not None
        except subprocess.TimeoutExpired:
            result["fallback_reaped"] = False
    return result


def immutable(fd, name, value):
    raw = encoded(value) + b"\n"
    require(len(raw) <= MAX_LOG, "Call log bound")
    out = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | NOFOLLOW, 0o400, dir_fd=fd)
    with os.fdopen(out, "wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.fsync(fd)


def history(fd):
    names = []
    with os.scandir(fd) as entries:
        for entry in entries:
            require(len(names) < MAX_CALLS * 2 + 512, "Call directory bound")
            names.append(entry.name)
    starts = [name for name in names if name.startswith("fileops-v2-") and name.endswith(".start.json")]
    require(len(starts) < MAX_CALLS, "Condition call count bound")
    charged = 0
    for name in starts:
        final = name.removesuffix(".start.json") + ".finish.json"
        require(final in names, "Prior call has no verified completion; independent recovery required")
        for item in (name, final):
            source = os.open(item, os.O_RDONLY | NOFOLLOW, dir_fd=fd)
            try:
                info = os.fstat(source)
                require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= MAX_LOG
                        and not info.st_mode & 0o222, "Call history must be immutable regular files")
                record = json.loads(os.read(source, MAX_LOG + 1), object_pairs_hook=unique)
            finally:
                os.close(source)
            require(record.get("protocol") == PROTOCOL, "Wrong prior call protocol")
            if item == name:
                cost = record.get("reserved_bytes")
                require(type(cost) is int and 0 <= cost <= MAX_FILE, "Invalid prior byte reservation")
                charged += cost
            else:
                require(record.get("cleanup", {}).get("verified") is True,
                        "Prior call cleanup unverified; independent recovery required")
    require(charged <= MAX_TOTAL, "Cumulative mutation byte bound")
    return charged


def main():
    if sys.argv == ["/runner.py", "--child"]:
        return child()
    require(len(sys.argv) == 2 and sys.argv[1] in ROLES,
            "usage: workspace_tool.py CONDITION < fixed-operation.json")
    remote = control(["git", "-C", str(REPO), "remote", "-v"])
    require(remote["exit"] == 0 and "origin\thttps://github.com/ScottTpirate/stead-urbit.git (push)" in remote["stdout"]
            and "upstream\tDISABLED_UPSTREAM_PUSH (push)" in remote["stdout"], "Wrong derivative remotes")
    role = sys.argv[1]
    root = BASE / role
    fds = [directory(root), directory(root / "input"), directory(root / "candidate"), directory(root / "calls")]
    parent, input_fd, output_fd, calls_fd = fds
    lock = os.open(".fileops-v2.lock", os.O_RDWR | os.O_CREAT | NOFOLLOW, 0o600, dir_fd=parent)
    fds.append(lock)
    require(stat.S_ISREG(os.fstat(lock).st_mode) and os.fstat(lock).st_nlink == 1, "Invalid lock")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    charged = history(calls_fd)
    raw = sys.stdin.buffer.read(MAX_REQUEST + 1)
    token = str(time.time_ns()) + "-" + secrets.token_hex(6)
    unit = "stead-fileops-" + role.replace("_", "-") + "-" + token + ".scope"
    name = "fileops-v2-" + token
    cpu = max(os.sched_getaffinity(0))
    source_fd = os.open(__file__, os.O_RDONLY | NOFOLLOW)
    fds.append(source_fd)
    source = os.read(source_fd, 131073)
    require(len(source) <= 131072 and stat.S_ISREG(os.fstat(source_fd).st_mode)
            and os.fstat(source_fd).st_nlink == 1, "Trusted helper source bound")
    try:
        request = parse(raw)
        roots = {"input": input_fd, "output": output_fd}
        before = inventory(roots)
        mutation = mutation_data(request, roots)
        cost = len(mutation) if mutation is not None else 0
        require(charged + cost <= MAX_TOTAL, "Cumulative mutation byte bound")
    except (ValueError, OSError, UnicodeError) as error:
        immutable(calls_fd, name + ".start.json", {
            "protocol": PROTOCOL, "condition": role, "unit": None,
            "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "request_hex": raw.hex(), "reserved_bytes": 0, "previous_reserved_bytes": charged,
            "wrapper_sha256": digest(source), "scope": "Rejected before sandbox/request admission"})
        rejection = {"protocol": PROTOCOL, "condition": role, "unit": None, "status": "failed",
                     "admitted": False, "error": type(error).__name__ + ": " + str(error)[:500],
                     "cleanup": {"verified": True, "not_started": True}}
        immutable(calls_fd, name + ".finish.json", rejection)
        emit({**rejection, "call": name})
        for fd in reversed(fds):
            os.close(fd)
        return 1
    argv = ["systemd-run", "--user", "--scope", "--quiet", "--unit=" + unit,
            "-p", "RuntimeMaxSec=30s", "-p", "CPUQuota=50%", "-p", "CPUQuotaPeriodSec=10ms",
            "-p", "MemoryMax=128M", "-p", "MemorySwapMax=0", "-p", "TasksMax=16", "--",
            "taskset", "-c", str(cpu), "bwrap", "--unshare-all", "--new-session", "--die-with-parent",
            "--ro-bind", "/usr", "/usr", "--symlink", "usr/bin", "/bin", "--symlink", "usr/lib", "/lib",
            "--symlink", "usr/lib", "/lib64", "--ro-bind", "/proc/self/fd/" + str(source_fd), "/runner.py",
            "--ro-bind", "/proc/self/fd/" + str(input_fd), "/input",
            "--bind", "/proc/self/fd/" + str(output_fd), "/output", "--proc", "/proc", "--dev", "/dev",
            "--dir", "/tmp", "--dir", "/etc", "--chdir", "/output", "--clearenv",
            "--setenv", "LANG", "C.UTF-8", "--", "/usr/bin/python3", "-I", "-B", "-S", "/runner.py", "--child"]
    started = {"protocol": PROTOCOL, "condition": role, "unit": unit,
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "request_hex": raw.hex(), "reserved_bytes": cost, "previous_reserved_bytes": charged,
               "before": before, "wrapper_sha256": digest(source), "argv": argv,
               "scope": "Fixed offline file operations; full model tool-trace bypass audit still required."}
    immutable(calls_fd, name + ".start.json", started)
    record = {"protocol": PROTOCOL, "condition": role, "unit": unit, "status": "failed", "admitted": False}
    proc = None
    diagnostic = bytearray()
    observed_group = None
    begun = time.monotonic()
    try:
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                bufsize=0, pass_fds=(source_fd, input_fd, output_fd))
        record["ready"] = frame(proc, 4096, 8, diagnostic)
        require(record["ready"] == {"protocol": PROTOCOL, "ready": True, "affinity": [cpu]}, "Wrong ready handshake")
        # Capture cgroup identity even when its limits later fail admission.
        record["initial_systemd"], initial = properties(unit)
        group = initial.get("ControlGroup", "")
        if group.startswith("/user.slice/") and group.endswith("/" + unit) and ".." not in group.split("/"):
            observed_group = "/sys/fs/cgroup" + group
        record["limits"] = scope_readback(unit, cpu)
        envelope = encoded({"request": request, "before_sha256": digest(encoded(before)), "allowance": cost}) + b"\n"
        require(len(envelope) <= MAX_REQUEST, "Trusted request envelope bound")
        record["admitted"] = True
        remaining = memoryview(envelope)
        while remaining:
            written = os.write(proc.stdin.fileno(), remaining)
            require(written > 0, "Trusted request write failed")
            remaining = remaining[written:]
        record["response"] = frame(proc, MAX_RESPONSE, 12, diagnostic)
        require(record["response"].get("protocol") == PROTOCOL and record["response"].get("status") == "passed",
                "Trusted file operation failed")
        record["after"] = inventory(roots)
        require([row for row in before if row["area"] == "input"]
                == [row for row in record["after"] if row["area"] == "input"],
                "Read-only input changed during operation")
        require(record["response"]["result"]["after_sha256"] == digest(encoded(record["after"])),
                "Workspace changed after trusted operation")
        record["status"] = "passed"
    except BaseException as error:
        record["error"] = type(error).__name__ + ": " + str(error)[:500]
    finally:
        record["cleanup"] = cleanup(proc, unit, observed_group) if proc is not None else {
            "verified": True, "not_started": True}
        if not record["cleanup"]["verified"]:
            record["status"] = "failed"
        record["stderr_hex"] = bytes(diagnostic).hex()
        record["elapsed_seconds"] = time.monotonic() - begun
        immutable(calls_fd, name + ".finish.json", record)
        for fd in reversed(fds):
            os.close(fd)
    emit({"protocol": PROTOCOL, "status": record["status"], "admitted": record["admitted"],
          "response": record.get("response"), "error": record.get("error"),
          "cleanup_verified": record["cleanup"]["verified"], "call": name})
    return 0 if record["status"] == "passed" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, json.JSONDecodeError, UnicodeError) as error:
        print(type(error).__name__ + ": " + str(error)[:500], file=sys.stderr)
        raise SystemExit(1)

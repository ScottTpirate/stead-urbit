# Version 2 evidence preparation and bounded criteria review

Prepared by `/root/independent_review` on 2026-09-26 at frozen source
`0d877cff4319de8d437f0da58d4518535f758c36`. This is a parent-only preparation
record, outside participant inputs. It is not a result, phase approval, or an
assertion that either exporter has run. Origin fetch/push was verified as
`https://github.com/ScottTpirate/stead-urbit.git`; upstream push remains disabled.

## Prepared helpers

| File | SHA-256 | Preparation result |
| --- | --- | --- |
| `export_parent_deliveries.py` | `e5527fae435fa7e27642d9409214b4400e0ae987a7da02e55fea531a277e04cd` | AST parsed; unexecuted |
| `export_trial_trace_safe.py` | `680591b8c5098e8c96bef0ccefc27f7998947d0f6236a1fac4f9e4c602637b8e` | AST parsed; unexecuted |
| `archive_v2_evidence.py` | `8a21e767042fbc8b7a95b3edfc4a5c993b8e7bb2fcb0067f474b565bab27be03` | AST parsed; unexecuted |

The previous `export_trial_trace.py` is preserved unchanged at
`9fb140d41725ea299af45ec1b03ee97c199b41075505f577360bfc95b8177976`.
No tracked source, frozen support helper, corpus, input or candidate was edited.
No test, native run, participant messaging, candidate read or live child-rollout
read was performed. Preparation inspected only the parent selected-tool record
shapes and historical v1 exported field names, in CPU50%/10ms scopes on CPU19.
That inspection was not a final trace export or a behavioral test.

The parent exporter selects only actual `spawn_agent`, `followup_task` and
`send_message` calls targeting the exact two v2 task names/canonical paths or
their observed context IDs, plus actual matching call outputs. It preserves
raw argument/output strings and source line hashes/positions, omitting unrelated
records and internal metadata. The safe child exporter uses explicit field
allowlists for tool calls/results and visible assistant commentary/final text.
It keeps incoming author/recipient/message identity plus type/size/hash
descriptors; it copies neither incoming content nor internal passthrough.
Neither exporter decrypts anything or equates an acknowledgment with receipt.

Both require `final-submissions.json` to attest that both participants stopped
and no further turns are authorized, exact observed child IDs, and closed
per-role final clocks. Both hash stable source snapshots twice before writing
new immutable output directories. A rolling source or incomplete call/ack pair
fails instead of becoming a finalized export. Source-snapshot hashes cover only
the recorded byte length; subsequent root records are outside that snapshot.

## Final execution sequence

After both final submissions are recorded, run the two exporters serially from
the repository root. Do not run the preserved old exporter for publication.

```sh
systemd-run --user --scope --quiet -p CPUQuota=50% -p CPUQuotaPeriodSec=10ms -p AllowedCPUs=19 taskset -c 19 python3 -B -X pycache_prefix=/tmp/stead-v2-evidence-export-cache .runtime/workflow-v2-participants/export_parent_deliveries.py --finalize
systemd-run --user --scope --quiet -p CPUQuota=50% -p CPUQuotaPeriodSec=10ms -p AllowedCPUs=19 taskset -c 19 python3 -B -X pycache_prefix=/tmp/stead-v2-evidence-export-cache .runtime/workflow-v2-participants/export_trial_trace_safe.py --finalize
```

Outputs are `parent-deliveries/{parent.jsonl,manifest.json}` and
`filtered-traces-safe/{baseline.jsonl,local_skill_assisted.jsonl,manifest.json}`.
Retain full exposed-tool limitations and actual per-turn model settings;
immutable backend revision remains unknown. Audit each tool call against its
literal permitted wrapper invocation, immutable call ledger and final input/
candidate hashes. Reconcile parent message arguments/acks against launch,
feedback delivery, pause/resume/final clocks and child delivery metadata.
Unavailable incoming plaintext remains unavailable. Do not claim complete
context isolation from tool history or ciphertext hashes.

After both one-shot private score lifecycles finish, prepare an exact selection
plan beside the helpers using protocol `stead.workflow-v2-portable-plan/1`,
the current source/package identities, and nonempty `members`. Each member has
`path` (repository-relative), `sha256`, `bytes`, and `classification`; optional
`expose_as` must be under `raw/` or `reports/`, with optional boolean `gzip`.
Compute entries from actual current files; this handoff deliberately supplies
no invented future inventory, score, outcome, guard or review.

Include all actual parent support/observation/version records, both immutable
input/candidate/call/timing/feedback-attempt ledgers, final snapshots, every
public reservation (including failed infrastructure), actual native inner
reports and generated programs, owned guard reports/events/source contexts,
exact scored source closure/pins/licenses, and the prequal12 receipts. Include
the new filtered exports and all final clock files. Explicitly preserve every
partial native checkpoint and distinct infrastructure symptom. Make raw public,
private and prequalification reports accessible through `expose_as` where useful.
Byte selection completeness still requires independent review.

```sh
systemd-run --user --scope --quiet -p CPUQuota=50% -p CPUQuotaPeriodSec=10ms -p AllowedCPUs=19 taskset -c 19 python3 -B -X pycache_prefix=/tmp/stead-v2-evidence-archive-cache .runtime/workflow-v2-participants/archive_v2_evidence.py --finalize --plan .runtime/workflow-v2-participants/portable-plan.json
```

The archive helper writes create-once `portable-bundle/` with a deterministic
archive, exact member index, selected accessible reports and an outcome-neutral
index. Output refs are relative to the index directory so reviewed bytes can
be promoted together. Archive members preserve original repository-relative
paths under `payload/`; extract only into an empty separate directory. The
helper verifies byte identity, not task/phase acceptance. Author the actual
result against frozen `result.schema.json` only from observed final scores and
review. Validate all five T05 subjects and every arm even for failed tasks;
distinguish compile failure, runtime behavioral failure, infrastructure, invalid
or missing cases. Do not infer a full Clay-tree hash from candidate projections.
No v1 candidate, score, result assertion, timing adjustment or efficacy claim
is carried into v2.

## Public infrastructure reservation disposition

The frozen README lines 48–55 and protocol budgets permit at most three public
submissions per task, distinguish infrastructure from candidate behavior, and
retain native/guard wait as infrastructure time. The already-frozen broker
counts failed reservations (header and `reserve_attempt`, lines 195–208), and
requires resolved ownership/cleanup before another reservation.

Actual baseline T06/1 retained `status=failed`, `native_execution=pending`,
`JSONDecodeError`, `ownership_resolved=true`, and `cleanup_completed=true`, with
run `51d3baf51e65c77f4548177b95a4dd14`. Its outer guard independently reports
`failed`, exit 1, launched true, and `Thermal ceiling reached`. Root separately
reported the retained inner task T06 `not_run`, cleanup bus exit -11 and Vere
startup `_lord_plea_ripe` SIGSEGV. These are two observed infrastructure failures;
the review does not attribute the segfault to temperature. Preserve original
record values; derived classification is infrastructure-interrupted, not
not-launched or a candidate pass/fail.

A new unchanged-snapshot reservation as T06 attempt 2, after preservation,
resolved stop/reset and unchanged cold guard admission, is within the same
pending public feedback request and consumes the second allowance. No invented
feedback or participant repair/resume is needed for the failed first attempt.
The private one-shot no-rerun rule is distinct. Keep conservative charged active
time, including compaction/delivery overhead; no retrospective clock subtraction.

## Scoped Phase 1 recovery wording correction

Read-only review of the controlling current criteria found that new
`NATIVE_CORE.md:73–75,94–96` language declaring controlled abrupt-crash recovery
a required current Phase 1 gate is an inferred addition. The controlling
`MASTER_BUILD_DIRECTIVE.md:120` requires restart and recover;
`ECOSYSTEM_PLAN.md:18` and URB-040 backlog acceptance require restart persistence.
Live issue [#7](https://github.com/ScottTpirate/stead-urbit/issues/7), read on
2026-09-26, explicitly requires **cold restart** and separates restart from
upgrade, without requiring abrupt termination or crash-window injection.

Frozen `specs/urbit/v2/qualification-gate.json:793–798` explicitly defines
`warm-home-restart` as graceful fenced process replacement retaining revisions,
policy and canonical Git bytes, **not abrupt crash**.
`CONTRACT_AMENDMENT_2.md:106–108` treats graceful restart and abrupt recovery as
separate assertions; it does not assign both to the current frozen gate.
`PHASE1_THREAT_TEST_MAP.md:20` says warm restart is not crash restore and assigns
broader recovery boundaries to separate issues. The directive's broader crash
and migration invariants remain valid; a current scoped restart pass does not
establish those later/broader behaviors.

Recommended documentation correction: current save/load and fenced process
restart are required separate checks; abrupt-crash recovery is a separate
unqualified assertion, not established by the current 66-native-obligation
bundle. Remove the inferred “required controlled” / “not deferred from Phase 1”
phrases. Do not alter any gate or schema, relabel a graceful restart as abrupt,
or claim an abrupt lane passed. Do not invent a specific future milestone for
it where no controlling assignment exists.

Issue #7's cold-restart wording still requires exact native evidence that the
old process exited, a new PID started against the retained pier, and accepted
content/revision, policy and canonical Git bytes survived. The code path in
`core_test.py:196–205` performs shutdown/old-exit observation/launch/wait and
records old/new PIDs; only its actual completed current-source artifact can
establish that assertion. An in-process load or planned replacement is not that
evidence. This source review does not approve pending or thermally interrupted
core execution. Root will make the scoped documentation correction after the
frozen native work, with a new attributed correction preserving earlier
hash-bound review records.

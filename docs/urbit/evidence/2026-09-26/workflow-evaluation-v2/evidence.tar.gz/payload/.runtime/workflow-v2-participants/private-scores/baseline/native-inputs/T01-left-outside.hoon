=>
|%
++  add-u8
  |=  [left=@ud right=@ud]
  ^-  (unit @ud)
  ?:  (gth left 255)  ~
  ?:  (gth right 255)  ~
  =/  total=@ud  (add left right)
  ?:  (gth total 255)  ~
  [~ total]
--

=/  actual  (add-u8 [256 0])
?>  =(~ actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

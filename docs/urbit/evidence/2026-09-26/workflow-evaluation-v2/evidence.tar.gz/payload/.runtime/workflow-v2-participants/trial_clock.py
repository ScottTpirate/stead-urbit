"""Parent-only observed trial timing; actual transcript/idle audit remains required."""
import datetime,hashlib,json,os,pathlib,re,stat,subprocess,sys,time
sys.dont_write_bytecode=True
BASE=pathlib.Path(__file__).absolute().parent
sys.path.insert(0,str(BASE.parent.parent/'scripts/urbit'))
from execution_policy import directory_fd
LIMIT=1800_000_000_000

def pairs(rows):
 result={}
 for key,value in rows:
  if key in result: raise ValueError('Duplicate JSON key')
  result[key]=value
 return result

def transition(state,active,begin,action,stamp):
 assert type(stamp) is int and stamp>=0
 charged=active+(stamp-begin if state=='running' else 0)
 assert charged>=active
 if action=='start': assert state=='new'
 elif action=='resume': assert state=='paused' and active<LIMIT
 elif action=='pause': assert state=='running'
 elif action in ('final','cutoff'): assert state in ('running','paused')
 else: raise ValueError('Invalid event')
 after='running' if action in ('start','resume') else ('paused' if action=='pause' else 'closed')
 return after,charged,stamp if after=='running' else None

def replay(rows,role,boot,now):
 state='new';active=0;begin=None;previous=None;prior=0
 for index,raw in enumerate(rows):
  row=json.loads(raw,object_pairs_hook=pairs)
  assert row['protocol']=='stead.observed-trial-timing/1' and row['condition']==role and row['boot_id']==boot
  assert type(row['number']) is int and row['number']==index+1 and row['previous_sha256']==previous
  stamp=row['monotonic_ns'];assert type(stamp) is int and prior<=stamp<=now
  assert row['state_before']==state and type(row['active_before_ns']) is int and row['active_before_ns']==active
  after,charged,next_begin=transition(state,active,begin,row['event'],stamp)
  assert row['state_after']==after and type(row['active_after_ns']) is int and row['active_after_ns']==charged
  assert (row['active_interval_started_ns'] is None if next_begin is None else type(row['active_interval_started_ns']) is int and row['active_interval_started_ns']==next_begin)
  state,active,begin=after,charged,next_begin;prior=stamp;previous=hashlib.sha256(raw).hexdigest()
 return state,active,begin,previous

def main():
 role,action=sys.argv[1:3]
 assert role in ('baseline','local_skill_assisted') and action in ('start','pause','resume','final','cutoff','status')
 assert subprocess.check_output(['git','remote','get-url','--push','origin'],cwd=BASE.parent.parent,text=True).strip()=='https://github.com/ScottTpirate/stead-urbit.git'
 boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert re.fullmatch('[0-9a-f-]{36}',boot)
 now=time.monotonic_ns();rows=[];timing=None
 with directory_fd(BASE/role) as parent:
  try: timing=os.open('timing',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
  except FileNotFoundError:
   if action!='status':
    os.mkdir('timing',0o700,dir_fd=parent)
    timing=os.open('timing',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
  try:
   if timing is not None:
    info=os.fstat(timing);assert stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
    names=sorted(os.listdir(timing));assert len(names)<256
    for index,name in enumerate(names):
     assert name=='%04d.json'%(index+1)
     fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=timing)
     with os.fdopen(fd,'rb') as stream:
      info=os.fstat(stream.fileno())
      assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and stat.S_IMODE(info.st_mode)==0o400 and info.st_uid==os.geteuid() and info.st_size<=8192
      raw=stream.read(8193);assert len(raw)<=8192;rows.append(raw)
   state,active,begin,previous=replay(rows,role,boot,now)
   elapsed=active+(now-begin if state=='running' else 0);assert elapsed>=active
   summary={'condition':role,'state':state,'active_seconds':elapsed/1e9,'remaining_seconds':max(0,(LIMIT-elapsed)/1e9),'over_budget':elapsed>LIMIT}
   if action=='status': print(json.dumps(summary));return
   after,charged,next_begin=transition(state,active,begin,action,now)
   record={'protocol':'stead.observed-trial-timing/1','number':len(rows)+1,'condition':role,'event':action,
    'boot_id':boot,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic_ns':now,
    'state_before':state,'state_after':after,'active_before_ns':active,'active_after_ns':charged,
    'active_interval_started_ns':next_begin,'previous_sha256':previous,'reference':sys.argv[3] if len(sys.argv)>3 else '',
    'definition':'Parent observation: delivery before launch/resume through confirmed idle/final/cutoff; wait excluded only while paused. Transcript reconciliation and parent cutoff enforcement required.'}
   raw=(json.dumps(record,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<=8192
   name='%04d.json'%(len(rows)+1)
   fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o400,dir_fd=timing)
   with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
   os.fsync(timing);print(json.dumps(dict(summary,state=after,event=action,record=str(BASE/role/'timing'/name))))
  finally:
   if timing is not None:os.close(timing)

if __name__=='__main__':main()

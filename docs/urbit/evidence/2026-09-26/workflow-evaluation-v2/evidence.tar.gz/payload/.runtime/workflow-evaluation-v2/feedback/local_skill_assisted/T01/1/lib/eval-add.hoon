|%
++  add-u8
  |=  [left=@ud right=@ud]
  ^-  (unit @ud)
  ?.  (lte left 255)  ~
  ?.  (lte right 255)  ~
  =/  total  (add left right)
  ?.  (lte total 255)  ~
  [~ total]
--

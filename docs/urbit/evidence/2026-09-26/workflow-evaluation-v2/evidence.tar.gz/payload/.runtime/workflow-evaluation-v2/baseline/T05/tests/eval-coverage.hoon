/+  *test, eval-authorization
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-outsider-spoofs-writer
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 4 4))))
++  test-owner-spoofs-writer
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 6 6))))
++  test-outsider-self-claim
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 8 8))))
++  test-owner-self-claim
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 4 4))))
++  test-outsider-claims-owner
  (expect !>(=(~ (advance:eval-authorization ~nec ~zod 7 7))))
++  test-writer-claims-outsider
  (expect !>(=([~ 6] (advance:eval-authorization ~bus ~nec 5 5))))
++  test-writer-claims-owner
  (expect !>(=([~ 4] (advance:eval-authorization ~bus ~zod 3 3))))
++  test-future-revision
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 2 3))))
++  test-writer-at-nonzero
  (expect !>(=([~ 43] (advance:eval-authorization ~bus ~bus 42 42))))
++  test-writer-claims-outsider-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~nec 9 8))))
--

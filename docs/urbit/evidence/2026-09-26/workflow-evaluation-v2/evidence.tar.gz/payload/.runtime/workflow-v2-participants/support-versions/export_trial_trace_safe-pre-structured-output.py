"""Final-only, explicit-field child trace export for the fresh v2 pair.

Preserves the old export_trial_trace.py unchanged. No live child trace is read
by preparation of this file. Run --finalize after both final clocks close, in
CPU50%/10ms on CPU19. Incoming message content is described by type/size/hash,
not copied or decrypted. Tool input/output and visible assistant text remain
actual task evidence and still require independent privacy/protocol review.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
import export_parent_deliveries as common

BASE, REPO = common.BASE, common.REPO
DEST = BASE / 'filtered-traces-safe'
SESSIONS = Path('/home/skilgore/.codex/sessions/2026/09/26')
MAX_ROLLOUT = 32 * 1024 * 1024
MAX_LINE = 8 * 1024 * 1024
MAX_SELECTED = 16 * 1024 * 1024
TOOL_FIELDS = {
    'custom_tool_call': ('type', 'call_id', 'id', 'name', 'namespace', 'input', 'status'),
    'custom_tool_call_output': ('type', 'call_id', 'id', 'output'),
    'function_call': ('type', 'call_id', 'id', 'name', 'namespace', 'arguments', 'status'),
    'function_call_output': ('type', 'call_id', 'id', 'output'),
}


def fields(item, names):
    # Never forward the source object wholesale, including for tool payloads.
    return {key: item[key] for key in names if key in item}


def text_content(items):
    common.require(isinstance(items, list) and len(items) <= 128, 'Visible content inventory bound')
    result = []
    for item in items:
        common.require(isinstance(item, dict) and item.get('type') in ('text', 'output_text', 'refusal'),
                       'Unsupported visible content type: manual review required')
        key = 'refusal' if item['type'] == 'refusal' else 'text'
        common.require(isinstance(item.get(key), str), 'Visible text must be an actual string')
        result.append({'type': item['type'], key: item[key]})
    return result


def select(kind, item, expected):
    subtype = item.get('type')
    if kind == 'session_meta':
        nested = item.get('source', {}).get('subagent', {}).get('thread_spawn', {})
        agent = item.get('agent_path') or nested.get('agent_path')
        parent = item.get('parent_thread_id') or nested.get('parent_thread_id')
        common.require(item.get('id') == expected['id'] and item.get('cwd') == str(REPO)
                       and agent == expected['agent_path'] and parent == common.PARENT_ID,
                       'Child session identity does not match observed fresh context')
        return {'id': item['id'], 'cwd': item['cwd'], 'agent_path': agent,
                'parent_thread_id': parent, 'model_provider': item.get('model_provider')}
    if kind == 'turn_context':
        selected = fields(item, ('turn_id', 'model', 'effort', 'cwd'))
        mode = item.get('collaboration_mode', {})
        common.require(isinstance(mode, dict) and isinstance(mode.get('settings', {}), dict),
                       'Unexpected model-context shape')
        selected['collaboration_mode'] = {
            'mode': mode.get('mode'),
            'settings': fields(mode.get('settings', {}), ('model', 'reasoning_effort'))}
        return selected
    if kind == 'response_item' and subtype in TOOL_FIELDS:
        common.require(isinstance(item.get('call_id'), str), 'Tool record missing actual call ID')
        selected = fields(item, TOOL_FIELDS[subtype])
        body = 'output' if subtype.endswith('_output') else ('input' if subtype == 'custom_tool_call' else 'arguments')
        common.require(body in selected and isinstance(selected[body], str), 'Unsupported tool input/output shape')
        return selected
    if kind == 'response_item' and subtype == 'message' and item.get('role') == 'assistant' and item.get('phase') in ('commentary', 'final_answer'):
        selected = fields(item, ('type', 'id', 'role', 'phase'))
        selected['content'] = text_content(item.get('content'))
        return selected
    if kind == 'response_item' and subtype == 'agent_message':
        selected = fields(item, ('type', 'id', 'author', 'recipient'))
        items = item.get('content')
        common.require(isinstance(items, list) and len(items) <= 128, 'Incoming content inventory bound')
        descriptions = []
        for block in items:
            common.require(isinstance(block, dict) and isinstance(block.get('type'), str),
                           'Malformed incoming message content descriptor')
            descriptor = {'type': block['type']}
            for name in ('text', 'encrypted_content'):
                if name in block:
                    common.require(isinstance(block[name], str), 'Incoming content field must be a string')
                    raw = block[name].encode()
                    descriptor[name + '_bytes'] = len(raw)
                    descriptor[name + '_sha256'] = common.digest(raw)
            descriptor['source_keys'] = sorted(block)
            descriptions.append(descriptor)
        selected['content_descriptors'] = descriptions
        selected['content_not_exported_or_decrypted'] = True
        return selected
    if kind == 'inter_agent_communication_metadata':
        return fields(item, ('trigger_turn',))
    if kind == 'event_msg' and subtype in ('task_started', 'task_complete'):
        return fields(item, ('type', 'turn_id'))
    return None


def snapshot(path, expected):
    out, contexts, omissions, counts = [], [], collections.Counter(), collections.Counter()
    h = hashlib.sha256()
    size = selected_size = sessions = 0
    with common.open_regular(path, MAX_ROLLOUT) as source:
        first = os.fstat(source.fileno())
        for number in range(1, 100001):
            offset = size
            raw = source.readline(MAX_LINE + 1)
            if not raw:
                break
            common.require(len(raw) <= MAX_LINE and raw.endswith(b'\n'), 'Oversized/partial child rollout record')
            size += len(raw)
            common.require(size <= first.st_size <= MAX_ROLLOUT, 'Child rollout changed during export')
            h.update(raw)
            row = common.document(raw)
            kind, item = row.get('type'), row.get('payload', {})
            common.require(isinstance(item, dict), 'Malformed child payload')
            if number == 1:
                common.require(kind == 'session_meta', 'Missing initial child session identity')
            selected = select(kind, item, expected)
            if selected is None:
                omissions['unselected_records'] += 1
                continue
            common.require('internal_chat_message_metadata_passthrough' not in selected,
                           'Internal passthrough may not be exported')
            if kind == 'session_meta':
                sessions += 1
            if kind == 'turn_context':
                contexts.append(selected)
            record = {'timestamp': row.get('timestamp'), 'ordinal': row.get('ordinal'),
                      'source_line': number, 'source_byte_offset': offset,
                      'source_line_bytes': len(raw), 'source_line_sha256': common.digest(raw),
                      'type': kind, 'payload': selected}
            selected_size += len(common.encoded(record))
            common.require(selected_size <= MAX_SELECTED, 'Filtered child evidence byte bound')
            out.append(record)
            counts[kind + '/' + str(item.get('type', ''))] += 1
        else:
            raise ValueError('Child rollout line-count bound')
        last = os.fstat(source.fileno())
    identity = (first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns)
    common.require(sessions == 1 and contexts and size == first.st_size
                   and identity == (last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns),
                   'Incomplete or changed child source')
    raw = b''.join(common.encoded(row) for row in out)
    return raw, {'local_rollout_filename': path.name, 'local_rollout_bytes': size,
                 'local_rollout_sha256': h.hexdigest(), 'exported_counts': dict(counts),
                 'omitted_counts': dict(omissions), 'model_contexts': contexts,
                 'immutable_backend_model_revision': 'unknown'}, identity


def unchanged(path, expected, identity):
    h, count = hashlib.sha256(), 0
    with common.open_regular(path, MAX_ROLLOUT) as source:
        first = os.fstat(source.fileno())
        while raw := source.read(1024 * 1024):
            count += len(raw)
            common.require(count <= MAX_ROLLOUT, 'Child rollout grew beyond bound')
            h.update(raw)
        last = os.fstat(source.fileno())
    for info in (first, last):
        common.require(identity == (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns),
                       'Child rollout changed before export')
    common.require(count == expected['local_rollout_bytes'] and h.hexdigest() == expected['local_rollout_sha256'],
                   'Child rollout byte digest changed before export')


def save(path, raw):
    common.require(path.parent == DEST, 'Child export output scope')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o400)
    with os.fdopen(fd, 'wb') as target:
        target.write(raw)
        target.flush()
        os.fsync(target.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--finalize', action='store_true', required=True)
    parser.parse_args()
    common.remotes()
    scope = common.resource_scope()
    common.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == common.HEAD,
                   'Recorded v2 source changed')
    originals, _, _, ids = common.final_bindings()
    contexts = common.document(originals[BASE / 'observed-contexts.json'])
    values, checked = {}, []
    manifest = {'protocol': 'stead.filtered-participant-traces/2', 'not_full_rollout': True,
        'source_commit': common.HEAD, 'package_sha256': common.PACKAGE,
        'source_and_native_tests_executed_by_exporter': False,
        'independent_protocol_privacy_and_timing_audit_required': True,
        'exporter_sha256': common.digest(common.read(Path(__file__).absolute())),
        'shared_export_support_sha256': common.digest(common.read(Path(common.__file__).absolute())),
        'resource_scope': scope, 'roles': {},
        'input_records': [{'path': path.relative_to(REPO).as_posix(), 'bytes': len(raw), 'sha256': common.digest(raw)}
                          for path, raw in sorted(originals.items())],
        'omissions': ['No raw rollout, reasoning, system/developer text, environment snapshot, internal_chat_message_metadata_passthrough, '
                      'unrelated context, model personality/summary, or incoming message body is exported.'],
        'limits': ['Incoming content descriptors are type/length/hash metadata only; encrypted incoming bodies are not decrypted.',
                   'Exact parent tool messages and acknowledgments are a separate export, not proof of child plaintext receipt.',
                   'Full inherited tool exposure remains a limitation. Exported tool calls/outputs require independent access audit.',
                   'This helper does not establish complete isolation, equal conditions, valid timing or task success.']}
    for role, task in common.TASKS.items():
        expected = contexts['/root/' + task]
        filename = expected['local_rollout_filename']
        common.require(Path(filename).name == filename and filename.endswith('-' + ids[role] + '.jsonl'),
                       'Unexpected exact child rollout filename')
        path = SESSIONS / filename
        raw, detail, identity = snapshot(path, expected)
        detail['filtered_trace'] = {'path': role + '.jsonl', 'bytes': len(raw), 'sha256': common.digest(raw)}
        values[role + '.jsonl'] = raw
        manifest['roles'][role] = detail
        checked.append((path, detail, identity))
    for path, detail, identity in checked:
        unchanged(path, detail, identity)
    common.require(all(common.read(path) == raw for path, raw in originals.items()), 'Final child bindings changed')
    common.remotes()
    common.require(not any(path.is_symlink() for path in (BASE, *BASE.parents)), 'Redirected child export root')
    DEST.mkdir(mode=0o700)
    for filename, raw in values.items():
        save(DEST / filename, raw)
    save(DEST / 'manifest.json', common.encoded(manifest))
    print(json.dumps({'directory': DEST.relative_to(REPO).as_posix(), 'roles': list(common.TASKS),
                      'manifest_sha256': common.digest(common.encoded(manifest)), 'independent_audit_pending': True}))


if __name__ == '__main__':
    main()

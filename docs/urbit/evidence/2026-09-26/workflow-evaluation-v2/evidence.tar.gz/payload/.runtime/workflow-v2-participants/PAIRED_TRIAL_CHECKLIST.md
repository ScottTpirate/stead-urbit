# Parent-only paired trial launch and measurement checklist — version 2

Prepared by `/root/independent_review`; this is an execution plan, not evidence
that either v2 context was launched. Version 1 is preserved as an incomplete
comparison with invalid T05 inventories; neither its candidates nor its private
scores may be reused, repaired or retried in version 2. Keep this file and `paired-input-map.json`
outside participant inputs. No candidate answers are included.

1. **Admission before launch.** Retain one actual completed current-source
   six-task native prequalification, all reference/oracle/mutant/control
   results, exact common-example provenance, and its clean completed outer
   guard. The prequal04 T03 timeout and prequal05 zero-task guard freshness
   failure are not admission. Version 1 prequalification does not admit the
   changed v2 scorer. In addition to six passing references, require the new
   separately recorded weak T05 continuation control: correct-pass, killed,
   survived, killed, killed for correct, claimed-author, outsider-granted,
   everyone-granted, claim-must-match. Every subject must compile and every
   discovered arm must execute; retain full typed arm/tang envelopes even for
   the surviving middle mutant. It is not a seventh participant task. Freeze
   the evaluator/helper/package hashes and
   source commit. Verify derivative remotes before writes. The v2 package has
   40 payload files plus freeze.json; public/common/assisted inputs and the six
   task oracles retain exact v1 bytes. The frozen package
   identity is `54369e5aba503a0d7abb1cf5cdd059a7b03888a368153c2d7d3b15c7b1afbc3a`.

2. **Create two fresh workspaces and copy only the exact mapped inputs.**
   For each `baseline` and `local_skill_assisted`, create separate `input/`,
   empty `candidate/`, and empty `calls/` under this directory. Do not copy or
   expose `.runtime/workflow-participants`, its context history, old answers,
   private results, or `.runtime/workflow-evaluation` to either participant.
   Preserve relative
   `public/` and `common/` paths. Both get 18 public files plus three common
   files: 21 files / 11,300 bytes. Assisted alone gets the four frozen files
   under `assisted/`: 25 files / 18,531 bytes total. The JSON map contains exact
   per-file hashes and role destinations. Do not copy the entire package,
   repository, reviewer inputs, schema, prior answers or this checklist.
   Keep all mandatory safety constraints identical in the common launch
   message; do not suppress one to manufacture a baseline.

3. **Supply the same actual T02 diagnostic before either starts.** Retain the
   completed prequalification inner and outer receipts inside
   `.runtime/workflow-evaluation-v2/`, with exact `/workflow/...` references and
   hashes in `prequalification.json`. Parent setup calls the reviewed
   `feedback_broker.publish_initial_diagnostics()` helper. It publishes
   byte-identical `input/T02-starter-diagnostic.json` for both roles from the
   single actual `T02-starter-rejection` command. Its argv, input digest, exit
   code, stdout and stderr are observed values; do not synthesize a message
   or copy other prequalification commands. Record diagnostic hash/size and
   updated input inventories, then independently compare both copies.

4. **Record context and tool exposure before work.** Launch two fresh
   `fork_turns=none` contexts, with no previous conversation and the same model
   alias, reasoning settings and exposed tools. Record actual IDs and launch
   arguments; verify every turn's available `turn_context` model/effort, not
   just the requested values. Record the immutable model revision as unknown
   if unavailable. Full inherited tools remain exposed; the wrapper limits
   permitted file-operation subprocesses, not the model's entire toolset.
   Audit initial context/mandatory instructions for baseline skill text or
   oracle exposure. Full skill text, an oracle or the other answer in a
   baseline context invalidates it even if no disallowed read appears later.

5. **Give the exact interface, equally.** Task order is T01 through T06.
   Candidate files live under `candidate/Txx/`; this is `/output/Txx/` inside
   the wrapper. Prompts and starters remain in `/input/public/`; common
   examples/pins remain in `/input/common/`. Both roles may request up to
   three public feedback submissions per task. The only work subprocess is
   `python3 .../workspace_tool.py CONDITION` with one literal JSON request on
   stdin. Allowed operations are list/read/hash/write/copy/remove; there is
   no shell, arbitrary runner, network, raw evaluator or native ship tool.
   Provide the same operation shapes/examples and use `login=False` for the
   outer command. Audit that the command has no extra statements, substitution,
   flags, imports or unrelated reads. Parent messages may request feedback
   or report final submission; no other context may provide task advice.
   Wrapper limits are 64 KiB/file, 1 MiB current aggregate and cumulative
   writes, 64 files, 512 entries, depth 16 and 256 calls per condition.
   Do not preassemble T06 or add generated answers to either workspace.

6. **Measure active wall time explicitly.** The budget is 1,800 active seconds
   per condition across all six tasks. The wrapper does not enforce this
   global budget. Maintain a parent event journal with monotonic nanoseconds,
   UTC, condition, event and rollout/tool/call references: initial delivery,
   task progress, feedback request, participant suspended, broker start/end,
   safe feedback delivered, participant resumed, final submission or cutoff.
   Pause only after the participant is actually waiting/suspended; resume at
   feedback delivery. Exclude verified native queue/guard wait, including
   refusal and cooldown. If the participant continues another task, that
   overlapping time remains active. Record ordinary thinking and workspace
   operations as active. Use nonoverlapping intervals, never subtract broker
   duration blindly, and retain the measurement definition. Interrupt at the
   cutoff and snapshot the then-existing output; do not permit a repair turn.
   Unverifiable or unequal timing limits the comparison and cannot be filled
   with invented values.

7. **Parent-only public feedback.** Parent owns the sole native slot and calls
   `python3 .runtime/workflow-v2-participants/feedback_broker.py CONDITION Txx`.
   It shares `.fileops-v2.lock`, reserves the durable next attempt, snapshots
   exact task bytes and requires current-source/prequalification binding.
   Failed reservations consume an attempt; unexplained startup ownership or
   cleanup blocks further calls. Retain every request/snapshot/command/result.
   Publish only after a clean completed exact linked outer guard, unchanged
   snapshot/helpers/package and no infrastructure error. Ordinary public
   compiler/test failure is valid feedback under that clean guard; a guard
   refusal, timeout or ambiguous cleanup is infrastructure, not candidate
   failure. The participant reads only `input/feedback/Txx-N.json`. Its raw
   inner `outer_guard_status: pending` remains unchanged; the parent's receipt
   message cites the separate completed outer guard. Do not disclose private
   commands, references, cases or mutants. Check combined workspace bounds
   before publication (the broker already does this); never orphan a claimed
   delivery after a failed write. No hand-written substitute feedback.

8. **Freeze final candidates once, then private score.** Stop both contexts
   after final submission/budget. Under each role lock, capture exact bytes
   and a complete hash inventory. Create immutable role snapshots at
   `.runtime/workflow-evaluation-v2/CONDITION/T01..T06` for the supervised private
   scorer. The final inventory is exactly 12 files: one each for T01–T04,
   three for T05 (including unchanged public authorization library), and five
   for T06. Keep narratives outside candidate roots. Use the existing guarded
   `harness.py skill-evaluation --condition CONDITION` operation; one final
   private scoring pass per task, no private feedback or repair afterward.
   Preserve infrastructure interruptions as incomplete. Do not rerun already
   privately scored tasks to obtain a better outcome. If corpus/scoring repair
   changes the experiment after launch, invalidate and restart both contexts
   under a newly documented version; do not silently move the goalposts.
   The parent v2 final scorer must validate all five ordered T05 subjects and
   every submitted arm for failed as well as passed T05. It must reconstruct
   exact generated sources from pinned helper/subject/tests, link actual stdout
   to the native jam, derive tang outcomes, and match row.t05_assessment. A
   complete behavioral failure is different from missing or malformed evidence.
   Do not privately rescore version 1 candidates to exercise the repair.

9. **Export actual trace evidence without unrelated content.** Resolve each
   child's rollout by exact parent/context/agent-path metadata. Retain raw
   local files, but export only that participant's task messages and complete
   tool call inputs/outputs, call IDs/timestamps, model/settings metadata,
   declared input exposure, and parent pause/feedback/cutoff events. Do not
   export reasoning, hidden system/developer text, unrelated sessions or
   credentials. For withheld non-task fields, retain an omission manifest;
   do not describe a filtered export as the full raw rollout. Independently
   inspect every actual tool call (including nested `functions.exec` calls)
   and correlate every allowed wrapper call with its immutable start/finish
   records, request bytes, before/after inventories and verified cleanup.
   Require no unexplained file changes, calls or delivered inputs. Participant
   declarations supplement this audit; they do not establish isolation alone.
   Incoming message bodies may be encrypted in retained rollout records. If
   unavailable, the plaintext ledger is an actual integrator observation and
   delivery metadata may be independently reconciled; do not claim decryption,
   complete plaintext coverage or tool-level isolation from that limitation.
   Preserve failed delivery attempts and any conservative active-time overcharge
   rather than silently treating undelivered feedback as participant input.

10. **Report the observed pair, not efficacy.** Use the frozen result schema
    only as record shape. Bind actual candidate/input/skill hashes, every
    public attempt, private raw case/arm results, source/Clay/loaded closure,
    native controls, final guard and timing records. Distinguish compile from
    runtime outcome and refusal/interruption from candidate failure. Report
    each condition's six outcomes, actual counts/difference and contamination
    limits, including ties/regressions. One local pair and unknown immutable
    model revision support no general skill-improvement claim. Independent
    final artifact review is required before URB-170 closure.

Current support sources for this version (hash identity is not execution):

- Workspace helper: `1a6b7af40bb367eb4e1d8d8ed9ee70c279de294a86ba83edb34244a6503af016`.
- Version 2 parent broker: `37416736c413b7d30d64e340c8e378f178112c7d6ea5c0ccd248a9e9abfbc885`.
- Parent private scorer: `a3fae8a56be2b1b5882c62eea6f97e863b4193576d8acaf17563310e388b498d`.
- Trial clock: `3d0c4ce8791a465fb5f5d2dfa0e6e41cc84f4dc1112cc912c3fcb872d653eae2`.
- Proposed native adapter: `67597ff220928b99ca1cf1e925bd86c903fa3d1399fd59e00825aec936965fe7`.
- Proposed affected host suite: `99f070716c4c63cd9811fc0854841a5ae6e61fd69388fc4b3bb5bd47c35a7192`.

The adapter/package proposal is under `.runtime/workflow-v2-proposal`; it must
be applied and committed by the integrator before any native v2 run. Independent
source/test-design review cleared the proposal and parent scorer; this checklist
records no v2 host/native/participant execution. Require actual current-source
host checks and completed guarded v2 prequalification before launch. Refresh
hashes after any authorized change and retain its review; a source hash alone
cannot transfer prior native evidence or close URB-170.

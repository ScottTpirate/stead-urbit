/+  *test, eval-authorization
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-reader-denied
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 4 4))))
++  test-outsider-denied
  (expect !>(=(~ (advance:eval-authorization ~wes ~wes 4 4))))
++  test-owner-denied
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 4 4))))
++  test-reader-claim-spoof-denied
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 4 4))))
++  test-owner-claim-spoof-denied
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 4 4))))
++  test-outsider-claim-spoof-denied
  (expect !>(=(~ (advance:eval-authorization ~wes ~bus 4 4))))
++  test-writer-reader-claim-ignored
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~nec 4 4))))
++  test-writer-owner-claim-ignored
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~zod 4 4))))
++  test-writer-outsider-claim-ignored
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~wes 4 4))))
++  test-writer-nonzero-revision
  (expect !>(=([~ 256] (advance:eval-authorization ~bus ~bus 255 255))))
++  test-future-revision-denied
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 4 5))))
--

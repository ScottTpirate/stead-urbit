=>
|%
++  maybe-count
  |=  [enabled=? count=@ud]
  ^-  (unit @ud)
  ?.  enabled  ~
  [~ count]
--

=/  actual  (maybe-count [%.y 421])
?>  =([~ 421] actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

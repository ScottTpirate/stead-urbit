=>
|%
++  maybe-count
  |=  [enabled=? count=@ud]
  ^-  (unit @ud)
  ?.  enabled  ~
  [~ count]
--

=/  actual  (maybe-count [%.n 0])
?>  =(~ actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

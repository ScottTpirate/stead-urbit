"""Parent-only, create-once export of exact v2 delivery calls and their acks.

Do not run until BOTH participants are final and their timing journals closed.
Run with --finalize in a CPU50%/10ms, CPU19 user scope. This reads the parent
rollout only. It never decrypts child messages, opens candidates, resumes an
agent, executes a test, or certifies delivery or isolation from an ack alone.
"""
from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

BASE = Path(__file__).absolute().parent
REPO = BASE.parent.parent
PARENT_ID = '01a0d560-1011-7fe3-813b-45a54cd6a983'
SOURCE = Path('/home/skilgore/.codex/sessions/2026/09/24') / (
    'rollout-2026-09-24T17-43-57-' + PARENT_ID + '.jsonl')
HEAD = '0d877cff4319de8d437f0da58d4518535f758c36'
PACKAGE = '54369e5aba503a0d7abb1cf5cdd059a7b03888a368153c2d7d3b15c7b1afbc3a'
TASKS = {'baseline': 'workflow_baseline_v2',
         'local_skill_assisted': 'workflow_assisted_v2'}
NAMES = {name: name for name in ('spawn_agent', 'followup_task', 'send_message')}
NAMES.update({'collaboration.' + name: name for name in tuple(NAMES)})
MAX_SOURCE = 128 * 1024 * 1024
MAX_LINE = 8 * 1024 * 1024
MAX_SELECTED = 16 * 1024 * 1024
MAX_VALUE = 1024 * 1024


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False,
                       allow_nan=False) + '\n').encode()


def pairs(values):
    result = {}
    for key, value in values:
        require(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def document(raw):
    def invalid(_):
        raise ValueError('Nonfinite JSON value')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def open_regular(path, maximum):
    require(path.is_absolute() and '..' not in path.parts
            and not any(item.is_symlink() for item in (path, *path.parents)),
            'Redirected input path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    info = os.fstat(fd)
    if not (stat.S_ISREG(info.st_mode) and info.st_nlink == 1
            and info.st_uid == os.getuid() and 0 <= info.st_size <= maximum):
        os.close(fd)
        raise ValueError('Input ownership/type/byte bound')
    return os.fdopen(fd, 'rb')


def read(path, maximum=MAX_VALUE):
    with open_regular(path, maximum) as source:
        raw = source.read(maximum + 1)
    require(len(raw) <= maximum, 'Input grew beyond bound')
    return raw


def remotes():
    for extra in ([], ['--push']):
        require(subprocess.check_output(['git', 'remote', 'get-url', *extra, 'origin'],
                                        cwd=REPO).strip()
                == b'https://github.com/ScottTpirate/stead-urbit.git', 'Wrong derivative remote')
    require(subprocess.check_output(['git', 'remote', 'get-url', '--push', 'upstream'],
                                    cwd=REPO).strip() == b'DISABLED_UPSTREAM_PUSH',
            'Upstream must remain read-only')


def resource_scope():
    rows = Path('/proc/self/cgroup').read_text().splitlines()
    require(len(rows) == 1 and rows[0].startswith('0::/user.slice/'), 'User scope required')
    group = rows[0].removeprefix('0::')
    require('..' not in group.split('/'), 'Invalid cgroup path')
    value = (Path('/sys/fs/cgroup' + group) / 'cpu.max').read_text().strip()
    require(value == '5000 10000' and sorted(os.sched_getaffinity(0)) == [19],
            'Require CPU50%/10ms and CPU19')
    return {'cpu_max': value, 'affinity': [19], 'control_group': group}


def final_bindings():
    paths = [BASE / name for name in
             ('observed-contexts.json', 'launch-inputs.json', 'final-submissions.json')]
    originals = {path: read(path) for path in paths}
    contexts, launch, final = (document(originals[path]) for path in paths)
    require(launch['source_commit'] == HEAD and launch['package_sha256'] == PACKAGE,
            'V2 source/package binding differs')
    require(final['both_participants_stopped'] is True
            and final['no_further_participant_turns_authorized'] is True
            and set(final['conditions']) == set(TASKS), 'Both final submissions required')
    aliases, ids = {}, {}
    for role, task in TASKS.items():
        context = contexts['/root/' + task]
        require(context['agent_path'] == '/root/' + task
                and context['parent_thread_id'] == PARENT_ID
                and context['cwd'] == str(REPO)
                and re.fullmatch(r'[0-9a-f-]{36}', context['id']), 'Wrong observed child context')
        entry = final['conditions'][role]
        require(entry['context_id'] == context['id'] and entry['participant'] == '/root/' + task,
                'Final context differs from observed launch')
        rel = Path(entry['final_clock_record'])
        require(not rel.is_absolute() and '..' not in rel.parts, 'Escaping final clock')
        clock_path = REPO / rel
        require(clock_path.parent == BASE / role / 'timing'
                and re.fullmatch(r'[0-9]{4}\.json', clock_path.name), 'Wrong final clock path')
        clock_raw = read(clock_path)
        clock = document(clock_raw)
        require(clock['condition'] == role and clock['state_after'] == 'closed'
                and clock['event'] in ('final', 'cutoff'), 'Participant clock remains open')
        originals[clock_path] = clock_raw
        ids[role] = context['id']
        for alias in (task, '/root/' + task, context['id']):
            require(alias not in aliases, 'Ambiguous participant target')
            aliases[alias] = role
    return originals, launch, aliases, ids


def filtered_snapshot(aliases, launch):
    calls, rows, omissions = {}, [], collections.Counter()
    hashes = hashlib.sha256()
    total = selected_bytes = 0
    session_verified = False
    with open_regular(SOURCE, MAX_SOURCE) as source:
        initial = os.fstat(source.fileno())
        for number in range(1, 250001):
            offset = total
            raw = source.readline(MAX_LINE + 1)
            if not raw:
                break
            require(len(raw) <= MAX_LINE and raw.endswith(b'\n'), 'Oversized/partial rollout line')
            total += len(raw)
            require(total <= initial.st_size <= MAX_SOURCE, 'Rollout grew during export')
            hashes.update(raw)
            row = document(raw)
            kind, item = row.get('type'), row.get('payload', {})
            require(isinstance(item, dict), 'Malformed rollout payload')
            if number == 1:
                require(kind == 'session_meta' and item.get('id') == PARENT_ID,
                        'Wrong parent session')
                session_verified = True
            selected, role = None, None
            if kind == 'response_item' and item.get('type') == 'function_call' and item.get('name') in NAMES:
                args_raw = item.get('arguments')
                require(isinstance(args_raw, str) and len(args_raw.encode()) <= MAX_VALUE,
                        'Malformed/oversized delivery argument')
                args = document(args_raw)
                require(isinstance(args, dict), 'Delivery arguments must be an object')
                op = NAMES[item['name']]
                target = args.get('task_name') if op == 'spawn_agent' else args.get('target')
                role = aliases.get(target) if isinstance(target, str) else None
                if role is not None:
                    allowed = ({'task_name', 'message', 'fork_turns', 'model', 'reasoning_effort'}
                               if op == 'spawn_agent' else {'target', 'message'})
                    require(set(args) <= allowed and isinstance(args.get('message'), str),
                            'Unknown selected delivery fields')
                    call_id = item.get('call_id')
                    require(isinstance(call_id, str) and 0 < len(call_id) <= 256
                            and call_id not in calls and len(calls) < 512,
                            'Missing/duplicate/oversized delivery call identity')
                    selected = {'type': 'function_call', 'name': item['name'],
                                'call_id': call_id, 'arguments': args_raw}
                    if 'namespace' in item:
                        require(item['namespace'] in (None, 'collaboration'), 'Unexpected tool namespace')
                        selected['namespace'] = item['namespace']
                    entry = {'condition': role, 'operation': op, 'call_id': call_id,
                             'call_record_index': len(rows), 'source_line': number,
                             'message_sha256': digest(args['message'].encode()), 'ack_record_index': None}
                    if op == 'spawn_agent':
                        expected = launch['participant_launches'][role]
                        entry['matches_recorded_initial_launch'] = (
                            args['task_name'] == expected['task_name']
                            and args.get('fork_turns') == expected['fork_turns'] == 'none'
                            and args['message'] == expected['prompt']
                            and args.get('model') == expected['model_override']
                            and args.get('reasoning_effort') == expected['reasoning_effort_override'])
                    calls[call_id] = entry
            elif kind == 'response_item' and item.get('type') == 'function_call_output' and item.get('call_id') in calls:
                entry = calls[item['call_id']]
                require(entry['ack_record_index'] is None, 'Duplicate delivery acknowledgment')
                output = item.get('output')
                require(isinstance(output, str) and len(output.encode()) <= MAX_VALUE,
                        'Malformed/oversized delivery acknowledgment')
                selected = {'type': 'function_call_output', 'call_id': item['call_id'], 'output': output}
                entry['ack_record_index'] = len(rows)
                role = entry['condition']
            if selected is None:
                # Counts only: no unrelated content, role text, hidden fields,
                # user/environment details, or internal passthrough is copied.
                omissions['unselected_records'] += 1
                continue
            out = {'timestamp': row.get('timestamp'), 'ordinal': row.get('ordinal'),
                   'source_line': number, 'source_byte_offset': offset,
                   'source_line_bytes': len(raw), 'source_line_sha256': digest(raw),
                   'condition': role, 'type': 'response_item', 'payload': selected}
            selected_bytes += len(encoded(out))
            require(selected_bytes <= MAX_SELECTED, 'Selected evidence byte bound')
            rows.append(out)
        else:
            raise ValueError('Rollout line-count bound exceeded')
        final = os.fstat(source.fileno())
    require(session_verified and total == initial.st_size
            and (initial.st_dev, initial.st_ino, initial.st_size, initial.st_mtime_ns)
            == (final.st_dev, final.st_ino, final.st_size, final.st_mtime_ns),
            'Parent rollout changed during scan')
    require(calls and all(value['ack_record_index'] is not None for value in calls.values()),
            'Incomplete selected delivery/acknowledgment pair')
    for role in TASKS:
        launches = [value for value in calls.values() if value['condition'] == role
                    and value['operation'] == 'spawn_agent']
        require(len(launches) == 1, 'One actual initial spawn required for each fresh context')
    return rows, list(calls.values()), dict(omissions), {
        'filename': SOURCE.name, 'bytes': total, 'sha256': hashes.hexdigest(),
        'device': initial.st_dev, 'inode': initial.st_ino, 'mtime_ns': initial.st_mtime_ns}


def unchanged_snapshot(expected):
    h = hashlib.sha256()
    count = 0
    with open_regular(SOURCE, MAX_SOURCE) as source:
        before = os.fstat(source.fileno())
        while raw := source.read(1024 * 1024):
            count += len(raw)
            require(count <= MAX_SOURCE, 'Parent rollout byte bound')
            h.update(raw)
        after = os.fstat(source.fileno())
    for current in (before, after):
        require((current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns)
                == (expected['device'], expected['inode'], expected['bytes'], expected['mtime_ns']),
                'Parent rollout changed before export')
    require(count == expected['bytes'] and h.hexdigest() == expected['sha256'],
            'Parent rollout bytes changed before export')


def immutable(path, raw):
    require(path.parent == BASE / 'parent-deliveries', 'Export scope escaped')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o400)
    with os.fdopen(fd, 'wb') as target:
        target.write(raw)
        target.flush()
        os.fsync(target.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--finalize', action='store_true', required=True)
    parser.parse_args()
    remotes()
    scope = resource_scope()
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == HEAD,
            'Recorded v2 source HEAD changed')
    original, launch, aliases, ids = final_bindings()
    rows, calls, omitted, source = filtered_snapshot(aliases, launch)
    output = b''.join(encoded(row) for row in rows)
    manifest = {'protocol': 'stead.parent-participant-deliveries/1',
        'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'prepared_by': '/root/independent_review', 'exported_by': 'parent-only helper',
        'parent_context_id': PARENT_ID, 'child_context_ids': ids,
        'source_commit': HEAD, 'package_sha256': PACKAGE,
        'parent_rollout_snapshot': {key: source[key] for key in ('filename', 'bytes', 'sha256')},
        'not_full_rollout': True, 'independent_delivery_and_timing_audit_required': True,
        'omissions': ['All unrelated records, hidden reasoning, system/developer content, environment snapshots, '
                      'internal_chat_message_metadata_passthrough and other unselected fields are omitted.'],
        'limitations': ['These are exact authored parent tool arguments and actual matched tool acknowledgments.',
                       'An acknowledgment alone does not prove participant receipt or plaintext contents.',
                       'Encrypted incoming child bodies are not decrypted. Parent plaintext and child delivery '
                       'metadata require separate reconciliation; complete context isolation is not established.',
                       'Snapshot hashing covers the parent file only through the recorded byte count; '
                       'later parent records are outside this export.'],
        'input_records': [{'path': str(path.relative_to(REPO)), 'bytes': len(raw), 'sha256': digest(raw)}
                          for path, raw in sorted(original.items())],
        'exporter_sha256': digest(read(Path(__file__).absolute())),
        'resource_scope': scope, 'calls': calls, 'omitted_counts': omitted,
        'filtered_trace': {'path': 'parent.jsonl', 'bytes': len(output), 'sha256': digest(output)}}
    unchanged_snapshot(source)
    require(all(read(path) == raw for path, raw in original.items()), 'Final metadata changed during export')
    remotes()
    dest = BASE / 'parent-deliveries'
    require(not any(path.is_symlink() for path in (BASE, *BASE.parents)), 'Redirected export root')
    dest.mkdir(mode=0o700)
    immutable(dest / 'parent.jsonl', output)
    immutable(dest / 'manifest.json', encoded(manifest))
    print(json.dumps({'directory': str(dest.relative_to(REPO)), 'calls': len(calls),
                      'trace_sha256': digest(output), 'manifest_sha256': digest(encoded(manifest)),
                      'classification': 'filtered authored deliveries and acks; independent audit pending'}))


if __name__ == '__main__':
    main()

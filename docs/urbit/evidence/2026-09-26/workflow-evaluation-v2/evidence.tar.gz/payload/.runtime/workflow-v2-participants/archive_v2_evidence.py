"""Create-once byte-preserving v2 archive from an explicit final evidence plan.

This is an outcome-neutral packager, not a trial scorer or completeness gate.
Prepare the exact members/sha256/bytes/classification plan after both one-shot
scores and trace audits. Run --finalize --plan PATH only in CPU50%/10ms, CPU19.
The output stays ignored at portable-bundle/ for review before publication.
No v1 outcome, candidate, score, timing adjustment or review is copied by default.
"""
from __future__ import annotations

import argparse
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
import export_parent_deliveries as common

BASE, REPO = common.BASE, common.REPO
HEAD, PACKAGE, ROLES = common.HEAD, common.PACKAGE, tuple(common.TASKS)
OUT = BASE / 'portable-bundle'
MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
MAX_FILES = 4096


def relative(value):
    common.require(isinstance(value, str) and 0 < len(value) <= 512, 'Invalid evidence path')
    path = Path(value)
    common.require(not path.is_absolute() and path.as_posix() == value
                   and all(part not in ('', '.', '..') for part in path.parts)
                   and all(re.fullmatch(r'[A-Za-z0-9_.-]+', part) for part in path.parts),
                   'Noncanonical evidence path')
    common.require(not any(part in ('__pycache__', '.codex', 'sessions') for part in path.parts)
                   and not value.endswith(('.pyc', '.lock')), 'Excluded cache/rollout/lock path')
    return path


def allowed(path):
    name = path.as_posix()
    prefixes = (
        '.runtime/workflow-v2-participants/', '.runtime/workflow-evaluation-v2/',
        'scripts/urbit/', 'specs/urbit/', 'native/',
        'tests/urbit/skill_evaluation/', 'tests/urbit/native_gall_schedule/',
        'docs/urbit/evidence/2026-09-26/native-attempts/prequal12/',
        '.runtime/phase01-20260926/baseline-T06-1-infrastructure/')
    if name in ('Makefile', 'LICENSE', 'LICENSE.txt') or name.startswith(prefixes):
        common.require(not name.startswith('.runtime/workflow-v2-participants/portable-bundle/'),
                       'Cannot archive prior/current output recursively')
        return True
    if re.fullmatch(r'\.runtime/execution-runs/four-fakes-[A-Za-z0-9_-]+/'
                    r'(report\.json|events\.jsonl|\.stead-disposable\.json|control/source-context\.json)', name):
        return True
    if re.fullmatch(r'\.piers/fakes/logs/skill-evaluation-[0-9]{8}T[0-9]{6}Z-'
                    r'(prequalification|baseline|local_skill_assisted|feedback-[A-Za-z0-9_-]+)'
                    r'(\.json|-[A-Za-z0-9_-]+\.json|-[A-Za-z0-9_-]+\.log|-[A-Za-z0-9_-]+-inputs/[A-Za-z0-9_./-]+|'
                    r'-inputs/[A-Za-z0-9_./-]+)', name):
        return True
    if re.fullmatch(r'\.runtime/urbit-[0-9a-f]{40}/'
                    r'(LICENSE\.txt|pkg/arvo/LICENSE\.txt|pkg/base-dev/lib/test\.hoon)', name):
        return True
    return False


def save(path, raw):
    common.require(path.is_relative_to(OUT) and not any(item.is_symlink() for item in (path, *path.parents)),
                   'Redirected/escaping archive output')
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o400)
    with os.fdopen(fd, 'wb') as target:
        target.write(raw)
        target.flush()
        os.fsync(target.fileno())


def ref(path, raw):
    return {'path': path.relative_to(OUT).as_posix(), 'bytes': len(raw), 'sha256': common.digest(raw)}


def load_plan(path):
    common.require(path.parent == BASE, 'Plan must be a parent-only file beside this helper')
    raw = common.read(path, 4 * 1024 * 1024)
    plan = common.document(raw)
    common.require(plan.get('protocol') == 'stead.workflow-v2-portable-plan/1'
                   and plan.get('source_commit') == HEAD and plan.get('package_sha256') == PACKAGE,
                   'Wrong v2 plan/source/package')
    members = plan.get('members')
    common.require(isinstance(members, list) and 0 < len(members) <= MAX_FILES,
                   'Nonempty bounded exact evidence inventory required')
    payload, rows, exposures, total = {}, [], set(), 0
    for member in members:
        common.require(isinstance(member, dict) and set(member) <=
                       {'path', 'sha256', 'bytes', 'classification', 'expose_as', 'gzip'},
                       'Unknown plan member field')
        source = relative(member['path'])
        common.require(allowed(source) and source.as_posix() not in payload,
                       'Unapproved/duplicate selected source path')
        common.require(isinstance(member.get('sha256'), str)
                       and re.fullmatch('[0-9a-f]{64}', member['sha256'])
                       and type(member.get('bytes')) is int and 0 <= member['bytes'] <= MAX_FILE
                       and isinstance(member.get('classification'), str)
                       and 0 < len(member['classification']) <= 256, 'Malformed exact evidence member')
        total += member['bytes']
        common.require(total <= MAX_TOTAL, 'Aggregate evidence byte bound')
        data = common.read(REPO / source, MAX_FILE)
        common.require(len(data) == member['bytes'] and common.digest(data) == member['sha256'],
                       'Selected source hash/length differs: ' + source.as_posix())
        if 'expose_as' in member:
            exposed = relative(member['expose_as'])
            common.require(exposed.parts[0] in ('raw', 'reports') and exposed.as_posix() not in exposures,
                           'Exposed report path must be unique under raw/ or reports/')
            exposures.add(exposed.as_posix())
        common.require(type(member.get('gzip', False)) is bool
                       and ('expose_as' in member or not member.get('gzip', False)), 'Invalid compression option')
        payload[source.as_posix()] = data
        rows.append(member)
    return raw, plan, payload, rows


def mandatory_members():
    names = [BASE / name for name in ('final-submissions.json', 'launch-admission.json',
              'launch-inputs.json', 'observed-contexts.json',
              'export_parent_deliveries.py', 'export_trial_trace_safe.py', 'archive_v2_evidence.py',
              'parent-deliveries/manifest.json', 'parent-deliveries/parent.jsonl',
              'filtered-traces-safe/manifest.json', 'filtered-traces-safe/baseline.jsonl',
              'filtered-traces-safe/local_skill_assisted.jsonl')]
    for role in ROLES:
        names += [BASE / 'private-scores' / role / item for item in
                  ('freeze-result.json', 'score-intent.json', 'score-result.json')]
    names += [REPO / '.runtime/workflow-evaluation-v2' / name for name in
              ('prequalification.json', 'prequalification-inner.json', 'prequalification-guard.json')]
    return {path.relative_to(REPO).as_posix() for path in names}


def check_trace_hashes(payload):
    for directory, manifest_name in (('parent-deliveries', 'manifest.json'), ('filtered-traces-safe', 'manifest.json')):
        prefix = (BASE / directory).relative_to(REPO).as_posix() + '/'
        manifest = common.document(payload[prefix + manifest_name])
        common.require(manifest.get('not_full_rollout') is True, 'Traces must be explicitly filtered')
        references = ([manifest['filtered_trace']] if directory == 'parent-deliveries'
                      else [manifest['roles'][role]['filtered_trace'] for role in ROLES])
        for item in references:
            local = relative(item['path'])
            common.require(len(local.parts) == 1, 'Filtered trace ref must be a local filename')
            raw = payload[prefix + local.as_posix()]
            common.require(len(raw) == item['bytes'] and common.digest(raw) == item['sha256'],
                           'Filtered trace bytes do not match manifest')
            for line in raw.splitlines():
                row = common.document(line)
                common.require(isinstance(row.get('payload'), dict)
                               and 'internal_chat_message_metadata_passthrough' not in row['payload'],
                               'Trace retained prohibited internal metadata')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--finalize', action='store_true', required=True)
    parser.add_argument('--plan', type=Path, required=True)
    options = parser.parse_args()
    common.remotes()
    scope = common.resource_scope()
    common.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip() == HEAD,
                   'Recorded v2 HEAD changed')
    originals, _, _, _ = common.final_bindings()
    plan_path = options.plan.absolute()
    plan_raw, plan, payload, rows = load_plan(plan_path)
    common.require(mandatory_members() <= set(payload), 'Missing required final score/trace/admission record')
    common.require(all(payload.get(path.relative_to(REPO).as_posix()) == raw
                       for path, raw in originals.items()), 'Final binding records missing or changed')
    check_trace_hashes(payload)
    for role in ROLES:
        result_path = (BASE / 'private-scores' / role / 'score-result.json').relative_to(REPO).as_posix()
        result = common.document(payload[result_path])
        common.require(result.get('condition') == role and result.get('completed_at'),
                       'Both one-shot score lifecycles must be final before packaging')
    # No score status is promoted here: failed/invalid/infrastructure receipts
    # remain exact. Semantic review owns complete coverage and outcome claims.
    common.remotes()
    OUT.mkdir(mode=0o700)
    save(OUT / 'selection-plan.json', plan_raw)
    members = [{'path': 'payload/' + name, 'bytes': len(raw), 'sha256': common.digest(raw),
                'classification': next(row['classification'] for row in rows if row['path'] == name)}
               for name, raw in sorted(payload.items())]
    save(OUT / 'members.json', common.encoded(members))
    archive = OUT / 'evidence.tar.gz'
    with archive.open('xb') as stream:
        os.fchmod(stream.fileno(), 0o400)
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as target:
                for member in members:
                    raw = payload[member['path'].removeprefix('payload/')]
                    info = tarfile.TarInfo(member['path'])
                    info.size, info.mode, info.mtime = len(raw), 0o400, 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    target.addfile(info, io.BytesIO(raw))
        stream.flush()
        os.fsync(stream.fileno())
    accessible = []
    for row in rows:
        if 'expose_as' not in row:
            continue
        raw = payload[row['path']]
        data = gzip.compress(raw, mtime=0, compresslevel=6) if row.get('gzip', False) else raw
        path = OUT / row['expose_as']
        save(path, data)
        accessible.append({**ref(path, data), 'original_path': row['path'],
                           'original_sha256': common.digest(raw), 'original_bytes': len(raw),
                           'compression': 'gzip' if row.get('gzip', False) else None,
                           'classification': row['classification']})
    expected = {row['path']: row for row in members}
    seen = set()
    with tarfile.open(archive, 'r|gz') as source:
        for member in source:
            common.require(member.isfile() and member.name in expected and member.name not in seen
                           and member.size == expected[member.name]['bytes']
                           and member.mode == 0o400 and member.uid == member.gid == member.mtime == 0
                           and member.uname == member.gname == '', 'Archive member type/metadata/inventory')
            raw = source.extractfile(member).read(MAX_FILE + 1)
            common.require(len(raw) == member.size and common.digest(raw) == expected[member.name]['sha256'],
                           'Archive member readback mismatch')
            seen.add(member.name)
    common.require(seen == set(expected), 'Archive lost selected members')
    common.require(common.read(plan_path, 4 * 1024 * 1024) == plan_raw
                   and all(common.read(REPO / name, MAX_FILE) == raw for name, raw in payload.items()),
                   'Selected originals changed during packaging')
    archive_raw = common.read(archive, MAX_TOTAL)
    index = {'protocol': 'stead.workflow-v2-portable-bytes/1',
        'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': HEAD, 'package_sha256': PACKAGE, 'classification': 'exact selected evidence bytes only',
        'status': 'packaged-awaiting-independent-semantic-and-completeness-review',
        'qualifies_task_or_phase': False, 'tests_or_native_executed_by_packager': False,
        'resource_scope': scope, 'archive': ref(archive, archive_raw),
        'members': ref(OUT / 'members.json', common.encoded(members)),
        'selection_plan': ref(OUT / 'selection-plan.json', plan_raw), 'accessible_reports': accessible,
        'counts': {'files': len(members), 'uncompressed_bytes': sum(row['bytes'] for row in members)},
        'byte_verification': {'all_selected_members_rehashed': True, 'all_selected_originals_unchanged': True},
        'limits': ['Selection is explicit. Byte integrity is not evidence-inventory completeness or task acceptance.',
                   'No prior v1 score, timing correction or participant outcome is inferred.',
                   'Parent acknowledgments and filtered child metadata do not decrypt incoming bodies or prove complete isolation.',
                   'Independent review must reconcile every public reservation, generated input, guard, source context, '
                   'candidate snapshot, T05 subject/arm, timing interval and private one-shot outcome.'],
        'archive_format': 'Sorted PAX regular files, uid/gid0, empty names, mode0400, mtime0; gzip mtime0.',
        'path_rule': 'Output references are relative to this index directory. Members preserve repository-relative originals '
                     'under payload/. Extract only into a separate empty directory.'}
    save(OUT / 'index.json', common.encoded(index))
    print(json.dumps({'directory': OUT.relative_to(REPO).as_posix(), 'files': len(members),
                      'index_sha256': common.digest(common.encoded(index)), 'qualifies_task_or_phase': False}))


if __name__ == '__main__':
    main()

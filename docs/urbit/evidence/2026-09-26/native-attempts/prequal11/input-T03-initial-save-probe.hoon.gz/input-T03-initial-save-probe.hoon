/=  candidate  /app/eval-counter
:-  %say
|=  *
:-  %noun
~&  [%stead-skill-t03-initial %body-enter]
=/  context=bowl:gall  *bowl:gall
=.  our.context  ~zod
=.  src.context  ~zod
=.  now.context  ~2026.9.25
=/  original=agent:gall  ~(. candidate context)
~&  [%stead-skill-t03-initial %agent-ready]
=/  initial=vase  on-save:original
~&  [%stead-skill-t03-initial %save-returned]
?>  =([%1 0 0] q.initial)
^-  [@tas @ud]
[%skill-result (jam q.initial)]

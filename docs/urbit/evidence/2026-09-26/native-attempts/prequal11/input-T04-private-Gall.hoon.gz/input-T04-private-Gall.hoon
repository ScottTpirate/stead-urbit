/=  gall-raw  /sys/vane/gall
/=  candidate  /app/eval-access
=/  gall-bunt  (gall-raw ~zod)
=>
|%
++  make-gall
  |=  who=ship
  =/  pupa  (gall-raw who)
  =/  adult  (pupa now=~2026.9.25 eny=`@`0xdead.beef scry=*roof)
  =+  [moves next]=(call:adult duct=~[/init] dud=~ task=[%init ~])
  ?>  =(~ moves)
  next
--
=/  gall-adult  (make-gall ~zod)
=>
|%
+$  machine  _gall-adult
+$  motion  move:gall-bunt
++  call
  |=  [state=machine return=duct input=(hobo task:gall)]
  (call:(state ~2026.9.25 `@`0xdead.beef *roof) return ~ input)
++  load
  =/  state  (make-gall ~zod)
  =^  moves  state
    (call state ~[/load] [%load [[%eval-access [~zod %base da+~2026.9.25] candidate] ~]])
  =/  response=sign-arvo
    :+  %clay  %writ
    `[[%a da+~2026.9.25 %base] /app/eval-access/hoon vase+!>(!>(candidate))]
  =^  ready  state
    (take:(state ~2026.9.25 `@`0xdead.beef *roof) /sys/cor/eval-access/~zod/base/(scot %da ~2026.9.25) ~[/load] ~ response)
  state
++  saved
  |=  state=machine
  =/  current  (state ~2026.9.25 `@`0xdead.beef *roof)
  =/  yoke  (~(got by yokes.state.current) %eval-access)
  ?>  ?=(%live -.yoke)
  ?>  ?=(%& -.agent.yoke)
  =/  observed  on-save:p.agent.yoke
  q.observed
--
:-  %say
|=  *
:-  %noun

=/  engine  load
?>  =([%0 0] (saved engine))
=/  evidence=(list *)  ~
=^  moves  engine  (call engine ~[/skill/step-0] [%deal [~bus ~zod /skill/fixture] %eval-access %poke %noun !>([%set ~bud 7])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ~] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  =([%0 7] (saved engine))
=.  evidence  [[0 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-1] [%deal [~nec ~zod /skill/fixture] %eval-access %poke %noun !>([%set ~bus 9])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-denied') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[1 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-2] [%deal [~bud ~zod /skill/fixture] %eval-access %poke %noun !>([%set ~bus 9])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-denied') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[2 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-3] [%deal [~zod ~zod /skill/fixture] %eval-access %poke %noun !>([%set ~bus 9])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-denied') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[3 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-4] [%deal [~bus ~zod /skill/fixture] %eval-access %poke %json !>([%set ~bus 9])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-mark') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[4 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-5] [%deal [~bus ~zod /skill/fixture] %eval-access %poke %noun !>([%set ~bus 256])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-limit') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[5 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-6] [%deal [~bus ~zod /skill/fixture] %eval-access %poke %noun !>([%reset ~bus 9])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  =([%0 7] (saved engine))
=.  evidence  [[6 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-7] [%deal [~bus ~zod /skill/fixture] %eval-access %watch /value])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ~] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(1 (lent facts))
?>  =(1 (lent kicks))
?>  =(3 (lent moves))
?>  ?=(^ facts)
=/  fact  i.facts
?>  ?=([* %give %unto %fact *] fact)
=/  [return=duct a=@ b=@ c=@ result=cage]  fact
?>  =(%noun p.result)
?>  =(7 !<(@ud q.result))
?>  =([%0 7] (saved engine))
=.  evidence  [[7 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-8] [%deal [~nec ~zod /skill/fixture] %eval-access %watch /value])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ~] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(1 (lent facts))
?>  =(1 (lent kicks))
?>  =(3 (lent moves))
?>  ?=(^ facts)
=/  fact  i.facts
?>  ?=([* %give %unto %fact *] fact)
=/  [return=duct a=@ b=@ c=@ result=cage]  fact
?>  =(%noun p.result)
?>  =(7 !<(@ud q.result))
?>  =([%0 7] (saved engine))
=.  evidence  [[8 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-9] [%deal [~bud ~zod /skill/fixture] %eval-access %watch /value])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-denied') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[9 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-10] [%deal [~zod ~zod /skill/fixture] %eval-access %watch /value])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-denied') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[10 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-11] [%deal [~bus ~zod /skill/fixture] %eval-access %watch /other])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-path') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[11 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-12] [%deal [~bus ~zod /skill/fixture] %eval-access %watch /value/extra])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ^] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  ?=(^ (find (trip 'eval-path') (trip (crip <moves>))))
?>  =([%0 7] (saved engine))
=.  evidence  [[12 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-13] [%deal [~bus ~zod /skill/fixture] %eval-access %poke %noun !>([%set ~nec 255])])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %poke-ack ~] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(0 (lent facts))
?>  =(0 (lent kicks))
?>  =(1 (lent moves))
?>  =([%0 255] (saved engine))
=.  evidence  [[13 (saved engine) moves] evidence]
=^  moves  engine  (call engine ~[/skill/step-14] [%deal [~nec ~zod /skill/fixture] %eval-access %watch /value])
?>  (lte (lent moves) 3)
=/  acks  (skim moves |=(item=motion ?=([* %give %unto %watch-ack ~] item)))
?>  =(1 (lent acks))
=/  facts  (skim moves |=(item=motion ?=([* %give %unto %fact *] item)))
=/  kicks  (skim moves |=(item=motion ?=([* %give %unto %kick ~] item)))
?>  =(1 (lent facts))
?>  =(1 (lent kicks))
?>  =(3 (lent moves))
?>  ?=(^ facts)
=/  fact  i.facts
?>  ?=([* %give %unto %fact *] fact)
=/  [return=duct a=@ b=@ c=@ result=cage]  fact
?>  =(%noun p.result)
?>  =(255 !<(@ud q.result))
?>  =([%0 255] (saved engine))
=.  evidence  [[14 (saved engine) moves] evidence]
^-  [@tas @ud]
[%skill-result (jam (flop evidence))]

/=  candidate  /app/eval-counter
:-  %say
|=  *
:-  %noun
=/  context=bowl:gall  *bowl:gall
=.  our.context  ~zod
=.  src.context  ~zod
=.  now.context  ~2026.9.25
=/  original=agent:gall  ~(. candidate context)
=/  initial=vase  on-save:original
?>  =([%1 0 0] q.initial)
=/  run-case
  |=  [label=@t incoming=vase expected=* must-reject=? repeat-load=?]
  ^-  *
  =/  agent=agent:gall  ~(. candidate context)
  ?:  must-reject
    =+  [cards loaded]=(on-load:agent !>([%1 5 2]))
    ?>  =(~ cards)
    =/  before=vase  on-save:loaded
    =/  rejected  (mute:vi |.((on-load:loaded incoming)))
    ?>  ?=(%| -.rejected)
    =/  after=vase  on-save:loaded
    ?>  =(before after)
    [label before rejected after]
  =+  [cards loaded]=(on-load:agent incoming)
  ?>  =(~ cards)
  =/  observed=vase  on-save:loaded
  ?>  =(expected q.observed)
  ?:  repeat-load
    =+  [later-cards reloaded]=(on-load:loaded observed)
    ?>  =(~ later-cards)
    =/  again=vase  on-save:reloaded
    ?>  =(observed again)
    [label cards observed]
  [label cards observed]
=/  evidence=(list *)
  :~
    (run-case 'public-v0' !>([%0 7]) [%1 7 0] %.n %.n)
    (run-case 'public-v1' !>([%1 9 3]) [%1 9 3] %.n %.n)
    (run-case 'v0-zero' !>([%0 0]) [%1 0 0] %.n %.n)
    (run-case 'v0-boundary' !>([%0 65.535]) [%1 65.535 0] %.n %.n)
    (run-case 'v1-boundaries' !>([%1 65.535 65.535]) [%1 65.535 65.535] %.n %.n)
    (run-case 'repeat-roundtrip' !>([%1 21 8]) [%1 21 8] %.n %.y)
    (run-case 'future-version' !>([%2 9 3]) ~ %.y %.n)
    (run-case 'untagged' !>(9) ~ %.y %.n)
    (run-case 'missing-field' !>([%1 9]) ~ %.y %.n)
    (run-case 'count-cell' !>([%0 [9 1]]) ~ %.y %.n)
    (run-case 'count-too-large' !>([%0 65.536]) ~ %.y %.n)
    (run-case 'revision-too-large' !>([%1 9 65.536]) ~ %.y %.n)
  ==
^-  [@tas @ud]
[%skill-result (jam evidence)]

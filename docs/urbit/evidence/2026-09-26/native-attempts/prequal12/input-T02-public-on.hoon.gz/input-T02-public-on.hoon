=>
|%
++  maybe-count
  |=  [enabled=? count=@ud]
  ^-  (unit @ud)
  ?.  enabled  ~
  [~ count]
--

=/  actual  (maybe-count [%.y 7])
?>  =([~ 7] actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

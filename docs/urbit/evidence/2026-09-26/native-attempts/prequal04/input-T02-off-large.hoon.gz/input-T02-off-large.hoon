=>
|%
++  maybe-count
  |=  [enabled=? count=@ud]
  ^-  (unit @ud)
  ?.  enabled  ~
  [~ count]
--

=/  actual  (maybe-count [%.n 18.446.744.073.709.551.615])
?>  =(~ actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

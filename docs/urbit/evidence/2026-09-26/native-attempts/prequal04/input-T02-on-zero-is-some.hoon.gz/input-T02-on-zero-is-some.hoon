=>
|%
++  maybe-count
  |=  [enabled=? count=@ud]
  ^-  (unit @ud)
  ?.  enabled  ~
  [~ count]
--

=/  actual  (maybe-count [%.y 0])
?>  =([~ 0] actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

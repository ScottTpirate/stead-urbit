/=  candidate  /app/eval-counter
:-  %say
|=  *
:-  %noun
~&  [%stead-skill-t03 %body-enter]
=/  context=bowl:gall  *bowl:gall
=.  our.context  ~zod
=.  src.context  ~zod
=.  now.context  ~2026.9.25
=/  original=agent:gall  ~(. candidate context)
~&  [%stead-skill-t03 %initial-agent-ready]
=/  initial=vase  on-save:original
~&  [%stead-skill-t03 %initial-save-returned]
?>  =([%1 0 0] q.initial)
=/  run-case
  |=  [label=@t incoming=vase expected=* must-reject=? repeat-load=?]
  ^-  *
  ~&  [%stead-skill-t03 %case-begin label]
  =/  agent=agent:gall  ~(. candidate context)
  ~&  [%stead-skill-t03 %case-agent-ready label]
  ?:  must-reject
    ~&  [%stead-skill-t03 %reject-setup-begin label]
    =+  [cards loaded]=(on-load:agent !>([%1 5 2]))
    ~&  [%stead-skill-t03 %reject-setup-loaded label]
    ?>  =(~ cards)
    =/  before=vase  on-save:loaded
    ~&  [%stead-skill-t03 %mute-begin label]
    =/  rejected  (mute:vi |.((on-load:loaded incoming)))
    ~&  [%stead-skill-t03 %mute-returned label]
    ?>  ?=(%| -.rejected)
    =/  after=vase  on-save:loaded
    ?>  =(before after)
    ~&  [%stead-skill-t03 %case-checked label]
    [label before rejected after]
  ~&  [%stead-skill-t03 %load-begin label]
  =+  [cards loaded]=(on-load:agent incoming)
  ~&  [%stead-skill-t03 %load-returned label]
  ?>  =(~ cards)
  =/  observed=vase  on-save:loaded
  ~&  [%stead-skill-t03 %save-returned label]
  ?>  =(expected q.observed)
  ?:  repeat-load
    ~&  [%stead-skill-t03 %roundtrip-load-begin label]
    =+  [later-cards reloaded]=(on-load:loaded observed)
    ~&  [%stead-skill-t03 %roundtrip-load-returned label]
    ?>  =(~ later-cards)
    =/  again=vase  on-save:reloaded
    ?>  =(observed again)
    ~&  [%stead-skill-t03 %case-checked label]
    [label cards observed]
  ~&  [%stead-skill-t03 %case-checked label]
  [label cards observed]
=/  evidence=(list *)
  :~
    (run-case 'public-v0' !>([%0 7]) [%1 7 0] %.n %.n)
    (run-case 'public-v1' !>([%1 9 3]) [%1 9 3] %.n %.n)
    (run-case 'v0-zero' !>([%0 0]) [%1 0 0] %.n %.n)
    (run-case 'v0-boundary' !>([%0 65.535]) [%1 65.535 0] %.n %.n)
    (run-case 'v1-boundaries' !>([%1 65.535 65.535]) [%1 65.535 65.535] %.n %.n)
    (run-case 'repeat-roundtrip' !>([%1 21 8]) [%1 21 8] %.n %.y)
    (run-case 'future-version' !>([%2 9 3]) ~ %.y %.n)
    (run-case 'untagged' !>(9) ~ %.y %.n)
    (run-case 'missing-field' !>([%1 9]) ~ %.y %.n)
    (run-case 'count-cell' !>([%0 [9 1]]) ~ %.y %.n)
    (run-case 'count-too-large' !>([%0 65.536]) ~ %.y %.n)
    (run-case 'revision-too-large' !>([%1 9 65.536]) ~ %.y %.n)
  ==
~&  [%stead-skill-t03 %all-cases-checked]
~&  [%stead-skill-t03 %jam-begin]
=/  encoded=@ud  (jam evidence)
=/  encoded-bytes=@ud  (met 3 encoded)
~&  [%stead-skill-t03 %result-jam-bytes encoded-bytes]
?.  (lte encoded-bytes 262.144)
  ~|  [%stead-skill-t03-result-jam-oversize encoded-bytes]
  !!
^-  [@tas @ud]
[%skill-result encoded]

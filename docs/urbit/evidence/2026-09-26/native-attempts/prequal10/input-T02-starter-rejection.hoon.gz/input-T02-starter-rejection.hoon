=>
|%
++  maybe-count
  |=  [enabled=? count=@ud]
  ^-  (unit @ud)
  ?.  enabled  ~
  count
--

(maybe-count %.y 7)

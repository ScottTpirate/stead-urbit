"""Host-only synthetic timing and temporary-filesystem checks; no trial/native run."""
import contextlib,copy,hashlib,importlib.util,io,json,os,pathlib,tempfile,unittest
from unittest.mock import patch
P=pathlib.Path(__file__).with_name('trial_clock.py');spec=importlib.util.spec_from_file_location('trial_clock',P);C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)

def fixture():
 rows=[];state='new';active=0;begin=None;previous=None
 for i,(event,stamp) in enumerate((('start',100),('pause',400),('resume',1000),('final',1100))):
  after,charged,next_begin=C.transition(state,active,begin,event,stamp)
  row={'protocol':'stead.observed-trial-timing/1','condition':'baseline','boot_id':'fixtureboot','number':i+1,'previous_sha256':previous,'monotonic_ns':stamp,'event':event,'state_before':state,'state_after':after,'active_before_ns':active,'active_after_ns':charged,'active_interval_started_ns':next_begin}
  raw=json.dumps(row).encode();rows.append(raw);previous=hashlib.sha256(raw).hexdigest();state,active,begin=after,charged,next_begin
 return rows

class Accounting(unittest.TestCase):
 def test_two_intervals_exclude_pause(self):
  self.assertEqual(C.replay(fixture(),'baseline','fixtureboot',1200)[:3],('closed',400,None))
 def test_no_resume_after_budget(self):
  with self.assertRaises(AssertionError):C.transition('paused',C.LIMIT,None,'resume',C.LIMIT+10)
 def test_tail_totals_state_and_interval_are_derived(self):
  for key,value in [('active_after_ns',1),('active_interval_started_ns',0),('state_after','paused'),('monotonic_ns',999),('monotonic_ns',True),('active_before_ns',True)]:
   with self.subTest(key=key,value=value):
    rows=fixture();tail=json.loads(rows[-1]);tail[key]=value;rows[-1]=json.dumps(tail).encode()
    with self.assertRaises(AssertionError):C.replay(rows,'baseline','fixtureboot',1200)
 def test_different_boot_future_timestamp_duplicate_keys(self):
  with self.assertRaises(AssertionError):C.replay(fixture(),'baseline','different',1200)
  with self.assertRaises(AssertionError):C.replay(fixture(),'baseline','fixtureboot',1000)
  rows=fixture();rows[-1]=rows[-1][:-1]+b',"active_after_ns":400}'
  with self.assertRaises(ValueError):C.replay(rows,'baseline','fixtureboot',1200)

class Files(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.base=pathlib.Path(self.tmp.name);(self.base/'baseline').mkdir(mode=0o700)
 def run_main(self):
  with patch.object(C,'BASE',self.base),patch.object(C.sys,'argv',['trial_clock','baseline','status']),patch.object(C.subprocess,'check_output',return_value='https://github.com/ScottTpirate/stead-urbit.git\n'),contextlib.redirect_stdout(io.StringIO()) as out:C.main()
  return json.loads(out.getvalue())
 def test_status_does_not_create_event_directory(self):
  self.assertEqual(self.run_main()['active_seconds'],0);self.assertFalse((self.base/'baseline/timing').exists())
 def test_redirected_timing_parent_rejected(self):
  outside=self.base/'outside';outside.mkdir();(self.base/'baseline/timing').symlink_to(outside,target_is_directory=True)
  with self.assertRaises(OSError):self.run_main()
 def test_redirected_role_parent_rejected(self):
  (self.base/'baseline').rmdir();outside=self.base/'outside';outside.mkdir();(self.base/'baseline').symlink_to(outside,target_is_directory=True)
  with self.assertRaises(OSError):self.run_main()
 def test_writable_or_hardlinked_event_rejected(self):
  timing=self.base/'baseline/timing';timing.mkdir(mode=0o700);p=timing/'0001.json';p.write_bytes(b'{}')
  with self.assertRaises(AssertionError):self.run_main()
  p.chmod(0o400);os.link(p,self.base/'extra-link')
  with self.assertRaises(AssertionError):self.run_main()

if __name__=='__main__':unittest.main(verbosity=2)

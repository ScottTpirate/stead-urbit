"""Parent-only bounded fileops probes. Never a participant or native trial.

Each real sandbox probe uses a fresh ignored condition root. Fault injection is
only in this parent-side probe process and is explicitly labeled in the summary.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).absolute().parent
SOURCE = BASE / 'workspace_tool.py'
spec = importlib.util.spec_from_file_location('fileops_probe_target', SOURCE)
W = importlib.util.module_from_spec(spec)
spec.loader.exec_module(W)


def injected_child():
    # This is the probe's host wrapper, never the sandbox child entrypoint.
    root, fault = Path(sys.argv[2]), sys.argv[3]
    W.BASE = root
    if fault == 'admission':
        original = W.scope_readback
        def reject(unit, cpu):
            original(unit, cpu)
            raise ValueError('AUTHORED host admission refusal after actual readback')
        W.scope_readback = reject
    elif fault == 'cleanup':
        original = W.control
        state = {'injected': False}
        def reject(args, timeout=5):
            result = original(args, timeout)
            if args[:3] == ['systemctl', '--user', 'stop'] and not state['injected']:
                state['injected'] = True
                # Actually stop the real owned scope, then inject an observed
                # error status. The helper must not certify this cleanup.
                assert result['exit'] == 0
                return {**result, 'exit': 1, 'stderr': 'AUTHORED host cleanup-status failure'}
            return result
        W.control = reject
    else:
        assert fault == 'none'
    sys.argv = [str(SOURCE), 'isolation-probe']
    return W.main()


def main():
    remotes = subprocess.check_output(['git', '-C', str(W.REPO), 'remote', '-v'], text=True)
    assert 'origin\thttps://github.com/ScottTpirate/stead-urbit.git (push)' in remotes
    assert 'upstream\tDISABLED_UPSTREAM_PUSH (push)' in remotes
    run = BASE / 'probes' / ('fileops-' + str(time.time_ns()))
    run.mkdir(parents=True)
    results = []
    exact = 'exact UTF-8 identity: Ω\nsecond line\n'.encode()

    def independent_inventory(root):
        rows = []
        for area, folder in [('input', 'input'), ('output', 'candidate')]:
            base = root / 'isolation-probe' / folder
            for path in base.rglob('*'):
                assert not path.is_symlink()
                row = {'area': area, 'path': path.relative_to(base).as_posix(),
                       'kind': 'directory' if path.is_dir() else 'file'}
                if not path.is_dir():
                    raw = path.read_bytes()
                    row.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
                rows.append(row)
        return sorted(rows, key=lambda row: (row['area'], row['path']))

    def prepare(name):
        root = run / name
        condition = root / 'isolation-probe'
        for part in ('input', 'candidate', 'calls'):
            (condition / part).mkdir(parents=True)
        (condition / 'input' / 'sentinel.txt').write_bytes(exact)
        return root

    def call(root, request, name, success, fault='none'):
        raw = json.dumps(request, ensure_ascii=True).encode()
        command = [sys.executable, '-B', str(Path(__file__).absolute()), '--injected-host', str(root), fault]
        response = subprocess.run(command, input=raw, capture_output=True, timeout=35)
        try:
            value = json.loads(response.stdout)
        except ValueError:
            value = None
        assert (response.returncode == 0) == success, (name, response.stdout, response.stderr)
        row = {'name': name, 'classification': 'actual fixed sandbox fileops' if fault == 'none'
               else 'actual sandbox with authored host fault injection', 'fault': fault,
               'request_sha256': hashlib.sha256(raw).hexdigest(), 'exit': response.returncode,
               'stdout_hex': response.stdout.hex(), 'stderr_hex': response.stderr.hex(), 'result': value}
        results.append(row)
        if value and value.get('call'):
            logs = root / 'isolation-probe/calls'
            final = json.loads((logs / (value['call'] + '.finish.json')).read_bytes())
            row['log'] = str(logs / (value['call'] + '.finish.json'))
            row['log_sha256'] = hashlib.sha256((logs / (value['call'] + '.finish.json')).read_bytes()).hexdigest()
            assert final['cleanup']['verified'] is (fault != 'cleanup')
            if success:
                independent = independent_inventory(root)
                assert final['after'] == independent, (name, final['after'], independent)
                row['independent_poststate_sha256'] = hashlib.sha256(W.encoded(independent)).hexdigest()
                if request['op'] in ('copy', 'write'):
                    target = next(item for item in independent
                                  if item['area'] == 'output' and item['path'] == request['path'])
                    assert target['sha256'] == final['response']['result']['sha256']
                    assert target['bytes'] == final['response']['result']['bytes']
            if final.get('admitted'):
                assert final['limits']['files']['cpu.max'] == '5000 10000'
                assert final['limits']['files']['memory.max'] == '134217728'
                assert final['limits']['files']['memory.swap.max'] == '0'
                assert final['limits']['files']['pids.max'] == '16'
        return value

    basic = prepare('basic')
    call(basic, {'op': 'list', 'area': 'input', 'path': ''}, 'list', True)
    read = call(basic, {'op': 'read', 'area': 'input', 'path': 'sentinel.txt'}, 'read', True)
    assert read['response']['result']['text'].encode() == exact
    hashed = call(basic, {'op': 'hash', 'area': 'input', 'path': 'sentinel.txt'}, 'hash', True)
    copied = call(basic, {'op': 'copy', 'source_area': 'input', 'source_path': 'sentinel.txt',
                          'path': 'T06/copied.txt'}, 'T06-exact-byte-copy', True)
    assert hashed['response']['result']['sha256'] == copied['response']['result']['sha256'] == hashlib.sha256(exact).hexdigest()
    assert (basic / 'isolation-probe/candidate/T06/copied.txt').read_bytes() == exact
    call(basic, {'op': 'write', 'path': 'T01/draft.txt', 'text': 'draft\n'}, 'write', True)
    call(basic, {'op': 'write', 'path': 'T01/draft.txt', 'text': 'replacement\n'}, 'overwrite', True)
    call(basic, {'op': 'remove', 'path': 'T01/draft.txt'}, 'remove', True)
    missing = call(basic, {'op': 'read', 'area': 'output', 'path': 'missing.txt'}, 'operation-error-cleanup', False)
    assert missing['admitted'] and missing['cleanup_verified']
    for index, request in enumerate([
        {'op': 'command', 'argv': ['/bin/sh']},
        {'op': 'read', 'area': 'input', 'path': '../calls'},
        {'op': 'read', 'area': 'input', 'path': '/etc/passwd'},
        {'op': 'write', 'area': 'input', 'path': 'bad', 'text': 'bad'},
        {'op': 'write', 'path': 'bad', 'text': 'x' * (W.MAX_FILE + 1)},
        {'op': 'write', 'path': 'bad', 'text': 'x\0y'},
        {'op': 'write', 'path': 'bad', 'text': 'x\r\ny'},
        {'op': 'write', 'path': '/'.join(['a'] * 17), 'text': 'x'},
    ]):
        refused = call(basic, request, 'invalid-request-' + str(index), False)
        assert not refused['admitted'] and refused['cleanup']['not_started']
    output = basic / 'isolation-probe/candidate'
    for name, make in (
            ('symlink', lambda p: p.symlink_to('/etc/passwd')),
            ('hardlink', lambda p: os.link(basic / 'isolation-probe/input/sentinel.txt', p)),
            ('fifo', lambda p: os.mkfifo(p))):
        bad = output / ('negative-' + name)
        make(bad)
        try:
            refused = call(basic, {'op': 'hash', 'area': 'input', 'path': 'sentinel.txt'}, name + '-refused', False)
            assert not refused['admitted']
        finally:
            bad.unlink()

    budget = prepare('cumulative-budget')
    for index in range(W.MAX_TOTAL // W.MAX_FILE):
        call(budget, {'op': 'write', 'path': 'bounded.txt', 'text': 'x' * W.MAX_FILE},
             'cumulative-overwrite-' + str(index), True)
    refused = call(budget, {'op': 'write', 'path': 'bounded.txt', 'text': 'x'}, 'cumulative-budget-refusal', False)
    assert not refused['admitted']
    call(budget, {'op': 'remove', 'path': 'bounded.txt'}, 'remove-does-not-refund', True)
    refused = call(budget, {'op': 'write', 'path': 'bounded.txt', 'text': 'x'}, 'budget-remains-spent', False)
    assert not refused['admitted']

    admission = prepare('admission-refusal')
    refused = call(admission, {'op': 'write', 'path': 'must-not-exist', 'text': 'x'},
                   'readback-refusal-before-request', False, 'admission')
    assert not refused['admitted'] and refused['cleanup_verified']
    assert not (admission / 'isolation-probe/candidate/must-not-exist').exists()
    cleanup = prepare('cleanup-refusal')
    refused = call(cleanup, {'op': 'hash', 'area': 'input', 'path': 'sentinel.txt'},
                   'cleanup-status-failure', False, 'cleanup')
    assert refused['admitted'] and not refused['cleanup_verified']
    call(cleanup, {'op': 'hash', 'area': 'input', 'path': 'sentinel.txt'}, 'unverified-cleanup-blocks-next-call', False)
    summary = {'protocol': 'stead.fileops-isolation-probes/1', 'status': 'passed', 'native_execution': False,
               'participant_trials': False, 'wrapper_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
               'prior_run_limitation': 'fileops-1790430093986207893 lacked independent complete post-state checks; retained unchanged',
               'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'checks': results}
    path = run / 'summary.json'
    path.write_bytes(json.dumps(summary, indent=2).encode() + b'\n')
    print(json.dumps({'status': 'passed', 'checks': len(results), 'summary': str(path)}))
    return 0


if __name__ == '__main__':
    if len(sys.argv) > 1:
        assert sys.argv[1] == '--injected-host' and len(sys.argv) == 4
        raise SystemExit(injected_child())
    raise SystemExit(main())

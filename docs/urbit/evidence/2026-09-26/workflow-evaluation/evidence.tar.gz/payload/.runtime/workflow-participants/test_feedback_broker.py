"""Authored host-only broker regressions. Every native command is replaced.

No fake ship, guard scope, subprocess or participant is launched by this file.
The authored receipt shapes below test admission, not native authenticity.
"""
from contextlib import ExitStack
import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import feedback_broker as B


def shaped_records(binding, task='T01', attempt=1, status='pass', files=None):
    guard = {'status': 'completed', 'exit_code': 0, 'launched': True, 'reason': None, 'cleanup': [],
             'run_id': 'e' * 32, 'guard_sha256': 'a' * 64, 'policy': binding['policy']}
    lease = {key: guard[key] for key in ('run_id', 'guard_sha256', 'policy')}
    inner = {'protocol': 'stead.skill-native-adapter/1', 'public_feedback': True,
             'prequalification': False, 'condition': 'baseline', 'feedback_task': task,
             'feedback_attempt': attempt, 'source_commit': binding['head'],
             'package_sha256': B.adapter.PACKAGE_SHA, 'toolchain_sha256': binding['toolchain_sha256'],
             'loaded_supervisor_source_sha256': binding['harness_sha256'],
             'candidate_files_sha256': {task: files or {}}, 'candidate_inputs_after': {task: files or {}},
             'loaded_closure': {'AUTHORED': 'HOST-ONLY'}, 'loaded_closure_after': {'AUTHORED': 'HOST-ONLY'},
             'status': status, 'execution_guard': lease, 'checks': [], 'commands': [], 'public_command_start': 0,
             'tasks': [{'id': task, 'status': 'passed' if status == 'pass' else 'failed',
                        'error': None if status == 'pass' else 'AUTHORED ordinary task failure'}]}
    public = {**B.adapter.public_feedback_projection(inner), 'execution_guard': lease}
    result = {'status': status, 'execution_guard': lease,
              'evidence_file': '.piers/fakes/logs/skill-evaluation-host.json',
              'feedback_file': '.piers/fakes/logs/skill-evaluation-host-feedback.json'}
    return result, inner, public, guard


class BrokerHostTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='stead-feedback-broker-host-')
        self.root = Path(self.temp.name)
        self.base = self.root / '.runtime/workflow-participants'
        self.base.mkdir(parents=True)
        for name in B.CONDITIONS:
            for directory in ('input', 'candidate/T01/lib', 'calls'):
                (self.base / name / directory).mkdir(parents=True, exist_ok=True)
            (self.base / name / 'input/T02-starter-diagnostic.json').write_bytes(b'AUTHORED initial diagnostic')
        (self.base / 'baseline/candidate/T01/lib/eval-add.hoon').write_bytes(b':: AUTHORED host fixture\n')
        (self.root / '.runtime/workflow-evaluation').mkdir()
        (self.root / '.runtime/execution-runs').mkdir()
        (self.root / '.piers/fakes/logs').mkdir(parents=True)
        self.stack = ExitStack()
        self.stack.enter_context(patch.object(B, 'REPO', self.root))
        self.stack.enter_context(patch.object(B, 'BASE', self.base))
        self.stack.enter_context(patch.object(B, 'remotes'))
        self.stack.enter_context(patch.object(B.subprocess, 'run', side_effect=AssertionError('No subprocess in host broker tests')))
        self.stack.enter_context(patch.object(B.subprocess, 'check_output', side_effect=AssertionError('No subprocess in host broker tests')))
        self.binding = {'head': 'b' * 40, 'inventories': {'scripts/urbit': {'execution_policy.py': 'a' * 64}},
                        'harness_sha256': 'c' * 64, 'toolchain_sha256': 'd' * 64, 'policy': {'AUTHORED': True}}
        self.addCleanup(self.cleanup)

    def cleanup(self):
        self.stack.close()
        for path in self.root.rglob('*'):
            if not path.is_symlink() and path.is_dir():
                path.chmod(0o700)
        self.temp.cleanup()

    @property
    def role(self):
        return self.base / 'baseline'

    def test_ledger_allows_three_create_only_attempts_and_never_refunds_failed_attempts(self):
        for number in (1, 2, 3):
            attempt, target = B.reserve_attempt(self.role, 'T01')
            self.assertEqual(attempt, number)
            B.immutable(target / 'result.json', B.encoded({'status': 'failed'}))
        with self.assertRaisesRegex(ValueError, 'three public attempts'):
            B.reserve_attempt(self.role, 'T01')
        with self.assertRaises(FileExistsError):
            B.immutable(self.role / 'feedback-attempts/T01/1/result.json', b'overwrite')

    def test_unfinished_or_cleanup_unverified_attempt_blocks_later_reservation(self):
        _, target = B.reserve_attempt(self.role, 'T01')
        with self.assertRaises(FileNotFoundError):
            B.reserve_attempt(self.role, 'T01')
        B.immutable(target / 'result.json', B.encoded({'status': 'failed', 'startup_attempted': True,
                                                      'owned_run': {'run_id': 'e' * 32}}))
        with self.assertRaisesRegex(ValueError, 'cleanup is incomplete'):
            B.reserve_attempt(self.role, 'T01')

    def test_shared_wrapper_lock_excludes_broker_file_operations(self):
        with B.policy.HeavyRunLock(self.role / '.fileops-v2.lock'):
            with self.assertRaises(BlockingIOError):
                B.evaluate('baseline', 'T01')
        self.assertFalse((self.role / 'feedback-attempts').exists())

    def test_snapshot_is_exact_read_only_and_not_affected_by_later_candidate_edits(self):
        snapshot, files = B.snapshot(self.role, 'T01', 1)
        self.assertEqual(files, B.adapter.hashes(B.task_files(self.role / 'candidate/T01')))
        self.assertEqual(snapshot.stat().st_mode & 0o777, 0o500)
        leaf = snapshot / 'lib/eval-add.hoon'
        self.assertEqual(leaf.stat().st_mode & 0o777, 0o400)
        (self.role / 'candidate/T01/lib/eval-add.hoon').write_text(':: later edit\n')
        self.assertEqual(B.adapter.hashes(B.task_files(snapshot)), files)
        with self.assertRaises(FileExistsError):
            B.snapshot(self.role, 'T01', 1)

    def test_task_snapshot_rejects_symlink_hardlink_and_extra_file_bounds(self):
        source = self.role / 'candidate/T01'
        extra = source / 'redirect'
        extra.symlink_to(source / 'lib/eval-add.hoon')
        with self.assertRaises(ValueError):
            B.snapshot(self.role, 'T01', 1)
        extra.unlink()
        os.link(source / 'lib/eval-add.hoon', extra)
        with self.assertRaises((ValueError, B.policy.GuardError)):
            B.snapshot(self.role, 'T01', 1)

    def test_actual_public_task_failure_is_publishable_only_with_clean_guard(self):
        result, inner, public, guard = shaped_records(self.binding, status='fail')
        admitted = B.admit_feedback(result, B.encoded(inner), B.encoded(public), guard,
                                     self.binding, 'baseline', 'T01', 1, {})
        self.assertEqual(admitted['status'], 'fail')
        self.assertIsNone(admitted['infrastructure_error'])
        for changed in ({'status': 'failed'}, {'exit_code': -15}, {'run_id': 'f' * 32},
                        {'cleanup': [{'error': 'unverified'}]}, {'policy': {'weakened': True}}):
            with self.subTest(changed=changed), self.assertRaisesRegex(ValueError, 'clean completed outer guard'):
                B.admit_feedback(result, B.encoded(inner), B.encoded(public), guard | changed,
                                   self.binding, 'baseline', 'T01', 1, {})

    def test_private_or_infrastructure_fields_never_publish_as_public_feedback(self):
        result, inner, public, guard = shaped_records(self.binding)
        for altered in (public | {'private_secret': 'must never publish'},
                        public | {'infrastructure_error': 'guard failure'},
                        public | {'private_scoring': True}):
            with self.subTest(altered=altered), self.assertRaisesRegex(ValueError, 'Unexpected/private/infrastructure'):
                B.admit_feedback(result, B.encoded(inner), B.encoded(altered), guard,
                                   self.binding, 'baseline', 'T01', 1, {})
        changed = copy.deepcopy(inner)
        changed['candidate_inputs_after'] = {'T01': {'wrong': '0' * 64}}
        with self.assertRaisesRegex(ValueError, 'input binding mismatch'):
            B.admit_feedback(result, B.encoded(changed), B.encoded(public), guard,
                               self.binding, 'baseline', 'T01', 1, {})

    def test_oversized_public_feedback_is_retained_outside_participant_input(self):
        with self.assertRaisesRegex(ValueError, 'per-file workspace bound'):
            B.publishable_space(self.role, b'x' * (B.workspace.MAX_FILE + 1))
        self.assertFalse((self.role / 'input/feedback').exists())

    def mock_commands(self, *, task_status='pass', fail=None):
        case = self
        class AuthoredCommands:
            calls = []
            stage = 'stopped'
            def __init__(self, attempt):
                self.attempt = attempt
            def status(self):
                return {'stage': self.stage, 'execution_guard': {'run_id': 'e' * 32} if self.stage == 'ready' else {}}
            def call(self, label, argv, timeout=180):
                self.calls.append(label)
                run = case.root / '.runtime/execution-runs/four-fakes-authored'
                if label == 'start':
                    (run / 'control').mkdir(parents=True)
                    (run / '.stead-disposable.json').write_bytes(B.encoded({'purpose': 'host native execution guard', 'run_id': 'e' * 32}))
                    (run / 'control/lease.json').write_bytes(B.encoded({'run_id': 'e' * 32}))
                    (run / 'control/source-context.json').write_bytes(B.encoded({
                        'source_commit': case.binding['head'], 'harness_sha256': case.binding['harness_sha256'],
                        'committed_bytes_verified': True, 'dirty_paths': []}))
                    self.stage = 'ready'
                if label == fail:
                    return 1, b'authored failure', b''
                if label == 'feedback':
                    task = case.root / '.runtime/workflow-evaluation/feedback/baseline/T01/1'
                    files = B.adapter.hashes(B.task_files(task))
                    result, inner, public, _ = shaped_records(case.binding, status=task_status, files=files)
                    (case.root / result['evidence_file']).write_bytes(B.encoded(inner))
                    (case.root / result['feedback_file']).write_bytes(B.encoded(public))
                    if fail == 'snapshot-change':
                        changed = task / 'lib/eval-add.hoon'
                        changed.chmod(0o600)
                        changed.write_bytes(b'changed after execution')
                    return 0 if task_status == 'pass' else 1, B.encoded(result), b''
                if label == 'stop':
                    self.stage = 'stopped'
                    guard = shaped_records(case.binding)[3]
                    if fail == 'guard':
                        guard.update(status='failed', exit_code=-15)
                    (run / 'report.json').write_bytes(B.encoded(guard))
                return 0, b'', b''
        self.stack.enter_context(patch.object(B, 'source_binding', return_value=self.binding))
        self.stack.enter_context(patch.object(B, 'prior_prequalification', return_value=({'authored': True}, b'AUTHORED initial diagnostic')))
        self.stack.enter_context(patch.object(B, 'Commands', AuthoredCommands))
        return AuthoredCommands

    def test_supervised_parent_flow_publishes_expected_task_failure_after_stop(self):
        commands = self.mock_commands(task_status='fail')
        result = B.evaluate('baseline', 'T01')
        self.assertEqual(result['status'], 'published')
        self.assertEqual(result['public_status'], 'fail')
        self.assertTrue(result['cleanup_completed'])
        self.assertEqual(commands.calls, ['start', 'wait-ready', 'feedback', 'stop'])
        published = self.role / 'input/feedback/T01-1.json'
        self.assertEqual(B.document(published)['status'], 'fail')
        self.assertEqual(B.digest(B.read(published)), result['feedback_sha256'])

    def test_wait_failure_still_stops_only_the_owned_fixture_and_retains_failed_attempt(self):
        commands = self.mock_commands(fail='wait-ready')
        with self.assertRaisesRegex(ValueError, 'readiness failed'):
            B.evaluate('baseline', 'T01')
        self.assertEqual(commands.calls, ['start', 'wait-ready', 'stop'])
        record = B.document(self.role / 'feedback-attempts/T01/1/result.json')
        self.assertEqual(record['status'], 'failed')
        self.assertTrue(record['cleanup_completed'])
        self.assertFalse((self.role / 'input/feedback/T01-1.json').exists())

    def test_stop_failure_retains_failure_and_blocks_next_request(self):
        commands = self.mock_commands(fail='stop')
        with self.assertRaisesRegex(ValueError, 'stop failed'):
            B.evaluate('baseline', 'T01')
        self.assertIn('stop', commands.calls)
        self.assertFalse((self.role / 'input/feedback/T01-1.json').exists())
        with self.assertRaisesRegex(ValueError, 'cleanup is incomplete'):
            B.reserve_attempt(self.role, 'T01')

    def test_ambiguous_startup_ownership_is_never_treated_as_proven_no_launch(self):
        commands = self.mock_commands()
        with patch.object(B, 'new_guard', side_effect=ValueError('ambiguous newly started guard')):
            with self.assertRaisesRegex(ValueError, 'ambiguous newly started guard'):
                B.evaluate('baseline', 'T01')
        self.assertEqual(commands.calls, ['start'])
        record = B.document(self.role / 'feedback-attempts/T01/1/result.json')
        self.assertTrue(record['startup_attempted'])
        self.assertFalse(record['ownership_resolved'])
        self.assertNotIn('no_launch_refusal', record)
        self.assertFalse((self.role / 'input/feedback/T01-1.json').exists())
        with self.assertRaisesRegex(ValueError, 'cleanup is incomplete'):
            B.reserve_attempt(self.role, 'T01')

    def test_failed_guard_never_publishes_passing_task(self):
        self.mock_commands(fail='guard')
        with self.assertRaisesRegex(ValueError, 'clean completed outer guard'):
            B.evaluate('baseline', 'T01')
        self.assertFalse((self.role / 'input/feedback/T01-1.json').exists())
        self.assertEqual(B.document(self.role / 'feedback-attempts/T01/1/guard.json')['status'], 'failed')

    def test_snapshot_change_after_execution_never_publishes(self):
        self.mock_commands(fail='snapshot-change')
        with self.assertRaisesRegex(ValueError, 'snapshot changed'):
            B.evaluate('baseline', 'T01')
        self.assertFalse((self.role / 'input/feedback/T01-1.json').exists())

    def test_other_fixture_owner_is_never_stopped(self):
        owner = self.root / '.runtime/execution-runs/four-fakes-authored'
        owner.mkdir()
        class Other:
            def status(self):
                return {'stage': 'ready', 'execution_guard': {'run_id': 'f' * 32}}
            def call(self, *args, **kwargs):
                raise AssertionError('Must not issue stop to unrelated fixture')
        with self.assertRaisesRegex(ValueError, 'different fixture owner'):
            B.stop_owned(Other(), (owner, 'e' * 32), set())


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Parent-only final snapshots and one-shot private native scoring.

Preparation/source review does not run this file. After BOTH participants have
stopped, freeze each submission, then score each condition serially:
  python3 .runtime/workflow-participants/final_score.py freeze CONDITION \
      --participants-stopped --submission-record .runtime/workflow-participants/RECORD.json
  python3 .runtime/workflow-participants/final_score.py score CONDITION --participants-stopped

Only the parent may invoke this. No private result is published to role inputs.
The stopped flag is the parent's attestation, not a tool-level isolation proof.
Actual context/timing/tool audits and independent semantic review remain gates.
Any created scoring intent consumes this helper's sole attempt, including an
infrastructure failure. There is no repair, resume, retry or reset operation.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import os
from pathlib import Path
import re
import signal
import stat
import sys

sys.dont_write_bytecode = True
import feedback_broker as broker

BASE, REPO = broker.BASE, broker.REPO
adapter, policy = broker.adapter, broker.policy
require, read, document = broker.require, broker.read, broker.document
immutable, encoded, digest = broker.immutable, broker.encoded, broker.digest
LOADED_SCORE_SHA = digest(read(Path(__file__)))
LEDGER = BASE / 'private-scores'
WORKFLOW = REPO / '.runtime/workflow-evaluation'


def private_directory(path, *, create=False):
    if create:
        broker.directory(path)
    with policy.directory_fd(path) as fd:
        info = os.fstat(fd)
        require(info.st_uid == os.getuid() and stat.S_ISDIR(info.st_mode)
                and not info.st_mode & 0o077, 'Owned private directory required: ' + str(path))
    return path


def once_directory(path):
    with policy.directory_fd(path.parent) as parent:
        os.mkdir(path.name, 0o700, dir_fd=parent)
        os.fsync(parent)
    return path


def current_binding():
    require(digest(read(Path(__file__))) == LOADED_SCORE_SHA, 'Loaded private scorer changed')
    return {**broker.source_binding(), 'private_score_helper_sha256': LOADED_SCORE_SHA}


def expected_paths(oracles):
    result = set()
    for task in oracles['tasks']:
        paths = set(task['editable_files'])
        if task['id'] == 'T05':
            paths.add('lib/eval-authorization.hoon')
        result.update(task['id'] + '/' + name for name in paths)
    require(len(result) == 12 and {name.split('/')[0] for name in result} == set(adapter.TASKS),
            'Frozen twelve-file/six-task interface changed')
    return result


def exact_files(path, *, maximum=32):
    values = adapter.files(path, maximum=maximum)
    require(all(read(path / name) == raw for name, raw in values.items()), 'Input changed or contains a hard link')
    return values


def task_hashes(values):
    return {task: adapter.hashes({name.split('/', 1)[1]: raw for name, raw in values.items()
                                 if name.startswith(task + '/')}) for task in adapter.TASKS}


def copy_tree(target, values):
    once_directory(target)
    directories = {target}
    for name, raw in sorted(values.items()):
        parts = Path(name).parts
        require(parts and not Path(name).is_absolute() and '..' not in parts, 'Escaping snapshot path')
        path = target
        for part in parts[:-1]:
            path = path / part
            if path not in directories:
                once_directory(path)
                directories.add(path)
        immutable(path / parts[-1], raw)
    require(exact_files(target, maximum=128) == values, 'Snapshot readback differs')
    for path in sorted(directories, key=lambda item: len(item.parts), reverse=True):
        with policy.directory_fd(path) as fd:
            os.fchmod(fd, 0o500)
            os.fsync(fd)


def reference(path):
    raw = read(path)
    return {'path': str(path.relative_to(REPO)), 'bytes': len(raw), 'sha256': digest(raw)}


def freeze(condition, submission):
    role = BASE / condition
    with policy.HeavyRunLock(BASE / 'native-feedback.lock'), policy.HeavyRunLock(role / '.fileops-v2.lock'):
        private_directory(LEDGER, create=True)
        private_directory(WORKFLOW)
        record_dir = once_directory(LEDGER / condition)
        record = {'protocol': 'stead.final-candidate-snapshot/1', 'condition': condition,
                  'status': 'incomplete', 'started_at': broker.now(),
                  'parent_attested_both_participants_stopped': True,
                  'native_execution': False, 'qualifies_phase': False}
        immutable(record_dir / 'freeze-intent.json', encoded(record))
        try:
            submission = submission.absolute()
            require(submission.is_relative_to(BASE) and '..' not in submission.parts
                    and not any(submission.is_relative_to(BASE / role) for role in broker.CONDITIONS),
                    'Parent submission record must be outside participant workspaces')
            raw_submission = read(submission)
            require(raw_submission, 'Actual final-submission/cutoff record required')
            immutable(record_dir / 'submission-record', raw_submission)
            record['submission_record'] = reference(record_dir / 'submission-record')
            binding = current_binding()
            proof, diagnostic = broker.prior_prequalification(binding)
            require(all(read(BASE / other / 'input/T02-starter-diagnostic.json') == diagnostic
                        for other in broker.CONDITIONS), 'Initial observed T02 diagnostics differ')
            _, oracles = adapter.verify_package(REPO / 'tests/urbit/skill_evaluation')
            wanted = expected_paths(oracles)
            selected = exact_files(role / 'candidate')
            target = WORKFLOW / condition
            record.update(binding=binding, prequalification=proof,
                          initial_diagnostic_sha256=digest(diagnostic),
                          snapshot=str(target.relative_to(REPO)),
                          files=[{'path': name, 'bytes': len(raw), 'sha256': digest(raw)}
                                 for name, raw in sorted(selected.items())],
                          files_sha256=task_hashes(selected), expected_paths=sorted(wanted),
                          missing_paths=sorted(wanted - set(selected)), extra_paths=sorted(set(selected) - wanted))
            immutable(record_dir / 'freeze-inputs.json', encoded(record))
            copy_tree(target, selected)
            require(exact_files(role / 'candidate') == selected == exact_files(target), 'Submission changed during freeze')
            require(current_binding() == binding and broker.prior_prequalification(binding)[0] == proof,
                    'Source or prequalification changed during freeze')
            record['status'] = 'ready' if set(selected) == wanted else 'invalid-submission-inventory'
            # Wrong/missing files remain exactly captured and cannot be repaired
            # through this helper. They are not invented native task failures.
            return record
        except BaseException as error:
            record['error'] = type(error).__name__ + ': ' + str(error)
            raise
        finally:
            record['completed_at'] = broker.now()
            immutable(record_dir / 'freeze-result.json', encoded(record))


def condition_reports(condition):
    root = REPO / '.piers/fakes/logs'
    with policy.directory_fd(root):
        entries = list(root.iterdir())
    require(len(entries) < 8192, 'Fixture log inventory bound')
    pattern = re.compile(r'skill-evaluation-[0-9]{8}T[0-9]{6}Z-' + re.escape(condition) + r'\.json')
    return {entry.name for entry in entries if pattern.fullmatch(entry.name)}


def store_raw(record_dir, name, raw, record):
    immutable(record_dir / name, raw)
    record.setdefault('artifacts', {})[name] = reference(record_dir / name)


def validate_execution(inner, result, guard, binding, proof, files, values, content, oracles):
    """Admit a complete observed run; this does not independently rescore Hoon."""
    linked = inner.get('execution_guard', {})
    require(guard.get('status') == 'completed' and guard.get('exit_code') == 0
            and guard.get('reason') is None and guard.get('launched') is True and not guard.get('cleanup')
            and guard.get('run_id') == linked.get('run_id') == result.get('execution_guard', {}).get('run_id')
            and guard.get('guard_sha256') == linked.get('guard_sha256')
                == binding['inventories']['scripts/urbit']['execution_policy.py']
            and guard.get('policy') == linked.get('policy') == binding['policy'],
            'Exact clean completed linked outer guard required')
    closure = {'/code/' + name: binding['inventories']['scripts/urbit'][name]
               for name in ('core_conn.py', 'conn.py', 'execution_policy.py', 'skill_evaluation_support.py')}
    require(inner.get('protocol') == 'stead.skill-native-adapter/1' and inner.get('prequalification') is False
            and inner.get('public_feedback') is False and inner.get('feedback_task') is None
            and inner.get('feedback_attempt') is None and inner.get('qualifies_phase') is False
            and inner.get('source_commit') == binding['head'] and inner.get('package_sha256') == adapter.PACKAGE_SHA
            and inner.get('loaded_supervisor_source_sha256') == binding['harness_sha256']
            and inner.get('toolchain_sha256') == binding['toolchain_sha256']
            and inner.get('loaded_closure') == inner.get('loaded_closure_after') == closure
            and inner.get('candidate_files_sha256') == inner.get('candidate_inputs_after') == files
            and inner.get('prior_prequalification') == proof['refs']
            and not any(inner.get(key) for key in ('cleanup_error', 'final_binding_error', 'native_execution_interrupted'))
            and not result.get('feedback_infrastructure_failure'), 'Private execution/source/input binding incomplete')
    rows, checks, commands = inner.get('tasks'), inner.get('checks'), inner.get('commands')
    require(isinstance(rows, list) and [row.get('id') for row in rows] == list(adapter.TASKS)
            and all(row.get('status') in ('passed', 'failed') for row in rows)
            and isinstance(checks, list) and checks and isinstance(commands, list) and commands,
            'Missing, duplicate or unexecuted private task inventory')
    require(all(isinstance(row.get('name'), str) and type(row.get('passed')) is bool for row in checks),
            'Invalid native check record')
    required = {'loaded-adapter-closure-current', 'loaded-supervisor-current', 'actual-evaluator-controls',
                'candidate-inputs-unchanged', 'loaded-adapter-closure-still-current', 'loaded-supervisor-still-current',
                'deliberate-false-native-expectation:native-evaluator-success',
                'deliberate-false-native-expectation:exact-nonempty-result-frame'}
    failed_prefixes = tuple(row['id'] + suffix for row in rows if row['status'] == 'failed' for suffix in (':', '-'))
    require(required <= {row['name'] for row in checks if row['passed']}
            and all(row['passed'] or row['name'] == 'all-six-native-tasks-passed'
                    or row['name'].startswith(failed_prefixes)
                    for row in checks), 'Admission/control/source failure is infrastructure')

    def require_checks(names):
        require(set(names) <= {check['name'] for check in checks if check['passed']}
                and not any(check['name'] in names and not check['passed'] for check in checks),
                'Passed task lacks obligatory positive checks or contains a contradictory failure')

    require(inner.get('evaluator_controls', {}).get('status') == 'passed', 'Native evaluator controls did not pass')
    control = inner.get('failure_control')
    require(adapter.valid_observation(control, 'deliberate-false-native-expectation')
            and control['actual_jam_hex'] != '02' and control['actual_noun'].strip() not in ('0', '~'),
            'Nonempty actual negative native control required')
    observed = [row for row in commands if row.get('kind') == 'native-observed-noun']
    require(len({row.get('label') for row in observed}) == len(observed)
            and {'kind': 'native-observed-noun', 'status': 'completed', **control} in observed,
            'Missing or duplicated actual native observations')

    def observation_input(actual, *, pure):
        # The adapter appends the actual pure/Dojo response immediately before
        # its observed-noun decoder record. Bind those retained bytes, not two
        # copies of the same summary or an unrelated successful invocation.
        entry = {'kind': 'native-observed-noun', 'status': 'completed', **actual}
        indices = [index for index, command in enumerate(commands) if command == entry]
        require(len(indices) == 1 and indices[0] > 0, 'Native observation has no unique preceding response')
        command = commands[indices[0] - 1]
        label = actual['label']
        require(command.get('status') == 'completed' and isinstance(command.get('stdout'), str),
                'Native observation follows an incomplete response')
        if pure:
            matching = [item for item in commands if item.get('kind') == 'native-pure-evaluator'
                        and item.get('label') == label]
            require(len(matching) == 1 and matching[0] == command
                    and type(command.get('exit_code')) is int and command['exit_code'] == 0
                    and command.get('input_sha256') == inner['generated_source_files_sha256'].get(label + '.hoon')
                    and isinstance(command.get('stderr'), str) and 'eval: bail:' not in command['stderr'],
                    'Missing exact successful evaluator input/output for native observation')
        else:
            require(command.get('kind') == 'native-dojo' and command.get('source') == '+skill-eval-check',
                    'Missing actual generator command before its native observation')
        require(adapter.result_jam(command['stdout']).hex() == actual['actual_jam_hex'],
                'Actual native response disagrees with its observed jam')

    observation_input(control, pure=True)
    inventory = adapter.prequalification_inventory(content, oracles)
    for row in rows:
        name = row['id']
        if row['status'] == 'failed':
            require(isinstance(row.get('error'), str) and row['error'], 'Failed task has no observed error')
            continue
        wanted = inventory[name]
        cases = wanted['cases']
        required_task = {name + ':exact-file-inventory', name + ':nonzero-native-results'}
        if name in ('T01', 'T02'):
            required_task.add(name + ':declared-public-interface')
        if name in ('T03', 'T04'):
            required_task.update((name + ':ten-Gall-arms', name + ':only-authorized-arms-edited',
                                  'installed-file:base:gen/skill-eval-check.hoon',
                                  'loaded-clay-file:base:gen/skill-eval-check.hoon'))
        if name != 'T06':
            for path in files[name]:
                if path.endswith('.hoon'):
                    required_task.update(('installed-file:base:' + path, 'loaded-clay-file:base:' + path))
        if name == 'T05':
            tests = values['T05/tests/eval-coverage.hoon'].decode()
            cases = [arm for arm in adapter.arm_names(tests) if arm.startswith('test-')]
            require(len(cases) >= 4 and row.get('requires_independent_test_semantics_review') is True
                    and row.get('mutants') == [Path(path).stem for path in oracles['tasks'][4]['mutants']],
                    'Missing candidate test-arm/mutant inventory')
            required_task.update(('T05:immutable-subject', 'T05:exact-test-imports',
                                  'T05:nonempty-complete-arm-inventory', 'T05:coverage-report'))
            required_task.update('T05:original-arm-retained:' + arm for arm in oracles['tasks'][4]['preserved_test_arms'])
        if name == 'T06':
            required_task.update(('T06:exact-supplied-bytes', 'T06:exact-assembly-manifest',
                                  'T06:repeat-empty-assembly', 'T06:pinned-platform-baseline',
                                  'T06:exact-native-mounted-desk', 'T06:native-clean-generator-result'))
            paths = set(adapter.T06_PLATFORM_ADDITIONS)
            paths.update(path.removeprefix('desk/') for path in oracles['tasks'][5]['source_mapping'])
            for path in paths:
                required_task.add('installed-file:skill-eval:' + path)
                if path.endswith('.hoon'):
                    required_task.add('loaded-clay-file:skill-eval:' + path)
            for path, source in adapter.T06_METADATA_CHECKS.items():
                required_task.add('loaded-clay-metadata:skill-eval:' + path)
                metadata = [command for command in commands if command.get('kind') == 'native-dojo'
                            and command.get('source') == source]
                require(len(metadata) == 1 and metadata[0].get('status') == 'completed'
                        and metadata[0].get('stdout', '').strip() == '%.y', 'Missing actual typed desk metadata readback')
        required_task.update(label + ':exact-nonempty-result-frame' for label in wanted['labels'] if name != 'T06')
        if name in ('T01', 'T02', 'T05'):
            required_task.update(label + ':native-evaluator-success' for label in wanted['labels'])
        require_checks(required_task)
        results = row.get('results')
        require(row.get('classification') == wanted['classification'] and row.get('expected_cases') == cases
                and row.get('observed_cases') == cases and isinstance(results, list)
                and len(results) == len(wanted['labels']), 'Incomplete passed task result inventory')
        for actual, label in zip(results, wanted['labels'], strict=True):
            if name == 'T06':
                require(actual == {'label': label, 'actual_noun': '42'}
                        and any(command.get('kind') == 'native-dojo' and command.get('status') == 'completed'
                                and command.get('source') == '+skill-eval!eval-desk-probe'
                                and command.get('stdout', '').strip() == '42' for command in commands),
                        'Missing actual clean-desk invocation')
            else:
                require(adapter.valid_observation(actual, label)
                        and {'kind': 'native-observed-noun', 'status': 'completed', **actual} in observed,
                        'Passed task lacks exact native observation')
                observation_input(actual, pure=name in ('T01', 'T02', 'T05'))
    passed = sum(row['status'] == 'passed' for row in rows)
    expected = 'pass' if passed == 6 else 'fail'
    aggregate = [row for row in checks if row['name'] == 'all-six-native-tasks-passed']
    require(len(aggregate) == 1 and aggregate[0]['passed'] is (passed == 6), 'Aggregate native check missing or inconsistent')
    require(inner.get('status') == result.get('status') == expected and result.get('tasks_passed') == passed,
            'Aggregate private status contradicts task observations')
    return [{'id': row['id'], 'status': row['status']} for row in rows]


def score(condition):
    role, record_dir, target = BASE / condition, LEDGER / condition, WORKFLOW / condition
    with policy.HeavyRunLock(BASE / 'native-feedback.lock'), policy.HeavyRunLock(role / '.fileops-v2.lock'):
        private_directory(record_dir)
        require(not (record_dir / 'score-intent.json').exists() and not (record_dir / 'score-result.json').exists(),
                'Private attempt already reserved: no rerun, repair or resume')
        record = {'protocol': 'stead.parent-private-score/1', 'condition': condition,
                  'status': 'infrastructure-incomplete', 'started_at': broker.now(),
                  'startup_attempted': False, 'ownership_resolved': False, 'cleanup_completed': False,
                  'private_operation_attempted': False, 'parent_attested_both_participants_stopped': True,
                  'native_execution': 'not-started', 'qualifies_phase': False,
                  'independent_semantics_and_trace_review': 'pending'}
        immutable(record_dir / 'score-intent.json', encoded(record))
        commands = broker.Commands(record_dir)
        owner = before_runs = before_reports = result = inner = guard = None
        errors = []
        try:
            for other in broker.CONDITIONS:
                final = document(LEDGER / other / 'freeze-result.json')
                require(final.get('condition') == other and final.get('status') in ('ready', 'invalid-submission-inventory')
                        and final.get('parent_attested_both_participants_stopped') is True, 'Both final submissions must be frozen')
            frozen = document(record_dir / 'freeze-result.json')
            require(frozen.get('status') == 'ready', 'Invalid or incomplete frozen candidate inventory')
            binding = current_binding()
            proof, _ = broker.prior_prequalification(binding)
            values = exact_files(target)
            content, oracles = adapter.verify_package(REPO / 'tests/urbit/skill_evaluation')
            require(set(values) == expected_paths(oracles) and task_hashes(values) == frozen['files_sha256']
                    and binding == frozen['binding'] and proof == frozen['prequalification'], 'Frozen submission/source changed')
            record.update(binding=binding, prequalification=proof, snapshot=frozen['snapshot'],
                          files_sha256=frozen['files_sha256'], freeze_receipt=reference(record_dir / 'freeze-result.json'))
            immutable(record_dir / 'score-inputs.json', encoded(record))
            require(commands.status().get('stage') in ('stopped', 'not-created'), 'Refusing to adopt another live fixture')
            before_runs, before_reports = broker.guard_runs(), condition_reports(condition)
            record['startup_attempted'] = True
            immutable(record_dir / 'startup-intent.json', encoded({'started_at': broker.now(), 'guard_runs_before': sorted(before_runs)}))
            try:
                code, _, _ = commands.call('start', ['make', 'start'], 180)
                owner = broker.new_guard(before_runs)
                require(code == 0, 'Native startup refused or failed')
                require(commands.status().get('execution_guard', {}).get('run_id') == owner[1], 'Different live guard owner')
                code, _, _ = commands.call('wait-ready', ['make', 'wait-ready'], 1205)
                require(code == 0, 'Native readiness failed')
                immutable(record_dir / 'private-operation-intent.json', encoded({'condition': condition, 'started_at': broker.now()}))
                record['private_operation_attempted'] = True
                code, output, _ = commands.call('private-score', [sys.executable, 'scripts/urbit/harness.py',
                                               'skill-evaluation', '--condition', condition], 3605)
                result = adapter.json_bytes(output)
                store_raw(record_dir, 'controller-result.json', output, record)
                require(result.get('condition') == condition and result.get('status') in ('pass', 'fail')
                        and code == (0 if result['status'] == 'pass' else 1), 'Unexpected private controller outcome')
            finally:
                try:
                    if owner is None:
                        owner = broker.new_guard(before_runs)
                    record['ownership_resolved'] = True
                    record['owned_run'] = {'run_id': owner[1], 'path': str(owner[0].relative_to(REPO))}
                    broker.stop_owned(commands, owner, before_runs)
                    record['cleanup_completed'] = True
                except BaseException as error:
                    errors.append('cleanup: ' + type(error).__name__ + ': ' + str(error))
                if owner is not None:
                    for name, source in (('guard.json', owner[0] / 'report.json'),
                                         ('source-context.json', owner[0] / 'control/source-context.json')):
                        try:
                            raw = broker.stopped_guard(*owner)[0] if name == 'guard.json' else read(source)
                            store_raw(record_dir, name, raw, record)
                            if name == 'guard.json':
                                guard = adapter.json_bytes(raw)
                                record['native_execution'] = 'launched' if guard.get('launched') else 'not-launched'
                        except BaseException as error:
                            errors.append(name + ': ' + type(error).__name__ + ': ' + str(error))
                try:
                    new_reports = sorted(condition_reports(condition) - before_reports)
                    require(len(new_reports) <= 1, 'Ambiguous private report inventory')
                    if new_reports:
                        path = REPO / '.piers/fakes/logs' / new_reports[0]
                        raw = read(path)
                        store_raw(record_dir, 'native-inner.json', raw, record)
                        inner = adapter.json_bytes(raw)
                        record['native_report_original'] = str(path.relative_to(REPO))
                        inputs = path.with_name(path.stem + '-inputs')
                        if inputs.is_dir():
                            generated = exact_files(inputs, maximum=128)
                            copy_tree(record_dir / 'native-inputs', generated)
                            record['native_inputs_sha256'] = adapter.hashes(generated)
                except BaseException as error:
                    errors.append('native evidence: ' + type(error).__name__ + ': ' + str(error))
            require(not errors and owner is not None and result is not None and inner is not None and guard is not None,
                    'Private attempt or evidence is incomplete')
            require(result.get('evidence_file') == record['native_report_original']
                    and inner.get('condition') == condition, 'Controller/private report reference mismatch')
            context = document(record_dir / 'source-context.json')
            require(context.get('source_commit') == binding['head'] and context.get('committed_bytes_verified') is True
                    and context.get('dirty_paths') == [] and context.get('harness_sha256') == binding['harness_sha256'],
                    'Exact owned source context required')
            require(commands.status().get('stage') == 'stopped' and not (REPO / '.piers/fakes/unclean-live.json').exists(),
                    'Fixture did not stop cleanly')
            require(current_binding() == binding and broker.prior_prequalification(binding)[0] == proof
                    and exact_files(target) == values, 'Source, proof or final snapshot changed during scoring')
            generated = inner.get('generated_source_files_sha256')
            require(isinstance(generated, dict) and generated and inner.get('generated_source_files_after') == generated
                    and {name: value for name, value in record.get('native_inputs_sha256', {}).items() if '/' not in name}
                        == generated, 'Generated actual native probe source is missing or changed')
            record['tasks'] = validate_execution(inner, result, guard, binding, proof, frozen['files_sha256'],
                                                 values, content, oracles)
            record.update(status='completed-all-tasks-passed' if inner['status'] == 'pass' else 'completed-with-candidate-failures',
                          native_result=inner['status'], native_execution='completed', tasks_passed=result['tasks_passed'],
                          outer_guard_status='completed')
        except BaseException as error:
            errors.append(type(error).__name__ + ': ' + str(error))
        finally:
            record.update(errors=errors, completed_at=broker.now())
            immutable(record_dir / 'score-result.json', encoded(record))
        return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('freeze', 'score'))
    parser.add_argument('condition', choices=broker.CONDITIONS)
    parser.add_argument('--participants-stopped', action='store_true', required=True)
    parser.add_argument('--submission-record', type=Path)
    args = parser.parse_args()
    require((args.operation == 'freeze') == (args.submission_record is not None),
            'Only freeze requires a parent final-submission/cutoff record')
    def interrupted(*_):
        raise KeyboardInterrupt('Parent private scorer interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    broker.remotes()
    record = freeze(args.condition, args.submission_record) if args.operation == 'freeze' else score(args.condition)
    print(encoded({'status': record['status'], 'condition': args.condition,
                   'tasks_passed': record.get('tasks_passed'), 'qualifies_phase': False,
                   'evidence_directory': str((LEDGER / args.condition).relative_to(REPO))}).decode(), end='')
    return 0 if record['status'] in ('ready', 'completed-all-tasks-passed') else (1 if record['status'] == 'completed-with-candidate-failures' else 2)


if __name__ == '__main__':
    raise SystemExit(main())

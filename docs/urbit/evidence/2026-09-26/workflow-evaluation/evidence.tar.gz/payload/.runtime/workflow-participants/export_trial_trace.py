"""Parent-only filtered task trace export; never export hidden reasoning/context."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path(__file__).absolute().parents[2]
BASE = Path(__file__).absolute().parent
SESSIONS = Path('/home/skilgore/.codex/sessions/2026/09/26')
ROLES = {
    'baseline': 'rollout-2026-09-26T12-53-24-01a0dea2-c46c-7762-b654-dfb3a5fb4bb2.jsonl',
    'local_skill_assisted': 'rollout-2026-09-26T12-53-58-01a0dea3-4af3-7100-8991-7a0713a3f900.jsonl',
}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def raw_json(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False) + '\n').encode()

def main():
    assert subprocess.check_output(['git', 'remote', 'get-url', '--push', 'origin'], cwd=REPO, text=True).strip() == 'https://github.com/ScottTpirate/stead-urbit.git'
    dest = BASE / 'filtered-traces'
    dest.mkdir(mode=0o700)
    manifest = {'protocol': 'stead.filtered-participant-traces/1', 'not_full_rollout': True,
                'omissions': 'No reasoning, hidden system/developer content, full environment/world state, token metrics or unrelated sessions. Only task messages, complete tool calls/results, explicit model/settings and delivery metadata are retained. Encrypted task-message content remains encrypted; the separate integrator plaintext observation ledger is not a decryption.',
                'roles': {}}
    for role, filename in ROLES.items():
        source = SESSIONS / filename
        raw = source.read_bytes()
        exported, omissions, contexts, counters = [], collections.Counter(), [], collections.Counter()
        for line in raw.splitlines():
            row = json.loads(line)
            kind, item = row['type'], row.get('payload', {})
            subtype = item.get('type', '')
            selected = None
            if kind == 'session_meta':
                selected = {key: item.get(key) for key in ('id', 'cwd', 'source', 'agent_path', 'parent_thread_id', 'model_provider')}
            elif kind == 'turn_context':
                selected = {key: item.get(key) for key in ('turn_id', 'model', 'effort', 'summary', 'personality', 'cwd')}
                mode = item.get('collaboration_mode', {})
                selected['collaboration_mode'] = {'mode': mode.get('mode'), 'settings': {
                    key: mode.get('settings', {}).get(key) for key in ('model', 'reasoning_effort')}}
                contexts.append(selected)
            elif kind == 'response_item' and subtype in ('custom_tool_call', 'custom_tool_call_output', 'function_call', 'function_call_output', 'agent_message'):
                selected = item
            elif kind == 'response_item' and subtype == 'message' and item.get('role') == 'assistant' and item.get('phase') in ('commentary', 'final_answer'):
                selected = item
            elif kind == 'inter_agent_communication_metadata':
                selected = item
            elif kind == 'event_msg' and subtype in ('task_started', 'task_complete'):
                selected = {key: item.get(key) for key in ('type', 'turn_id', 'last_agent_message') if key in item}
            if selected is None:
                omissions[(kind, subtype, item.get('role', ''))] += 1
            else:
                exported.append({'timestamp': row.get('timestamp'), 'ordinal': row.get('ordinal'), 'type': kind, 'payload': selected})
                counters[kind + '/' + subtype] += 1
        assert source.read_bytes() == raw, 'Trace changed while exporting'
        output = b''.join(raw_json(value) for value in exported)
        with (dest / (role + '.jsonl')).open('xb') as stream:
            stream.write(output)
        manifest['roles'][role] = {'local_rollout_filename': filename,
            'local_rollout_bytes': len(raw), 'local_rollout_sha256': digest(raw),
            'filtered_trace': {'path': role + '.jsonl', 'bytes': len(output), 'sha256': digest(output)},
            'exported_counts': dict(counters), 'omitted_counts': [
                {'type': key[0], 'subtype': key[1], 'role': key[2], 'count': value} for key, value in sorted(omissions.items())],
            'model_contexts': contexts, 'immutable_backend_model_revision': 'unknown'}
    with (dest / 'manifest.json').open('xb') as stream:
        stream.write(raw_json(manifest))
    print(json.dumps({'roles': list(ROLES), 'directory': str(dest.relative_to(REPO)), 'classification': 'filtered task evidence; independent audit required'}))

if __name__ == '__main__':
    main()

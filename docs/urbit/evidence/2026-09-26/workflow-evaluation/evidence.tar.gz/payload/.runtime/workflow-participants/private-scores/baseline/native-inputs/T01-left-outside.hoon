=>
|%
++  add-u8
  |=  [left=@ud right=@ud]
  ^-  (unit @ud)
  ?.  (lte left 255)  ~
  ?.  (lte right 255)  ~
  =/  sum=@ud  (add left right)
  ?.  (lte sum 255)  ~
  [~ sum]
--

=/  actual  (add-u8 [256 0])
?>  =(~ actual)
^-  [@tas @ud]
[%skill-result (jam actual)]

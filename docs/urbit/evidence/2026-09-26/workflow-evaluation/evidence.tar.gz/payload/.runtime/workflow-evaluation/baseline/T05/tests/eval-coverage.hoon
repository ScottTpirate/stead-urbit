/+  *test, eval-authorization
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-spoofed-writer
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 0 0))))
++  test-other-sender
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 4 4))))
++  test-home-owner
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 0 0))))
++  test-home-owner-spoof
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 7 7))))
++  test-writer-untrusted-claim
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~nec 0 0))))
++  test-writer-owner-claim
  (expect !>(=([~ 5] (advance:eval-authorization ~bus ~zod 4 4))))
++  test-writer-nonzero
  (expect !>(=([~ 8] (advance:eval-authorization ~bus ~bus 7 7))))
++  test-expected-ahead
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 3 4))))
++  test-stale-untrusted-claim
  (expect !>(=(~ (advance:eval-authorization ~bus ~nec 2 1))))
--

"""Parent-only public workflow feedback. Never expose this as a participant tool.

Usage: python3 .runtime/workflow-participants/feedback_broker.py CONDITION TASK
The parent must own the sole native slot; this lock additionally serializes
broker calls. No raw Vere/Lens/conn operations are available here. Requests,
snapshots, commands and outcomes are create-only, and failed attempts count.
The full participant tool transcript/timing audit and private final score are
separate. This ignored support file is not a production application service.
"""
from __future__ import annotations

from contextlib import ExitStack
from dataclasses import asdict
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import signal
import subprocess
import sys
import tempfile
import time

BASE = Path(__file__).absolute().parent
REPO = BASE.parent.parent
sys.dont_write_bytecode = True
sys.pycache_prefix = '/tmp/stead-feedback-no-cache-' + secrets.token_hex(16)
sys.path.insert(0, str(REPO / 'scripts/urbit'))
import execution_policy as policy
import digests
import skill_evaluation_support as adapter
import workspace_tool as workspace

CONDITIONS = ('baseline', 'local_skill_assisted')
SOURCE_ROOTS = ('scripts/urbit', 'native', 'specs/urbit',
                'tests/urbit/native_gall_schedule', 'tests/urbit/skill_evaluation')
MAX_RECORD = 16 * 1024 * 1024
LOADED_HELPERS = digests.source_inventory(REPO / 'scripts/urbit')
LOADED_SUPPORT = {str(path): digests.sha(path) for path in (Path(__file__), BASE / 'workspace_tool.py')}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2) + '\n').encode()


def read(path):
    return digests.read_source(path, maximum=MAX_RECORD)


def document(path):
    return adapter.json_bytes(read(path))


def directory(path):
    """Create only below already verified real parents, never traverse links."""
    path = Path(path)
    with policy.directory_fd(path.parent) as parent:
        try:
            os.mkdir(path.name, 0o700, dir_fd=parent)
        except FileExistsError:
            pass
    with policy.directory_fd(path):
        pass
    return path


def immutable(path, raw, mode=0o400):
    require(isinstance(raw, bytes) and len(raw) <= MAX_RECORD, 'Evidence byte bound')
    with policy.directory_fd(path.parent) as parent:
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode, dir_fd=parent)
        with os.fdopen(fd, 'wb') as out:
            out.write(raw)
            out.flush()
            os.fsync(out.fileno())
        os.fsync(parent)


def remotes():
    for direction in ([], ['--push']):
        value = subprocess.check_output(['git', 'remote', 'get-url', *direction, 'origin'], cwd=REPO, text=True).strip()
        require(value == 'https://github.com/ScottTpirate/stead-urbit.git', 'Wrong derivative origin')
    require(subprocess.check_output(['git', 'remote', 'get-url', '--push', 'upstream'], cwd=REPO, text=True).strip()
            == 'DISABLED_UPSTREAM_PUSH', 'Upstream must remain read-only')


def source_binding():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain', '--', *SOURCE_ROOTS], cwd=REPO, text=True)
    require(re.fullmatch('[0-9a-f]{40}', head) and not dirty, 'Committed native inputs required')
    inventories = {name: digests.source_inventory(REPO / name, ignore_python_cache=name == 'scripts/urbit')
                   for name in SOURCE_ROOTS}
    require(inventories['scripts/urbit'] == LOADED_HELPERS
            and all(digests.sha(path) == value for path, value in LOADED_SUPPORT.items()), 'Loaded broker helpers changed')
    return {'head': head, 'inventories': inventories,
            'harness_sha256': digests.source_sha(REPO / 'scripts/urbit'),
            'toolchain_sha256': digest(read(REPO / 'specs/urbit/toolchain.lock.json')),
            'policy': asdict(policy.policy_from_limits(document(REPO / 'specs/urbit/urgit-candidate.lock.json')['limits'])),
            'broker_sha256': digest(read(Path(__file__))),
            'workspace_sha256': digest(read(BASE / 'workspace_tool.py'))}


def prior_prequalification(binding):
    root = REPO / '.runtime/workflow-evaluation'
    raw = read(root / 'prequalification.json')
    refs = adapter.json_bytes(raw)
    require(isinstance(refs, dict) and set(refs) == {'inner', 'guard'}, 'Exact prequalification references required')
    receipts = {}
    for key, reference in refs.items():
        path = Path(reference['path'])
        require(path.is_absolute() and path.is_relative_to('/workflow') and '..' not in path.parts,
                'Prequalification must stay inside the fixed workflow mount')
        data = read(root / path.relative_to('/workflow'))
        require(digest(data) == reference['sha256'], 'Prequalification evidence changed')
        receipts[key] = adapter.json_bytes(data)
    inner, guard = receipts['inner'], receipts['guard']
    closure = {'/code/' + name: binding['inventories']['scripts/urbit'][name]
               for name in ('core_conn.py', 'conn.py', 'execution_policy.py', 'skill_evaluation_support.py')}
    require(inner.get('protocol') == 'stead.skill-native-adapter/1' and inner.get('status') == 'pass'
            and inner.get('prequalification') is True and inner.get('condition') == 'prequalification'
            and inner.get('package_sha256') == adapter.PACKAGE_SHA
            and inner.get('loaded_supervisor_source_sha256') == binding['harness_sha256']
            and inner.get('toolchain_sha256') == binding['toolchain_sha256']
            and inner.get('loaded_closure') == inner.get('loaded_closure_after') == closure
            and guard.get('status') == 'completed' and guard.get('exit_code') == 0
            and guard.get('reason') is None and not guard.get('cleanup')
            and guard.get('policy') == inner.get('execution_guard', {}).get('policy') == binding['policy']
            and inner.get('execution_guard', {}).get('run_id') == guard.get('run_id')
            and re.fullmatch('[0-9a-f]{32}', guard.get('run_id', ''))
            and guard.get('guard_sha256') == binding['inventories']['scripts/urbit']['execution_policy.py'],
            'Completed current-source prequalification required')
    content, oracles = adapter.verify_package(REPO / 'tests/urbit/skill_evaluation')
    adapter.validate_prequalification_execution(inner, content, oracles)
    # Both roles receive this exact observed starter diagnostic before beginning.
    starter = [row for row in inner['commands'] if row.get('label') == 'T02-starter-rejection']
    require(len(starter) == 1, 'One actual T02 starter compiler diagnostic required')
    diagnostic = {'protocol': 'stead.public-starter-diagnostic/1', 'task': 'T02',
        'package_sha256': adapter.PACKAGE_SHA, 'source_commit': inner['source_commit'],
        'prequalification_sha256': refs['inner']['sha256'],
        'command': {key: starter[0][key] for key in ('argv', 'input_sha256', 'exit_code', 'stdout', 'stderr')}}
    return {'manifest_sha256': digest(raw), 'refs': refs}, encoded(diagnostic)


def publishable_space(role, raw):
    require(len(raw) <= workspace.MAX_FILE, 'Public feedback exceeds per-file workspace bound')
    with ExitStack() as stack:
        fds = {}
        for key, path in (('input', role / 'input'), ('output', role / 'candidate')):
            fds[key] = workspace.directory(path)
            stack.callback(os.close, fds[key])
        rows = workspace.inventory(fds)
    require(sum(row['kind'] == 'file' for row in rows) + 1 <= workspace.MAX_FILES
            and sum(row.get('bytes', 0) for row in rows) + len(raw) <= workspace.MAX_TOTAL
            and len(rows) + 2 <= workspace.MAX_ENTRIES, 'Public feedback exceeds workspace aggregate bound')


def publish_initial_diagnostics():
    """Parent setup only, before either participant is launched; equal bytes."""
    remotes()
    binding = source_binding()
    _, raw = prior_prequalification(binding)
    with ExitStack() as stack:
        for condition in CONDITIONS:
            role = BASE / condition
            stack.enter_context(policy.HeavyRunLock(role / '.fileops-v2.lock'))
        for condition in CONDITIONS:
            role = BASE / condition
            target = role / 'input/T02-starter-diagnostic.json'
            if target.exists():
                require(read(target) == raw, 'Existing initial diagnostic differs')
            else:
                publishable_space(role, raw)
        for condition in CONDITIONS:
            target = BASE / condition / 'input/T02-starter-diagnostic.json'
            if not target.exists():
                immutable(target, raw)
    return {'sha256': digest(raw), 'bytes': len(raw), 'conditions': list(CONDITIONS)}


def reserve_attempt(role, task):
    parent = directory(directory(role / 'feedback-attempts') / task)
    found = list(parent.iterdir())
    require(len(found) <= 3 and all(p.name in ('1', '2', '3') and p.is_dir() and not p.is_symlink() for p in found),
            'Malformed or overfull attempt ledger')
    numbers = sorted(int(path.name) for path in found)
    require(numbers == list(range(1, len(numbers) + 1)), 'Attempt ledger is not contiguous')
    for path in found:
        prior = document(path / 'result.json')
        require(prior.get('status') in ('published', 'failed')
                and (not prior.get('startup_attempted') and not (path / 'startup-intent.json').exists()
                     or prior.get('ownership_resolved') is True and prior.get('cleanup_completed') is True),
                'Prior attempt cleanup is incomplete; parent audit required')
    require(len(numbers) < 3, 'All three public attempts have been reserved')
    attempt = len(numbers) + 1
    target = parent / str(attempt)
    with policy.directory_fd(parent) as fd:
        os.mkdir(str(attempt), 0o700, dir_fd=fd)
        os.fsync(fd)
    return attempt, target


def task_files(path):
    values = adapter.files(path, maximum=8)
    require(all(read(path / name) == raw for name, raw in values.items()), 'Task input changed during capture')
    return values


def snapshot(role, task, attempt):
    source = role / 'candidate' / task
    selected = task_files(source)
    target = directory(directory(directory(REPO / '.runtime/workflow-evaluation/feedback') / role.name) / task) / str(attempt)
    with policy.directory_fd(target.parent) as fd:
        os.mkdir(target.name, 0o700, dir_fd=fd)
    for name, raw in selected.items():
        path = target / name
        for parent in reversed(path.parent.relative_to(target).parents):
            if str(parent) != '.':
                directory(target / parent)
        if path.parent != target:
            directory(path.parent)
        immutable(path, raw)
    require(task_files(source) == selected == task_files(target), 'Task changed while snapshotting')
    for path in sorted(target.rglob('*'), key=lambda p: len(p.parts), reverse=True):
        if path.is_dir():
            path.chmod(0o500)
    target.chmod(0o500)
    return target, adapter.hashes(selected)


class Commands:
    def __init__(self, attempt):
        self.attempt, self.number = attempt, 0

    def call(self, label, argv, timeout=180):
        self.number += 1
        base = self.attempt / (str(self.number).zfill(2) + '-' + label)
        immutable(base.with_suffix('.start.json'), encoded({'argv': argv, 'started_at': now(), 'timeout_seconds': timeout}))
        record = {'argv': argv, 'status': 'failed', 'exit_code': None}
        begin = time.monotonic()
        try:
            with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
                try:
                    result = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL,
                                            stdout=out, stderr=err, timeout=timeout, check=False)
                    record.update(status='completed', exit_code=result.returncode)
                finally:
                    record.update(stdout_bytes=out.seek(0, os.SEEK_END), stderr_bytes=err.seek(0, os.SEEK_END))
                    out.seek(0)
                    err.seek(0)
                    stdout, stderr = out.read(2_000_001), err.read(2_000_001)
                    record.update(stdout_hex=stdout[:2_000_000].hex(), stderr_hex=stderr[:2_000_000].hex())
            require(len(stdout) <= 2_000_000 and len(stderr) <= 2_000_000, 'Parent command output bound')
            return result.returncode, stdout, stderr
        except BaseException as error:
            record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
            raise
        finally:
            record['elapsed_seconds'] = time.monotonic() - begin
            immutable(base.with_suffix('.finish.json'), encoded(record))

    def status(self):
        code, output, _ = self.call('status', [sys.executable, 'scripts/urbit/harness.py', 'status'], 10)
        require(code == 0, 'Could not verify fixture status')
        return adapter.json_bytes(output)


def guard_runs():
    root = REPO / '.runtime/execution-runs'
    with policy.directory_fd(root):
        paths = list(root.iterdir())
    require(len(paths) < 4096, 'Execution inventory bound')
    return {path.name for path in paths}


def new_guard(before):
    new = sorted(guard_runs() - before)
    require(len(new) == 1 and new[0].startswith('four-fakes-'), 'Exactly one newly owned guarded fixture required')
    path = REPO / '.runtime/execution-runs' / new[0]
    marker = document(path / '.stead-disposable.json')
    require(marker.get('purpose') == 'host native execution guard'
            and re.fullmatch('[0-9a-f]{32}', marker.get('run_id', '')), 'Wrong execution marker')
    return path, marker['run_id']


def stopped_guard(path, run_id, timeout=30):
    deadline = time.monotonic() + timeout
    while not (path / 'report.json').exists():
        require(time.monotonic() < deadline, 'Owned outer guard did not finish')
        time.sleep(.1)
    raw = read(path / 'report.json')
    report = adapter.json_bytes(raw)
    require(report.get('run_id') == run_id, 'Final guard run ID changed')
    return raw, report


def stop_owned(commands, owner, before_runs):
    # A normal shutdown can latch STOP before its socket closes; status then
    # omits the run ID. The exact newly owned directory/lease still identifies
    # that lifetime. Never use this fallback after any other guard appeared.
    require(guard_runs() - before_runs == {owner[0].name}, 'Guard ownership changed before cleanup')
    try:
        status = commands.status()
    except Exception:
        status = {}
    current = status.get('execution_guard', {}).get('run_id')
    require(current is None or current == owner[1], 'Refusing to stop a different fixture owner')
    if current is None and status.get('stage') not in ('stopped', 'not-created'):
        lease = document(owner[0] / 'control/lease.json')
        require(lease.get('run_id') == owner[1], 'Lost owned fixture lease during cleanup')
    code, _, _ = commands.call('stop', ['make', 'stop'], 190)
    require(code == 0 and commands.status().get('stage') == 'stopped', 'Owned fixture stop failed')


def admit_feedback(result, private_raw, public_raw, guard, binding, condition, task, attempt, files):
    inner, public = adapter.json_bytes(private_raw), adapter.json_bytes(public_raw)
    expected_guard = inner.get('execution_guard', {})
    require(guard.get('status') == 'completed' and guard.get('exit_code') == 0
            and guard.get('reason') is None and guard.get('launched') is True and not guard.get('cleanup')
            and guard.get('run_id') == expected_guard.get('run_id') == result.get('execution_guard', {}).get('run_id')
            and guard.get('guard_sha256') == expected_guard.get('guard_sha256')
                == binding['inventories']['scripts/urbit']['execution_policy.py']
            and guard.get('policy') == expected_guard.get('policy') == binding['policy'], 'Exact clean completed outer guard required')
    require(inner.get('protocol') == 'stead.skill-native-adapter/1' and inner.get('public_feedback') is True
            and inner.get('prequalification') is False and inner.get('condition') == condition
            and inner.get('feedback_task') == task and inner.get('feedback_attempt') == attempt
            and inner.get('source_commit') == binding['head'] and inner.get('package_sha256') == adapter.PACKAGE_SHA
            and inner.get('loaded_supervisor_source_sha256') == binding['harness_sha256']
            and inner.get('toolchain_sha256') == binding['toolchain_sha256']
            and inner.get('candidate_files_sha256') == inner.get('candidate_inputs_after') == {task: files}
            and inner.get('loaded_closure') == inner.get('loaded_closure_after')
            and not inner.get('cleanup_error') and not inner.get('final_binding_error')
            and inner.get('status') == public.get('status') == result.get('status') in ('pass', 'fail'),
            'Public native execution/input binding mismatch')
    rows = inner.get('tasks', [])
    require(len(rows) == 1 and rows[0].get('id') == task
            and rows[0].get('status') == ('passed' if inner['status'] == 'pass' else 'failed'),
            'Feedback is not a completed public task observation')
    projection = adapter.public_feedback_projection(inner)
    require(public == {**projection, 'execution_guard': expected_guard}
            and public.get('infrastructure_error') is None, 'Unexpected/private/infrastructure feedback')
    return public


def evaluate(condition, task):
    require(condition in CONDITIONS and task in adapter.TASKS, 'Explicit candidate condition and task required')
    remotes()
    role = BASE / condition
    with policy.HeavyRunLock(BASE / 'native-feedback.lock'), policy.HeavyRunLock(role / '.fileops-v2.lock'):
        attempt, record_dir = reserve_attempt(role, task)
        record = {'protocol': 'stead.parent-public-feedback/1', 'condition': condition, 'task': task,
                  'attempt': attempt, 'status': 'failed', 'started_at': now(), 'native_execution': 'pending',
                  'startup_attempted': False, 'ownership_resolved': False,
                  'scope': 'Public feedback only; no final private score or phase qualification.'}
        immutable(record_dir / 'request.json', encoded(record))
        commands, owner, before_runs, tried_start = Commands(record_dir), None, None, False
        result = None
        try:
            binding = source_binding()
            proof, diagnostic = prior_prequalification(binding)
            require(all(read(BASE / other / 'input/T02-starter-diagnostic.json') == diagnostic for other in CONDITIONS),
                    'Exact initial T02 compiler diagnostic was not supplied before feedback')
            target, files = snapshot(role, task, attempt)
            record.update(binding=binding, prequalification=proof, snapshot=str(target.relative_to(REPO)), files_sha256=files)
            immutable(record_dir / 'inputs.json', encoded(record))
            require(commands.status().get('stage') in ('stopped', 'not-created'), 'Refusing to adopt another live fixture')
            before_runs = guard_runs()
            try:
                tried_start = True
                record['startup_attempted'] = True
                immutable(record_dir / 'startup-intent.json', encoded({'startup_attempted': True, 'started_at': now()}))
                code, _, _ = commands.call('start', ['make', 'start'], 180)
                owner = new_guard(before_runs)
                require(code == 0, 'Native startup refused or failed')
                status = commands.status()
                require(status.get('execution_guard', {}).get('run_id') == owner[1], 'Live fixture is not the newly owned run')
                code, _, _ = commands.call('wait-ready', ['make', 'wait-ready'], 1205)
                require(code == 0, 'Native readiness failed')
                code, output, _ = commands.call('feedback', [sys.executable, 'scripts/urbit/harness.py', 'skill-feedback',
                    '--condition', condition, '--task', task, '--attempt', str(attempt)], 3605)
                result = adapter.json_bytes(output)
                require(code == (0 if result.get('status') == 'pass' else 1)
                        and result.get('status') in ('pass', 'fail'), 'Unexpected feedback controller outcome')
            finally:
                if owner is None and tried_start:
                    owner = new_guard(before_runs)
                if owner is not None:
                    record['ownership_resolved'] = True
                    record['owned_run'] = {'run_id': owner[1], 'path': str(owner[0].relative_to(REPO))}
                    stop_owned(commands, owner, before_runs)
                    record['cleanup_completed'] = True
                    if (owner[0] / 'report.json').exists():
                        stopped = document(owner[0] / 'report.json')
                        if stopped.get('run_id') == owner[1] and stopped.get('launched') is False:
                            record.update(native_execution='not-launched', no_launch_refusal=True)
            require(result is not None, 'Missing public feedback result')
            raw_guard, guard = stopped_guard(*owner)
            immutable(record_dir / 'guard.json', raw_guard)
            record['guard'] = {'run_id': owner[1], 'sha256': digest(raw_guard), 'path': str(owner[0].relative_to(REPO)) + '/report.json'}
            require(commands.status().get('stage') == 'stopped'
                    and not (REPO / '.piers/fakes/unclean-live.json').exists(), 'Fixture did not stop cleanly')
            context = document(owner[0] / 'control/source-context.json')
            require(context.get('source_commit') == binding['head'] and context.get('committed_bytes_verified') is True
                    and context.get('dirty_paths') == [] and context.get('harness_sha256') == binding['harness_sha256'],
                    'Owned guard source context differs from submitted source')
            require(source_binding() == binding and prior_prequalification(binding)[0] == proof
                    and adapter.hashes(task_files(target)) == files, 'Source, package, proof or snapshot changed')
            raws = []
            for field in ('evidence_file', 'feedback_file'):
                path = Path(result[field])
                require(path.parent == Path('.piers/fakes/logs') and path.name.startswith('skill-evaluation-')
                        and path.suffix == '.json', 'Unexpected native report path')
                raws.append(read(REPO / path))
            public = admit_feedback(result, *raws, guard, binding, condition, task, attempt, files)
            for name, raw in zip(('internal.json', 'public.json'), raws, strict=True):
                immutable(record_dir / name, raw)
            publishable_space(role, raws[1])
            feedback = directory(role / 'input/feedback') / (task + '-' + str(attempt) + '.json')
            record.update(status='ready-to-publish', native_execution='completed',
                          public_status=public['status'], feedback_sha256=digest(raws[1]),
                          public_target=str(feedback.relative_to(BASE)))
            immutable(record_dir / 'validated.json', encoded(record))
            immutable(feedback, raws[1])
            record['status'] = 'published'
            return record
        except BaseException as error:
            record['error'] = type(error).__name__ + ': ' + str(error)
            raise
        finally:
            record['finished_at'] = now()
            immutable(record_dir / 'result.json', encoded(record))


def main():
    require(len(sys.argv) == 3, 'usage: feedback_broker.py CONDITION TASK')
    def interrupted(*_):
        raise KeyboardInterrupt('Parent feedback broker interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    print(json.dumps(evaluate(sys.argv[1], sys.argv[2]), sort_keys=True, indent=2))


if __name__ == '__main__':
    main()

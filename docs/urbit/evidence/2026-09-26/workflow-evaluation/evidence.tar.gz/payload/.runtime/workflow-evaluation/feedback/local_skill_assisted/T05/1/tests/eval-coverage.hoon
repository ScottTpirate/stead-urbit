/+  *test, eval-authorization
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-reader-claim-writer
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 0 0))))
++  test-owner-claim-writer
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 3 3))))
++  test-outsider-claim-writer
  (expect !>(=(~ (advance:eval-authorization ~wes ~bus 12 12))))
++  test-reader-claim-self
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 8 8))))
++  test-owner-claim-self
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 0 0))))
++  test-outsider-claim-self
  (expect !>(=(~ (advance:eval-authorization ~wes ~wes 2 2))))
++  test-writer-claim-reader
  (expect !>(=([~ 8] (advance:eval-authorization ~bus ~nec 7 7))))
++  test-writer-claim-owner
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~zod 0 0))))
++  test-writer-claim-outsider
  (expect !>(=([~ 65.536] (advance:eval-authorization ~bus ~wes 65.535 65.535))))
++  test-future-revision
  (expect !>(=(~ (advance:eval-authorization ~bus ~nec 3 4))))
++  test-stale-with-untrusted-claim
  (expect !>(=(~ (advance:eval-authorization ~bus ~zod 3 2))))
--

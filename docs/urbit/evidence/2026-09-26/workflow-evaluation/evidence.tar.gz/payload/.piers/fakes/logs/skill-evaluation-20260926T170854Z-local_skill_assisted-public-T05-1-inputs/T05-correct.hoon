=/  test
::  testing utilities meant to be directly used from files in %/tests
::
|%
::  +expect-eq: compares :expected and :actual and pretty-prints the result
::
++  expect-eq
  |=  [expected=vase actual=vase]
  ^-  tang
  ::
  =|  result=tang
  ::
  =?  result  !=(q.expected q.actual)
    %+  weld  result
    ^-  tang
    :~  [%palm [": " ~ ~ ~] [leaf+"expected" (sell expected) ~]]
        [%palm [": " ~ ~ ~] [leaf+"actual  " (sell actual) ~]]
    ==
  ::
  =?  result  !(~(nest ut p.actual) | p.expected)
    %+  weld  result
    ^-  tang
    :~  :+  %palm  [": " ~ ~ ~]
        :~  [%leaf "failed to nest"]
            (~(dunk ut p.actual) %actual)
            (~(dunk ut p.expected) %expected)
    ==  ==
  result
::  +expect: compares :actual to %.y and pretty-prints anything else
::
++  expect
  |=  actual=vase
  (expect-eq !>(%.y) actual)
::  +expect-fail: kicks a trap, expecting crash. pretty-prints if succeeds
::
++  expect-fail
  |=  a=(trap)
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %|  ~
    %&  ['expected failure - succeeded' ~]
  ==
::  +expect-success: kicks a trap, expecting success; returns trace on failure
::
++  expect-success
  |=  a=(trap)
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %&  ~
    %|  ['expected success - failed' p.b]
  ==
::
::  +expect-fail-message: kicks a trap, expecting crash, compares the resulting error message
++  expect-fail-message
  |=  [msg=@t a=(trap)]
  ^-  tang
  =/  b  (mule a)
  ?-  -.b
    %|  |^
        =/  =tang  (flatten +.b)
        ?:  ?=(^ (find (trip msg) tang))
          ~
        ['expected error message - not found' ~]
        ++  flatten
          |=  tang=(list tank)
          =|  res=tape
          |-  ^-  tape
          ?~  tang  res
          $(tang t.tang, res (weld ~(ram re i.tang) res))
        --
    %&  ['expected failure - succeeded' ~]
  ==
::  $a-test-chain: a sequence of tests to be run
::
::  NB: arms shouldn't start with `test-` so that `-test % ~` runs
::
+$  a-test-chain
  $_
  |?
  ?:  =(0 0)
    [%& p=*tang]
  [%| p=[tang=*tang next=^?(..$)]]
::  +run-chain: run a sequence of tests, stopping at first failure
::
++  run-chain
  |=  seq=a-test-chain
  ^-  tang
  =/  res  $:seq
  ?-  -.res
    %&  p.res
    %|  ?.  =(~ tang.p.res)
          tang.p.res
        $(seq next.p.res)
  ==
::  +category: prepends a name to an error result; passes successes unchanged
::
++  category
  |=  [a=tape b=tang]  ^-  tang
  ?:  =(~ b)  ~  :: test OK
  :-  leaf+"in: '{a}'"
  (turn b |=(c=tank rose+[~ "  " ~]^~[c]))
--

=/  eval-authorization
|%
++  advance
  |=  [sender=@p claimed=@p current=@ud expected=@ud]
  ^-  (unit @ud)
  ?.  =(~bus sender)  ~
  ?.  =(current expected)  ~
  [~ +(current)]
--

=,  test
=>
|%
++  test-writer
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~bus 0 0))))
++  test-stale
  (expect !>(=(~ (advance:eval-authorization ~bus ~bus 1 0))))
++  test-reader-claim-writer
  (expect !>(=(~ (advance:eval-authorization ~nec ~bus 0 0))))
++  test-owner-claim-writer
  (expect !>(=(~ (advance:eval-authorization ~zod ~bus 3 3))))
++  test-outsider-claim-writer
  (expect !>(=(~ (advance:eval-authorization ~wes ~bus 12 12))))
++  test-reader-claim-self
  (expect !>(=(~ (advance:eval-authorization ~nec ~nec 8 8))))
++  test-owner-claim-self
  (expect !>(=(~ (advance:eval-authorization ~zod ~zod 0 0))))
++  test-outsider-claim-self
  (expect !>(=(~ (advance:eval-authorization ~wes ~wes 2 2))))
++  test-writer-claim-reader
  (expect !>(=([~ 8] (advance:eval-authorization ~bus ~nec 7 7))))
++  test-writer-claim-owner
  (expect !>(=([~ 1] (advance:eval-authorization ~bus ~zod 0 0))))
++  test-writer-claim-outsider
  (expect !>(=([~ 65.536] (advance:eval-authorization ~bus ~wes 65.535 65.535))))
++  test-future-revision
  (expect !>(=(~ (advance:eval-authorization ~bus ~nec 3 4))))
++  test-stale-with-untrusted-claim
  (expect !>(=(~ (advance:eval-authorization ~bus ~zod 3 2))))
--

=/  observed=(list [@t tang])  ~[['test-writer' test-writer] ['test-stale' test-stale] ['test-reader-claim-writer' test-reader-claim-writer] ['test-owner-claim-writer' test-owner-claim-writer] ['test-outsider-claim-writer' test-outsider-claim-writer] ['test-reader-claim-self' test-reader-claim-self] ['test-owner-claim-self' test-owner-claim-self] ['test-outsider-claim-self' test-outsider-claim-self] ['test-writer-claim-reader' test-writer-claim-reader] ['test-writer-claim-owner' test-writer-claim-owner] ['test-writer-claim-outsider' test-writer-claim-outsider] ['test-future-revision' test-future-revision] ['test-stale-with-untrusted-claim' test-stale-with-untrusted-claim]]
=/  failures  (skim observed |=([name=@t result=tang] !=(~ result)))
?>  =(~ failures)
^-  [@tas @ud]
[%skill-result (jam observed)]
